/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test.samples.substance.api;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.theme.*;

/**
 * Test application that shows the use of the
 * {@link SubstanceLookAndFeel#getActiveColorScheme()} API.
 * 
 * @author Kirill Grouchnikov
 * @see SubstanceLookAndFeel#getActiveColorScheme()
 */
public class GetActiveColorScheme extends JFrame {
	/**
	 * Creates the main frame for <code>this</code> sample.
	 */
	public GetActiveColorScheme() {
		super("Get active color scheme");

		this.setLayout(new BorderLayout());

		final JPanel panel = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				int width = getWidth();
				int height = getHeight();

				// paint the panel with the colors of the current
				// active color scheme
				ColorScheme scheme = SubstanceLookAndFeel
						.getActiveColorScheme();
				Paint paint = new GradientPaint(0, 0, scheme
						.getUltraLightColor(), width, height, scheme
						.getLightColor());
				Graphics2D g2 = (Graphics2D) g.create();
				g2.setPaint(paint);
				g2.fillRect(0, 0, width, height);
				g2.dispose();
			}
		};
		this.add(panel, BorderLayout.CENTER);

		JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		final JButton setAqua = new JButton("Set Aqua");
		setAqua.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						// Set Aqua theme
						SubstanceLookAndFeel
								.setCurrentTheme(new SubstanceAquaTheme());
						SwingUtilities
								.updateComponentTreeUI(GetActiveColorScheme.this);
					}
				});
			}
		});
		controls.add(setAqua);

		final JButton setPink = new JButton("Set Pink");
		setPink.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						// Set Barby Pink theme
						SubstanceLookAndFeel
								.setCurrentTheme(new SubstanceBarbyPinkTheme());
						SwingUtilities
								.updateComponentTreeUI(GetActiveColorScheme.this);
					}
				});
			}
		});
		controls.add(setPink);

		this.add(controls, BorderLayout.SOUTH);

		// register theme change listener to repaint the panel on theme change
		SubstanceLookAndFeel
				.registerThemeChangeListener(new ThemeChangeListener() {
					public void themeChanged() {
						panel.repaint();
					}
				});

		this.setSize(400, 200);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	/**
	 * The main method for <code>this</code> sample. The arguments are
	 * ignored.
	 * 
	 * @param args
	 *            Ignored.
	 * @throws Exception
	 *             If some exception occured. Note that there is no special
	 *             treatment of exception conditions in <code>this</code>
	 *             sample code.
	 */
	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		JFrame.setDefaultLookAndFeelDecorated(true);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new GetActiveColorScheme().setVisible(true);
			}
		});
	}
}
