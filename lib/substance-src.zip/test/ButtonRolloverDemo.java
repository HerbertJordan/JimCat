package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.jvnet.lafwidget.LafWidget;
import org.jvnet.lafwidget.utils.FadeConfigurationManager;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.lafwidget.utils.LafConstants.AnimationKind;
import org.jvnet.substance.SubstanceDefaultListCellRenderer;
import org.jvnet.substance.skin.SubstanceModerateLookAndFeel;

public class ButtonRolloverDemo extends JFrame {
	public ButtonRolloverDemo() {
		super("Button Rollover Demo");

		this.setLayout(new BorderLayout());
		final JPanel buttons = new JPanel(new FlowLayout());
		buttons.putClientProperty(LafWidget.ANIMATION_KIND,
				AnimationKind.REGULAR);
		buttons.add(new JButton("Copy", new ImageIcon(ButtonRolloverDemo.class
				.getResource("/org/jvnet/lafwidget/text/edit-copy.png"))));
		buttons.add(new JButton("Cut", new ImageIcon(ButtonRolloverDemo.class
				.getResource("/org/jvnet/lafwidget/text/edit-cut.png"))));
		buttons.add(new JButton("Paste", new ImageIcon(ButtonRolloverDemo.class
				.getResource("/org/jvnet/lafwidget/text/edit-paste.png"))));
		buttons
				.add(new JButton(
						"Delete",
						new ImageIcon(
								ButtonRolloverDemo.class
										.getResource("/org/jvnet/lafwidget/text/edit-delete.png"))));
		buttons
				.add(new JButton(
						"Select All",
						new ImageIcon(
								ButtonRolloverDemo.class
										.getResource("/org/jvnet/lafwidget/text/edit-select-all.png"))));

		this.add(buttons, BorderLayout.CENTER);

		JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		final JComboBox animKindCombo = new JComboBox(new Object[] {
				AnimationKind.NONE, AnimationKind.FAST, AnimationKind.REGULAR,
				AnimationKind.SLOW });
		animKindCombo.setRenderer(new SubstanceDefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list,
					Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				AnimationKind ak = (AnimationKind) value;
				return super.getListCellRendererComponent(list, ak.getName(),
						index, isSelected, cellHasFocus);
			}
		});
		animKindCombo.setSelectedItem(buttons
				.getClientProperty(LafWidget.ANIMATION_KIND));
		controls.add(animKindCombo);
		animKindCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttons.putClientProperty(LafWidget.ANIMATION_KIND,
						animKindCombo.getSelectedItem());
			}
		});
		this.add(controls, BorderLayout.SOUTH);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(300, 150);
		this.setLocationRelativeTo(null);
	}

	public static void main(String[] args) throws Exception {
		JFrame.setDefaultLookAndFeelDecorated(true);
		UIManager.setLookAndFeel(new SubstanceModerateLookAndFeel());
		FadeConfigurationManager.getInstance().allowFades(
				FadeKind.GHOSTING_ICON_ROLLOVER);
		FadeConfigurationManager.getInstance().allowFades(
				FadeKind.GHOSTING_BUTTON_PRESS);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new ButtonRolloverDemo().setVisible(true);
			}
		});

	}
}
