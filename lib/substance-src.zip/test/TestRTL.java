package test;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Locale;

import javax.swing.*;

public class TestRTL {
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try {

			UIManager
					.setLookAndFeel("net.beeger.squareness.SquarenessLookAndFeel");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		Locale.setDefault(new Locale("iw"));

		JFrame frame = new JFrame("RTL Test");

		JMenu main = new JMenu("\u05e8\u05d0\u05e9\u05d9");
		JMenuItem item = new JMenuItem("\u05d9\u05e6\u05d9\u05d0\u05d4");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
				KeyEvent.CTRL_DOWN_MASK));
		item.setIcon(new SomeIcon());
		main.add(item);
		item = new JMenuItem("Test test test");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
				Event.CTRL_MASK | Event.ALT_MASK));
		main.add(item);
		JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem(
				"Test test test");
		checkBoxMenuItem.setIcon(new SomeIcon());
		checkBoxMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,
				KeyEvent.CTRL_DOWN_MASK));
		main.add(checkBoxMenuItem);
		main.add(new JMenu("bla"));

		JMenuBar mb = new JMenuBar();
		mb.add(main);
		frame.setJMenuBar(mb);

		frame.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		frame.setSize(200, 200);
		frame.setVisible(true);
	}

	private static class SomeIcon implements Icon {

		public void paintIcon(Component c, Graphics g, int x, int y) {
			Color oldColor = g.getColor();
			g.setColor(Color.GREEN);
			g.fillRect(x, y, 7, 7);
			g.setColor(oldColor);
		}

		public int getIconWidth() {
			return 7;
		}

		public int getIconHeight() {
			return 7;
		}
	}
}