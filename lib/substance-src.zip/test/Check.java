/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.net.URL;
import java.util.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.jdesktop.swingx.JXTaskPane;
import org.jdesktop.swingx.JXTaskPaneContainer;
import org.jvnet.lafwidget.LafWidget;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.layout.TransitionLayoutManager;
import org.jvnet.lafwidget.tabbed.DefaultTabPreviewPainter;
import org.jvnet.lafwidget.utils.LafConstants.AnimationKind;
import org.jvnet.substance.*;
import org.jvnet.substance.button.*;
import org.jvnet.substance.painter.*;
import org.jvnet.substance.skin.SkinChangeListener;
import org.jvnet.substance.tabbed.*;
import org.jvnet.substance.theme.*;
import org.jvnet.substance.title.*;
import org.jvnet.substance.utils.SubstanceConstants;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.SubstanceConstants.*;
import org.jvnet.substance.watermark.*;

import test.check.*;
import test.check.AKDockLayout;

public class Check extends JFrame {
	private JTabbedPane jtp;

	private static class FontSizeChanger implements ActionListener {
		private JFrame frame;

		private boolean isAbsolute;

		private int value;

		public FontSizeChanger(JFrame frame, boolean isAbsolute, int value) {
			this.frame = frame;
			this.isAbsolute = isAbsolute;
			this.value = value;
		}

		public void actionPerformed(ActionEvent e) {
			try {
				if (isAbsolute)
					SubstanceLookAndFeel.setBasicFontSize(value);
				else
					SubstanceLookAndFeel.setFontSizeExtra(value);
				UIManager.setLookAndFeel(new SubstanceLookAndFeel());
				SwingUtilities.updateComponentTreeUI(frame);
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}
	}

	private class MyThemeChangeListener implements ThemeChangeListener {
		public void themeChanged() {
			if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
				out("Substance theme is '"
						+ SubstanceLookAndFeel.getCurrentThemeName() + "'");
				Check.this.setIconImage(SubstanceImageCreator.getThemeImage(
						new ImageIcon(Check.class.getClassLoader().getResource(
								"test/resource/image-x-generic.png")),
						SubstanceLookAndFeel.getTheme(), false));

			}
		}
	}

	private class MyWatermarkChangeListener implements WatermarkChangeListener {
		public void watermarkChanged() {
			if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
				out("Substance watermark is '"
						+ SubstanceLookAndFeel.getCurrentWatermarkName() + "'");
			}
		}
	}

	private class MyButtonShaperChangeListener implements
			ButtonShaperChangeListener {
		public void buttonShaperChanged() {
			if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
				out("Substance button shaper is '"
						+ SubstanceLookAndFeel.getCurrentButtonShaperName()
						+ "'");
			}
		}
	}

	private class MyGradientPainterChangeListener implements
			GradientPainterChangeListener {
		public void gradientPainterChanged() {
			if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
				out("Substance gradient painter is '"
						+ SubstanceLookAndFeel.getCurrentGradientPainterName()
						+ "'");
			}
		}
	}

	private class MyTitlePainterChangeListener implements
			TitlePainterChangeListener {
		public void titlePainterChanged() {
			if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
				out("Substance title painter is '"
						+ SubstanceLookAndFeel.getCurrentTitlePainterName()
						+ "'");
			}
		}
	}

	private boolean toUseThemeObjs;

	private boolean toUseWatermarksObjs;

	private boolean toUseButtonShapersObjs;

	private boolean toUseGradientPaintersObjs;

	private JXTaskPaneContainer taskPaneContainer;

	private JXTaskPane currentSpecificTaskPane;

	private JXTaskPane mainTaskPane;

	public Check() {
		super(
				"Substance test with very very very very very very very very very very very very very very long title");

		// this.setIconImage(SubstanceImageCreator.getBigHexaMarker(6,
		// SubstanceLookAndFeel.getTheme()));
		this.setIconImage(SubstanceImageCreator.getThemeImage(new ImageIcon(
				Check.class.getClassLoader().getResource(
						"test/resource/image-x-generic.png")),
				SubstanceLookAndFeel.getTheme(), false));
		this.setLayout(new AKDockLayout());

		this.jtp = new JTabbedPane();
		this.jtp.getModel().addChangeListener(new TabSwitchListener());

		TransitionLayoutManager.getInstance().track(this.jtp, true);
		UIManager.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if ("lookAndFeel".equals(evt.getPropertyName())) {
					LookAndFeel newLaf = (LookAndFeel) evt.getNewValue();
					if (newLaf.getID().contains("Substance")) {
						if (!(jtp.getLayout() instanceof TransitionLayout)) {
							TransitionLayoutManager.getInstance().track(jtp,
									true);
						}
					} else {
						TransitionLayoutManager.getInstance().untrack(jtp);
					}
				}
			}
		});
		this.add(jtp, AKDockLayout.CENTER);

		// JPanel buttons = new JPanel(new FlowLayout());

		this.taskPaneContainer = new JXTaskPaneContainer();
		this.taskPaneContainer.putClientProperty(
				SubstanceLookAndFeel.BUTTON_SHAPER_PROPERTY,
				new ClassicButtonShaper());

		this.mainTaskPane = new JXTaskPane();
		this.mainTaskPane.setLayout(new BorderLayout());
		JPanel mainControlPanel = ControlPanelFactory.getMainControlPanel(this,
				jtp);
		mainControlPanel.setOpaque(false);
		this.mainTaskPane.add(mainControlPanel, BorderLayout.CENTER);
		this.mainTaskPane.setTitle("General settings");
		this.mainTaskPane.setIcon(getIcon("JFrameColor16"));
		this.mainTaskPane.setExpanded(false);
		this.taskPaneContainer.add(this.mainTaskPane);

		JPanel dialogControlPanel = ControlPanelFactory
				.getDialogControlPanel(this);
		JXTaskPane dialogTaskPane = new JXTaskPane();
		dialogTaskPane.setLayout(new BorderLayout());
		dialogTaskPane.add(dialogControlPanel, BorderLayout.CENTER);
		dialogTaskPane.setTitle("Dialogs");
		dialogTaskPane.setIcon(getIcon("JDialogColor16"));
		dialogTaskPane.setExpanded(false);
		dialogTaskPane.setOpaque(false);
		this.taskPaneContainer.add(dialogTaskPane);

		this.currentSpecificTaskPane = null;

		JScrollPane scrollPane = new JScrollPane(this.taskPaneContainer,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setOpaque(false);
		scrollPane.getViewport().setOpaque(false);
		this.add(scrollPane, BorderLayout.WEST);

		this.setPreferredSize(new Dimension(400, 400));
		this.setSize(this.getPreferredSize());
		this.setMinimumSize(this.getPreferredSize());

		ButtonsPanel buttonsPanel = new ButtonsPanel();
		this.jtp.addTab("Buttons", getIcon("JButtonColor16"), buttonsPanel);
		this.getRootPane().setDefaultButton(buttonsPanel.defaultButton);

		this.jtp.addTab("Mixed Buttons", getIcon("JColorChooserColor16"),
				new MixedButtonsPanel());

		this.jtp.addTab("Combo box", getIcon("JComboBoxColor16"),
				new CombosPanel());

		this.jtp.addTab("Scroll pane", getIcon("JScrollPaneColor16"),
				new ScrollPanel());

		TabCloseCallback closeCallback = new TabCloseCallback() {
			public TabCloseKind onAreaClick(JTabbedPane tabbedPane,
					int tabIndex, MouseEvent mouseEvent) {
				if (mouseEvent.getButton() != MouseEvent.BUTTON3)
					return TabCloseKind.NONE;
				if (mouseEvent.isShiftDown()) {
					return TabCloseKind.ALL;
				}
				return TabCloseKind.THIS;
			}

			public TabCloseKind onCloseButtonClick(JTabbedPane tabbedPane,
					int tabIndex, MouseEvent mouseEvent) {
				if (mouseEvent.isAltDown()) {
					return TabCloseKind.ALL_BUT_THIS;
				}
				if (mouseEvent.isShiftDown()) {
					return TabCloseKind.ALL;
				}
				return TabCloseKind.THIS;
			}

			public String getAreaTooltip(JTabbedPane tabbedPane, int tabIndex) {
				return null;
			}

			public String getCloseButtonTooltip(JTabbedPane tabbedPane,
					int tabIndex) {
				StringBuffer result = new StringBuffer();
				result.append("<html><body>");
				result.append("Mouse click closes <b>"
						+ tabbedPane.getTitleAt(tabIndex) + "</b> tab");
				result
						.append("<br><b>Alt</b>-Mouse click closes all tabs but <b>"
								+ tabbedPane.getTitleAt(tabIndex) + "</b> tab");
				result.append("<br><b>Shift</b>-Mouse click closes all tabs");
				result.append("</body></html>");
				return result.toString();
			}
		};

		TabPanel tp = new TabPanel();
		tp.jtp.putClientProperty(
				SubstanceLookAndFeel.TABBED_PANE_CLOSE_CALLBACK, closeCallback);
		try {
			tp.jtp.putClientProperty(LafWidget.TABBED_PANE_PREVIEW_PAINTER,
					new DefaultTabPreviewPainter() {
						@Override
						public boolean toUpdatePeriodically(JTabbedPane tabPane) {
							return true;
						}

						@Override
						public int getUpdateCycle(JTabbedPane tabPane) {
							return 3000;
						}

						@Override
						public void previewTab(JTabbedPane tabPane,
								int tabIndex, Graphics g, int x, int y, int w,
								int h) {
							super.previewTab(tabPane, tabIndex, g, x, y, w, h);
						}
					});
		} catch (Throwable e) {
		}
		this.jtp.addTab("Tabbed pane", getIcon("JTabbedPaneColor16"), tp);

		TabPanel tp2 = new TabPanel();
		tp2.jtp.putClientProperty(
				SubstanceLookAndFeel.TABBED_PANE_VERTICAL_ORIENTATION, true);

		tp2.jtp.putClientProperty(
				SubstanceLookAndFeel.TABBED_PANE_CLOSE_CALLBACK, closeCallback);
		tp2.jtp.setTabPlacement(JTabbedPane.RIGHT);
		SubstanceLookAndFeel.registerTabCloseChangeListener(tp2.jtp,
				new MultipleTabCloseListener() {
					public void tabsClosed(JTabbedPane tabbedPane,
							Set<Component> tabComponents) {
						out("Closed " + tabComponents.size()
								+ " vertical tabs - specific");
					}

					public void tabsClosing(JTabbedPane tabbedPane,
							Set<Component> tabComponents) {
						out("Closing " + tabComponents.size()
								+ " vertical tabs - specific");
					}
				});
		SubstanceLookAndFeel.registerTabCloseChangeListener(tp2.jtp,
				new TabCloseListener() {
					public void tabClosed(JTabbedPane tabbedPane,
							Component tabComponent) {
						out("Closed vertical tab - specific");
					}

					public void tabClosing(JTabbedPane tabbedPane,
							Component tabComponent) {
						out("Closing vertical tab - specific");
					}
				});

		this.jtp.addTab("Tabbed pane vertical", tp2);

		this.jtp.addTab("Split", new SplitPanel());

		this.jtp.addTab("Desktop", getIcon("JDesktopPaneColor16"),
				new DesktopPanel());

		this.jtp.addTab("Text fields", getIcon("JTextPaneColor16"),
				new TextFieldsPanel());

		this.jtp.addTab("Table", getIcon("JTableColor16"), new TablePanel());

		this.jtp.addTab("List", getIcon("JListColor16"), new ListPanel());

		this.jtp.addTab("Slider", getIcon("JSliderColor16"), new SliderPanel());

		this.jtp.addTab("Progress bar", getIcon("JProgressBarColor16"),
				new ProgressBarPanel());

		this.jtp.addTab("Spinner", getIcon("JSpinnerColor16"),
				new SpinnerPanel());

		this.jtp.addTab("Tree", getIcon("JTreeColor16"), new TreePanel());

		this.jtp.addTab("Cards", new CardPanel());

		JPanel bigButtonPanel = new JPanel();
		bigButtonPanel.setLayout(new BorderLayout());
		bigButtonPanel.add(new JButton("One big button"));
		this.jtp.addTab("Big button", bigButtonPanel);

		JPanel verticalButtonPanel = new JPanel();
		verticalButtonPanel.setLayout(new GridLayout(1, 3));
		verticalButtonPanel.add(new JButton("Vert button 1"));
		verticalButtonPanel.add(new JButton("Vert button 2"));
		JPanel smallVerticalButtonPanel = new JPanel();
		smallVerticalButtonPanel.setLayout(new GridLayout(4, 4));
		for (int row = 0; row < 4; row++) {
			for (int col = 0; col < 4; col++) {
				smallVerticalButtonPanel.add(new JButton("vert"));
			}
		}
		verticalButtonPanel.add(smallVerticalButtonPanel);
		this.jtp.addTab("Vertical buttons", verticalButtonPanel);

		JPanel coloredPanel = new JPanel();
		coloredPanel.setLayout(new FlowLayout());
		coloredPanel.setBackground(new Color(200, 200, 255));
		JCheckBox colored1 = new JCheckBox("Colored checkbox");
		colored1.setForeground(Color.blue);
		colored1.setBackground(Color.yellow);
		coloredPanel.add(colored1);
		JRadioButton colored2 = new JRadioButton("Colored radiobutton");
		colored2.setForeground(new Color(0, 128, 0));
		colored2.setBackground(new Color(255, 180, 180));
		coloredPanel.add(colored2);
		JSlider colored3 = new JSlider(100, 1000, 400);
		colored3.setPaintTicks(true);
		colored3.setMajorTickSpacing(100);
		colored3.setForeground(new Color(128, 0, 0));
		colored3.setBackground(new Color(180, 255, 180));
		coloredPanel.add(colored3);
		JPanel colored4 = new JPanel();
		colored4.setSize(100, 100);
		colored4.setPreferredSize(colored4.getSize());
		colored4.setBackground(Color.cyan);
		coloredPanel.add(colored4);
		this.jtp.addTab("Colored components", coloredPanel);

		JPanel buttonStripPanel = new JPanel();
		buttonStripPanel.setLayout(new FlowLayout());

		this.jtp.addTab("Theme combo", new ThemesPanel());

		// sample menu bar
		JMenuBar jmb = new JMenuBar();

		if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {

			jmb.add(SampleMenuFactory.getThemeMenu());
			jmb.add(SampleMenuFactory.getSkinMenu());

			JMenu jmWatermark = new JMenu("Watermark");
			JCheckBoxMenuItem jmiWatermarkObjs = new JCheckBoxMenuItem(
					"Use objects");
			jmiWatermarkObjs.setSelected(true);
			jmiWatermarkObjs.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JCheckBoxMenuItem src = (JCheckBoxMenuItem) e.getSource();
					toUseWatermarksObjs = src.isSelected();
				}
			});
			jmWatermark.add(jmiWatermarkObjs);
			toUseWatermarksObjs = jmiWatermarkObjs.isSelected();

			Map<String, WatermarkInfo> allWatermarks = SubstanceLookAndFeel
					.getAllWatermarks();
			for (Map.Entry<String, WatermarkInfo> watermarkEntry : allWatermarks
					.entrySet()) {
				String watermarkName = watermarkEntry.getKey();
				final String watermarkClassName = watermarkEntry.getValue()
						.getClassName();

				JMenuItem jmiWatermark = new JMenuItem(watermarkName);
				try {
					Class watermarkClass = Class.forName(watermarkClassName);
					SubstanceWatermark watermark = (SubstanceWatermark) watermarkClass
							.newInstance();
					jmiWatermark.setIcon(SubstanceImageCreator
							.getWatermarkIcon(watermark));
				} catch (Exception exc) {
					continue;
				}
				jmiWatermark.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								if (toUseWatermarksObjs) {
									try {
										SubstanceLookAndFeel
												.setCurrentWatermark((SubstanceWatermark) Class
														.forName(
																watermarkClassName)
														.newInstance());
									} catch (Exception exc) {
										exc.printStackTrace();
									}
								} else {
									SubstanceLookAndFeel
											.setCurrentWatermark(watermarkClassName);
								}
								SwingUtilities
										.updateComponentTreeUI(Check.this);
							}
						});
					}
				});
				if (watermarkName.equals(SubstanceLookAndFeel
						.getCurrentWatermarkName())) {
					jmiWatermark.setSelected(true);
				}
				jmWatermark.add(jmiWatermark);
			}

			jmWatermark.addSeparator();

			JMenuItem jmiCoffeeBeansWatermark = new JMenuItem("Coffee Beans");
			jmiCoffeeBeansWatermark.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							try {
								SubstanceLookAndFeel
										.setCurrentWatermark(new SubstanceCoffeeBeansWatermark());
							} catch (Exception exc) {
								exc.printStackTrace();
							}
							SwingUtilities.updateComponentTreeUI(Check.this);
						}
					});
				}
			});
			if ("Coffee Beans".equals(SubstanceLookAndFeel
					.getCurrentWatermarkName())) {
				jmiCoffeeBeansWatermark.setSelected(true);
			}
			jmWatermark.add(jmiCoffeeBeansWatermark);

			JMenuItem jmiVerticalGradientWatermark = new JMenuItem(
					"Vertical Gradient");
			jmiVerticalGradientWatermark
					.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							SwingUtilities.invokeLater(new Runnable() {
								public void run() {
									try {
										SubstanceLookAndFeel
												.setCurrentWatermark(new SubstanceVerticalGradientWatermark());
									} catch (Exception exc) {
										exc.printStackTrace();
									}
									SwingUtilities
											.updateComponentTreeUI(Check.this);
								}
							});
						}
					});
			if ("Vertical Gradient".equals(SubstanceLookAndFeel
					.getCurrentWatermarkName())) {
				jmiVerticalGradientWatermark.setSelected(true);
			}
			jmWatermark.add(jmiVerticalGradientWatermark);

			JMenuItem jmiDiagonalGradientWatermark = new JMenuItem(
					"Diagonal Gradient");
			jmiDiagonalGradientWatermark
					.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							SwingUtilities.invokeLater(new Runnable() {
								public void run() {
									try {
										SubstanceLookAndFeel
												.setCurrentWatermark(new SubstanceDiagonalGradientWatermark());
									} catch (Exception exc) {
										exc.printStackTrace();
									}
									SwingUtilities
											.updateComponentTreeUI(Check.this);
								}
							});
						}
					});
			if ("Diagonal Gradient".equals(SubstanceLookAndFeel
					.getCurrentWatermarkName())) {
				jmiDiagonalGradientWatermark.setSelected(true);
			}
			jmWatermark.add(jmiDiagonalGradientWatermark);

			jmb.add(jmWatermark);

			JMenu jmButtonShaper = new JMenu("Shapers");
			JCheckBoxMenuItem jmiButtonShaperObjs = new JCheckBoxMenuItem(
					"Use objects");
			jmiButtonShaperObjs.setSelected(true);
			jmiButtonShaperObjs.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JCheckBoxMenuItem src = (JCheckBoxMenuItem) e.getSource();
					toUseButtonShapersObjs = src.isSelected();
				}
			});
			jmButtonShaper.add(jmiButtonShaperObjs);
			toUseButtonShapersObjs = jmiButtonShaperObjs.isSelected();

			ButtonGroup bgButtonShaper = new ButtonGroup();
			Map<String, ButtonShaperInfo> allButtonShapers = SubstanceLookAndFeel
					.getAllButtonShapers();
			for (Map.Entry<String, ButtonShaperInfo> ButtonShaperEntry : allButtonShapers
					.entrySet()) {
				String buttonShaperName = ButtonShaperEntry.getKey();
				final String buttonShaperClassName = ButtonShaperEntry
						.getValue().getClassName();

				JRadioButtonMenuItem jmiButtonShaper = new JRadioButtonMenuItem(
						buttonShaperName);
				jmiButtonShaper.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								if (toUseButtonShapersObjs) {
									try {
										SubstanceLookAndFeel
												.setCurrentButtonShaper((SubstanceButtonShaper) Class
														.forName(
																buttonShaperClassName)
														.newInstance());
									} catch (Exception exc) {
										exc.printStackTrace();
									}
								} else {
									SubstanceLookAndFeel
											.setCurrentButtonShaper(buttonShaperClassName);
								}
								SwingUtilities
										.updateComponentTreeUI(Check.this);
							}
						});
					}
				});
				if (buttonShaperName.equals(SubstanceLookAndFeel
						.getCurrentButtonShaperName())) {
					jmiButtonShaper.setSelected(true);
				}
				bgButtonShaper.add(jmiButtonShaper);
				jmButtonShaper.add(jmiButtonShaper);
			}

			jmb.add(jmButtonShaper);

			JMenu jmGradientPainter = new JMenu("Painters");
			JCheckBoxMenuItem jmiGradientPainterObjs = new JCheckBoxMenuItem(
					"Use objects");
			jmiGradientPainterObjs.setSelected(true);
			jmiGradientPainterObjs.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JCheckBoxMenuItem src = (JCheckBoxMenuItem) e.getSource();
					toUseGradientPaintersObjs = src.isSelected();
				}
			});
			jmGradientPainter.add(jmiGradientPainterObjs);
			toUseGradientPaintersObjs = jmiGradientPainterObjs.isSelected();

			ButtonGroup bgGradientPainter = new ButtonGroup();
			Map<String, GradientPainterInfo> allGradientPainters = SubstanceLookAndFeel
					.getAllGradientPainters();
			for (Map.Entry<String, GradientPainterInfo> GradientPainterEntry : allGradientPainters
					.entrySet()) {
				String gradientPainterName = GradientPainterEntry.getKey();
				final String gradientPainterClassName = GradientPainterEntry
						.getValue().getClassName();

				JRadioButtonMenuItem jmiGradientPainter = new JRadioButtonMenuItem(
						gradientPainterName);
				jmiGradientPainter.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								if (toUseGradientPaintersObjs) {
									try {
										SubstanceLookAndFeel
												.setCurrentGradientPainter((SubstanceGradientPainter) Class
														.forName(
																gradientPainterClassName)
														.newInstance());
									} catch (Exception exc) {
										exc.printStackTrace();
									}
								} else {
									SubstanceLookAndFeel
											.setCurrentGradientPainter(gradientPainterClassName);
								}
								SwingUtilities
										.updateComponentTreeUI(Check.this);
							}
						});
					}
				});
				if (gradientPainterName.equals(SubstanceLookAndFeel
						.getCurrentGradientPainterName())) {
					jmiGradientPainter.setSelected(true);
				}
				bgGradientPainter.add(jmiGradientPainter);
				jmGradientPainter.add(jmiGradientPainter);
			}

			jmb.add(jmGradientPainter);
		}
		JMenu jm0 = new JMenu("Dummy");
		jm0.setMnemonic('0');
		jm0.add(new JMenuItem("dummy0"));
		jmb.add(jm0);

		JMenu testMenu = SampleMenuFactory.getTestMenu();
		jmb.add(testMenu);

		JMenu jm4 = new JMenu("Disabled");
		jm4.add(new JMenuItem("dummy4"));
		jm4.setMnemonic('4');
		jmb.add(jm4);
		jm4.setEnabled(false);

		if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
			JMenu fontSizeMenu = new JMenu("Font size");
			JMenuItem sizeM2 = new JMenuItem("Minus 2 points");
			sizeM2.addActionListener(new FontSizeChanger(this, false, -2));
			fontSizeMenu.add(sizeM2);

			JMenuItem sizeM1 = new JMenuItem("Minus 1 point");
			sizeM1.addActionListener(new FontSizeChanger(this, false, -1));
			fontSizeMenu.add(sizeM1);

			JMenuItem sizeP1 = new JMenuItem("Plus 1 point");
			sizeP1.addActionListener(new FontSizeChanger(this, false, 1));
			fontSizeMenu.add(sizeP1);

			JMenuItem sizeP2 = new JMenuItem("Plus 2 points");
			sizeP2.addActionListener(new FontSizeChanger(this, false, 2));
			fontSizeMenu.add(sizeP2);

			fontSizeMenu.addSeparator();

			JMenuItem size9 = new JMenuItem("Base 9 points");
			size9.addActionListener(new FontSizeChanger(this, true, 9));
			fontSizeMenu.add(size9);

			JMenuItem size10 = new JMenuItem("Base 10 points");
			size10.addActionListener(new FontSizeChanger(this, true, 10));
			fontSizeMenu.add(size10);

			JMenuItem size11 = new JMenuItem("Base 11 points");
			size11.addActionListener(new FontSizeChanger(this, true, 11));
			fontSizeMenu.add(size11);

			JMenuItem size12 = new JMenuItem("Base 12 points");
			size12.addActionListener(new FontSizeChanger(this, true, 12));
			fontSizeMenu.add(size12);

			JMenuItem size13 = new JMenuItem("Base 13 points");
			size13.addActionListener(new FontSizeChanger(this, true, 13));
			fontSizeMenu.add(size13);

			jmb.add(fontSizeMenu);
		}

		// LAF changing
		JMenu lafMenu = new JMenu("Look & feel");
		JMenu substanceMenus = new JMenu("Substance family");
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this, "Substance",
				"org.jvnet.substance.SubstanceLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Default",
				"org.jvnet.substance.SubstanceDefaultLookAndFeel"));
		substanceMenus.addSeparator();
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Business",
				"org.jvnet.substance.skin.SubstanceBusinessLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Creme",
				"org.jvnet.substance.skin.SubstanceCremeLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Moderate",
				"org.jvnet.substance.skin.SubstanceModerateLookAndFeel"));
		substanceMenus
				.add(SubstanceLafChanger
						.getMenuItem(this, "Substance Office Silver 2007",
								"org.jvnet.substance.skin.SubstanceOfficeSilver2007LookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Sahara",
				"org.jvnet.substance.skin.SubstanceSaharaLookAndFeel"));
		substanceMenus.addSeparator();
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Field of Wheat",
				"org.jvnet.substance.skin.SubstanceFieldOfWheatLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Green Magic",
				"org.jvnet.substance.skin.SubstanceGreenMagicLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Mango",
				"org.jvnet.substance.skin.SubstanceMangoLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Office Blue 2007",
				"org.jvnet.substance.skin.SubstanceOfficeBlue2007LookAndFeel"));
		substanceMenus.addSeparator();
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Challenger Deep",
				"org.jvnet.substance.skin.SubstanceChallengerDeepLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Emerald Dusk",
				"org.jvnet.substance.skin.SubstanceEmeraldDuskLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Magma",
				"org.jvnet.substance.skin.SubstanceMagmaLookAndFeel"));
		substanceMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Substance Raven",
				"org.jvnet.substance.skin.SubstanceRavenLookAndFeel"));
		lafMenu.add(substanceMenus);
		lafMenu.addSeparator();
		JMenu coreLafMenus = new JMenu("Core LAFs");
		lafMenu.add(coreLafMenus);
		coreLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Metal",
				"javax.swing.plaf.metal.MetalLookAndFeel"));
		coreLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Windows",
				"com.sun.java.swing.plaf.windows.WindowsLookAndFeel"));
		coreLafMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Windows Classic",
				"com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel"));
		coreLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Motif",
				"com.sun.java.swing.plaf.motif.MotifLookAndFeel"));

		JMenu customLafMenus = new JMenu("Custom LAFs");
		lafMenu.add(customLafMenus);
		JMenu jgoodiesMenu = new JMenu("JGoodies family");
		customLafMenus.add(jgoodiesMenu);
		jgoodiesMenu.add(SubstanceLafChanger.getMenuItem(this,
				"JGoodies Plastic",
				"com.jgoodies.looks.plastic.PlasticLookAndFeel"));
		jgoodiesMenu.add(SubstanceLafChanger.getMenuItem(this,
				"JGoodies PlasticXP",
				"com.jgoodies.looks.plastic.PlasticXPLookAndFeel"));
		jgoodiesMenu.add(SubstanceLafChanger.getMenuItem(this,
				"JGoodies Plastic3D",
				"com.jgoodies.looks.plastic.Plastic3DLookAndFeel"));

		JMenu jtattooMenu = new JMenu("JTattoo family");
		customLafMenus.add(jtattooMenu);
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo Acryl",
				"com.jtattoo.plaf.acryl.AcrylLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo Aero",
				"com.jtattoo.plaf.aero.AeroLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this,
				"JTattoo Aluminium",
				"com.jtattoo.plaf.aluminium.AluminiumLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this,
				"JTattoo Bernstein",
				"com.jtattoo.plaf.bernstein.BernsteinLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo Fast",
				"com.jtattoo.plaf.fast.FastLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo HiFi",
				"com.jtattoo.plaf.hifi.HiFiLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo Luna",
				"com.jtattoo.plaf.luna.LunaLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo McWin",
				"com.jtattoo.plaf.mcwin.McWinLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo Mint",
				"com.jtattoo.plaf.mint.MintLookAndFeel"));
		jtattooMenu.add(SubstanceLafChanger.getMenuItem(this, "JTattoo Smart",
				"com.jtattoo.plaf.smart.SmartLookAndFeel"));

		JMenu syntheticaMenu = new JMenu("Synthetica family");
		customLafMenus.add(syntheticaMenu);
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica base",
				"de.javasoft.plaf.synthetica.SyntheticaStandardLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica BlackMoon",
				"de.javasoft.plaf.synthetica.SyntheticaBlackMoonLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica BlackStar",
				"de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica BlueIce",
				"de.javasoft.plaf.synthetica.SyntheticaBlueIceLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica BlueMoon",
				"de.javasoft.plaf.synthetica.SyntheticaBlueMoonLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica BlueSteel",
				"de.javasoft.plaf.synthetica.SyntheticaBlueSteelLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica GreenDream",
				"de.javasoft.plaf.synthetica.SyntheticaGreenDreamLookAndFeel"));
		syntheticaMenu
				.add(SubstanceLafChanger
						.getMenuItem(this, "Synthetica OrangeMetallic",
								"de.javasoft.plaf.synthetica.SyntheticaOrangeMetallicLookAndFeel"));
		syntheticaMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Synthetica SilverMoon",
				"de.javasoft.plaf.synthetica.SyntheticaSilverMoonLookAndFeel"));

		JMenu officeMenu = new JMenu("Office family");
		customLafMenus.add(officeMenu);
		officeMenu.add(SubstanceLafChanger.getMenuItem(this, "Office 2003",
				"org.fife.plaf.Office2003.Office2003LookAndFeel"));
		officeMenu.add(SubstanceLafChanger.getMenuItem(this, "Office XP",
				"org.fife.plaf.OfficeXP.OfficeXPLookAndFeel"));
		officeMenu.add(SubstanceLafChanger.getMenuItem(this,
				"Visual Studio 2005",
				"org.fife.plaf.VisualStudio2005.VisualStudio2005LookAndFeel"));

		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "A03",
				"apprising.api.swing.plaf.a03.A03LookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Alloy",
				"com.incors.plaf.alloy.AlloyLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "FH",
				"com.shfarr.ui.plaf.fh.FhLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Hippo",
				"se.diod.hippo.plaf.HippoLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Kuntstoff",
				"com.incors.plaf.kunststoff.KunststoffLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Liquid",
				"com.birosoft.liquid.LiquidLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Lipstik",
				"com.lipstikLF.LipstikLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Metouia",
				"net.sourceforge.mlf.metouia.MetouiaLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Napkin",
				"net.sourceforge.napkinlaf.NapkinLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "NimROD",
				"com.nilo.plaf.nimrod.NimRODLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Oyoaha",
				"com.oyoaha.swing.plaf.oyoaha.OyoahaLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Pagosoft",
				"com.pagosoft.plaf.PgsLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Simple",
				"com.memoire.slaf.SlafLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Skin",
				"com.l2fprod.gui.plaf.skin.SkinLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this,
				"Smooth Metal", "smooth.metal.SmoothLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Squareness",
				"net.beeger.squareness.SquarenessLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Tiny",
				"de.muntjak.tinylookandfeel.TinyLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Tonic",
				"com.digitprop.tonic.TonicLookAndFeel"));
		customLafMenus.add(SubstanceLafChanger.getMenuItem(this, "Trendy",
				"com.Trendy.swing.plaf.TrendyLookAndFeel"));

		lafMenu.addSeparator();
		JMenu localeMenus = new JMenu("Change locale");
		lafMenu.add(localeMenus);
		// Locale changing
		JMenuItem localeArabic = new JMenuItem("Arabic Locale",
				getIcon("flag_saudi_arabia"));
		localeArabic.addActionListener(new MyLocaleChangeListener("ar", "AR",
				this));

		JMenuItem localeBulgarian = new JMenuItem("Bulgarian Locale",
				getIcon("flag_bulgaria"));
		localeBulgarian.addActionListener(new MyLocaleChangeListener("bg",
				"BG", this));

		JMenuItem localeChinese = new JMenuItem("Chinese (Simplified) Locale",
				getIcon("flag_china"));
		localeChinese.addActionListener(new MyLocaleChangeListener("zh", "CN",
				this));

		JMenuItem localeChineseHK = new JMenuItem("Chinese (Hong Kong) Locale",
				getIcon("flag_hong_kong"));
		localeChineseHK.addActionListener(new MyLocaleChangeListener("zh",
				"HK", this));

		JMenuItem localeChineseTW = new JMenuItem("Chinese (Taiwan) Locale",
				getIcon("flag_taiwan"));
		localeChineseTW.addActionListener(new MyLocaleChangeListener("zh",
				"TW", this));

		JMenuItem localeCzech = new JMenuItem("Czech Locale",
				getIcon("flag_czech_republic"));
		localeCzech.addActionListener(new MyLocaleChangeListener("cs", "CZ",
				this));

		JMenuItem localeDanish = new JMenuItem("Danish Locale",
				getIcon("flag_denmark"));
		localeDanish.addActionListener(new MyLocaleChangeListener("da", "DK",
				this));

		JMenuItem localeDutch = new JMenuItem("Dutch Locale",
				getIcon("flag_netherlands"));
		localeDutch.addActionListener(new MyLocaleChangeListener("nl", "NL",
				this));

		JMenuItem localeEnglish = new JMenuItem("English Locale",
				getIcon("flag_united_states"));
		localeEnglish.addActionListener(new MyLocaleChangeListener("en", "US",
				this));

		JMenuItem localeFinnish = new JMenuItem("Finnish Locale",
				getIcon("flag_finland"));
		localeFinnish.addActionListener(new MyLocaleChangeListener("fi", "FI",
				this));

		JMenuItem localeFrench = new JMenuItem("French Locale",
				getIcon("flag_france"));
		localeFrench.addActionListener(new MyLocaleChangeListener("fr", "FR",
				this));

		JMenuItem localeFrenchCA = new JMenuItem("French (Canada) Locale",
				getIcon("flag_canada"));
		localeFrenchCA.addActionListener(new MyLocaleChangeListener("fr", "CA",
				this));

		JMenuItem localeGerman = new JMenuItem("German Locale",
				getIcon("flag_germany"));
		localeGerman.addActionListener(new MyLocaleChangeListener("de", "DE",
				this));

		JMenuItem localeGreek = new JMenuItem("Greek Locale",
				getIcon("flag_greece"));
		localeGreek.addActionListener(new MyLocaleChangeListener("el", "GR",
				this));

		JMenuItem localeHebrew = new JMenuItem("Hebrew Locale",
				getIcon("flag_israel"));
		localeHebrew.addActionListener(new MyLocaleChangeListener("iw", "IL",
				this));

		JMenuItem localeHungarian = new JMenuItem("Hungarian Locale",
				getIcon("flag_hungary"));
		localeHungarian.addActionListener(new MyLocaleChangeListener("hu",
				"HU", this));

		JMenuItem localeItalian = new JMenuItem("Italian Locale",
				getIcon("flag_italy"));
		localeItalian.addActionListener(new MyLocaleChangeListener("it", "IT",
				this));

		JMenuItem localeJapanese = new JMenuItem("Japanese Locale",
				getIcon("flag_japan"));
		localeJapanese.addActionListener(new MyLocaleChangeListener("ja", "JP",
				this));

		JMenuItem localeNorwegian = new JMenuItem("Norwegian Locale",
				getIcon("flag_norway"));
		localeNorwegian.addActionListener(new MyLocaleChangeListener("no",
				"NO", this));

		JMenuItem localePolish = new JMenuItem("Polish Locale",
				getIcon("flag_poland"));
		localePolish.addActionListener(new MyLocaleChangeListener("pl", "PL",
				this));

		JMenuItem localePortuguese = new JMenuItem("Portuguese Locale",
				getIcon("flag_portugal"));
		localePortuguese.addActionListener(new MyLocaleChangeListener("pt",
				"PT", this));

		JMenuItem localePortugueseBR = new JMenuItem(
				"Portuguese (Brazil) Locale", getIcon("flag_brazil"));
		localePortugueseBR.addActionListener(new MyLocaleChangeListener("pt",
				"BR", this));

		JMenuItem localeRomanian = new JMenuItem("Romanian Locale",
				getIcon("flag_romania"));
		localeRomanian.addActionListener(new MyLocaleChangeListener("ro", "RO",
				this));

		JMenuItem localeRussian = new JMenuItem("Russian Locale",
				getIcon("flag_russia"));
		localeRussian.addActionListener(new MyLocaleChangeListener("ru", "RU",
				this));

		JMenuItem localeSpanish = new JMenuItem("Spanish Locale",
				getIcon("flag_spain"));
		localeSpanish.addActionListener(new MyLocaleChangeListener("es", "ES",
				this));

		JMenuItem localeSpanishMX = new JMenuItem("Spanish (Mexico) Locale",
				getIcon("flag_mexico"));
		localeSpanishMX.addActionListener(new MyLocaleChangeListener("es",
				"MX", this));

		JMenuItem localeSwedish = new JMenuItem("Swedish Locale",
				getIcon("flag_sweden"));
		localeSwedish.addActionListener(new MyLocaleChangeListener("sv", "SE",
				this));

		JMenuItem localeThai = new JMenuItem("Thai Locale",
				getIcon("flag_thailand"));
		localeThai.addActionListener(new MyLocaleChangeListener("th", "TH",
				this));

		JMenuItem localeTurkish = new JMenuItem("Turkish Locale",
				getIcon("flag_turkey"));
		localeTurkish.addActionListener(new MyLocaleChangeListener("tr", "TR",
				this));

		localeMenus.add(localeEnglish);
		localeMenus.add(localeArabic);
		localeMenus.add(localeBulgarian);
		localeMenus.add(localeChinese);
		localeMenus.add(localeChineseHK);
		localeMenus.add(localeChineseTW);
		localeMenus.add(localeCzech);
		localeMenus.add(localeDanish);
		localeMenus.add(localeDutch);
		localeMenus.add(localeFinnish);
		localeMenus.add(localeFrench);
		localeMenus.add(localeFrenchCA);
		localeMenus.add(localeGerman);
		localeMenus.add(localeGreek);
		localeMenus.add(localeHebrew);
		localeMenus.add(localeHungarian);
		localeMenus.add(localeItalian);
		localeMenus.add(localeJapanese);
		localeMenus.add(localeNorwegian);
		localeMenus.add(localePolish);
		localeMenus.add(localePortuguese);
		localeMenus.add(localePortugueseBR);
		localeMenus.add(localeRomanian);
		localeMenus.add(localeRussian);
		localeMenus.add(localeSpanish);
		localeMenus.add(localeSpanishMX);
		localeMenus.add(localeSwedish);
		localeMenus.add(localeThai);
		localeMenus.add(localeTurkish);

		jmb.add(lafMenu);

		this.setJMenuBar(jmb);

		// sample flat toolbar (does nothing)
		JToolBar toolBar = getToolbar("Flat ");
		this.add(toolBar, AKDockLayout.NORTH);

		// sample non-flat toolbar (does nothing)
		JToolBar toolBar2 = getToolbar("Non-flat ");
		toolBar2.putClientProperty(SubstanceLookAndFeel.TOOLBAR_BUTTON_FLAT,
				Boolean.FALSE);
		this.add(toolBar2, AKDockLayout.NORTH);

		final JToolBar toolBar3 = getToolbar("Translucent ");
		toolBar3.putClientProperty(SubstanceLookAndFeel.TOOLBAR_BUTTON_FLAT,
				Boolean.FALSE);
		toolBar3.putClientProperty(SubstanceLookAndFeel.BACKGROUND_COMPOSITE,
				new AlphaControlBackgroundComposite(0.5f));
		final JSlider translucencySlider = new JSlider(0, 100, 50);
		translucencySlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				toolBar3.putClientProperty(
						SubstanceLookAndFeel.BACKGROUND_COMPOSITE,
						new AlphaControlBackgroundComposite(translucencySlider
								.getValue() / 100.f));
				toolBar3.repaint();
			}
		});
		toolBar3.add(translucencySlider);
		this.add(toolBar3, AKDockLayout.NORTH);

		// register sample listeners
		SubstanceLookAndFeel
				.registerThemeChangeListener(new MyThemeChangeListener());
		SubstanceLookAndFeel
				.registerWatermarkChangeListener(new MyWatermarkChangeListener());
		SubstanceLookAndFeel
				.registerButtonShaperChangeListener(new MyButtonShaperChangeListener());
		SubstanceLookAndFeel
				.registerGradientPainterChangeListener(new MyGradientPainterChangeListener());
		SubstanceLookAndFeel
				.registerTitlePainterChangeListener(new MyTitlePainterChangeListener());
		SubstanceLookAndFeel
				.registerSkinChangeListener(new SkinChangeListener() {
					public void skinChanged() {
						TransitionLayoutManager.getInstance().track(jtp, true);
					}
				});

		TabCloseCallback closeCallbackMain = new TabCloseCallback() {
			public TabCloseKind onAreaClick(JTabbedPane tabbedPane,
					int tabIndex, MouseEvent mouseEvent) {
				if (mouseEvent.getButton() != MouseEvent.BUTTON2)
					return TabCloseKind.NONE;
				if (mouseEvent.isShiftDown()) {
					return TabCloseKind.ALL;
				}
				return TabCloseKind.THIS;
			}

			public TabCloseKind onCloseButtonClick(JTabbedPane tabbedPane,
					int tabIndex, MouseEvent mouseEvent) {
				if (mouseEvent.isAltDown()) {
					return TabCloseKind.ALL_BUT_THIS;
				}
				if (mouseEvent.isShiftDown()) {
					return TabCloseKind.ALL;
				}
				return TabCloseKind.THIS;
			}

			public String getAreaTooltip(JTabbedPane tabbedPane, int tabIndex) {
				return null;
			}

			public String getCloseButtonTooltip(JTabbedPane tabbedPane,
					int tabIndex) {
				StringBuffer result = new StringBuffer();
				result.append("<html><body>");
				result.append("Mouse click closes <b>"
						+ tabbedPane.getTitleAt(tabIndex) + "</b> tab");
				result
						.append("<br><b>Alt</b>-Mouse click closes all tabs but <b>"
								+ tabbedPane.getTitleAt(tabIndex) + "</b> tab");
				result.append("<br><b>Shift</b>-Mouse click closes all tabs");
				result.append("</body></html>");
				return result.toString();
			}
		};

		jtp.putClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_CALLBACK,
				closeCallbackMain);
		try {
			jtp.putClientProperty(LafWidget.TABBED_PANE_PREVIEW_PAINTER,
					new DefaultTabPreviewPainter() {
						@Override
						public void previewTab(JTabbedPane tabPane,
								int tabIndex, Graphics g, int x, int y, int w,
								int h) {
							if (tabPane.getComponentAt(tabIndex) instanceof MixedButtonsPanel) {
								Graphics2D graphics = (Graphics2D) g.create();
								int fontSize = Math.min(w, h) / 6;
								Font font = new Font("Arial", Font.PLAIN,
										fontSize);
								graphics.setFont(font);
								graphics.setColor(Color.black);
								graphics.setRenderingHint(
										RenderingHints.KEY_TEXT_ANTIALIASING,
										RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
								graphics.drawString("Mixed buttons", x + 5, y
										+ w / 2 - fontSize);
								graphics.drawRect(x, y, w - 1, h - 1);
								graphics.dispose();
							} else {
								super.previewTab(tabPane, tabIndex, g, x, y, w,
										h);
							}
						}
					});
		} catch (Throwable e) {
		}

		SubstanceLookAndFeel
				.registerTabCloseChangeListener(new TabCloseListener() {
					public void tabClosed(JTabbedPane tabbedPane,
							Component tabComponent) {
						out("Closed tab");
					}

					public void tabClosing(JTabbedPane tabbedPane,
							Component tabComponent) {
						out("Closing tab");
					}
				});

		SubstanceLookAndFeel.registerTabCloseChangeListener(jtp,
				new VetoableTabCloseListener() {
					public void tabClosed(JTabbedPane tabbedPane,
							Component tabComponent) {
						out("Closed tab - specific");
					}

					public void tabClosing(JTabbedPane tabbedPane,
							Component tabComponent) {
						out("Closing tab - specific");
					}

					public boolean vetoTabClosing(JTabbedPane tabbedPane,
							Component tabComponent) {
						int userCloseAnswer = JOptionPane
								.showConfirmDialog(
										Check.this,
										"Are you sure you want to close '"
												+ tabbedPane
														.getTitleAt(tabbedPane
																.indexOfComponent(tabComponent))
												+ "' tab?", "Confirm dialog",
										JOptionPane.YES_NO_OPTION);
						return (userCloseAnswer == JOptionPane.NO_OPTION);
					}
				});

		SubstanceLookAndFeel.registerTabCloseChangeListener(jtp,
				new VetoableMultipleTabCloseListener() {
					public void tabsClosed(JTabbedPane tabbedPane,
							Set<Component> tabComponents) {
						out("Closed " + tabComponents.size()
								+ " tabs - specific");
					}

					public void tabsClosing(JTabbedPane tabbedPane,
							Set<Component> tabComponents) {
						out("Closing " + tabComponents.size()
								+ " tabs - specific");
					}

					public boolean vetoTabsClosing(JTabbedPane tabbedPane,
							Set<Component> tabComponents) {
						int userCloseAnswer = JOptionPane.showConfirmDialog(
								Check.this, "Are you sure you want to close "
										+ tabComponents.size() + " tabs?",
								"Confirm dialog", JOptionPane.YES_NO_OPTION);
						return (userCloseAnswer == JOptionPane.NO_OPTION);
					}
				});

	}

	public static JButton getPill(SubstanceTheme theme1, SubstanceTheme theme2) {
		JButton result = new JButton("Pill");
		result.putClientProperty(
				SubstanceLookAndFeel.GRADIENT_PAINTER_PROPERTY,
				SpecularGradientPainter.class.getName());
		result.putClientProperty(SubstanceLookAndFeel.PAINT_ACTIVE_PROPERTY,
				Boolean.TRUE);
		result.putClientProperty(SubstanceLookAndFeel.THEME_PROPERTY,
				new SubstanceMixTheme(theme1, theme2));
		result.putClientProperty(SubstanceLookAndFeel.BUTTON_SHAPER_PROPERTY,
				StandardButtonShaper.class.getName());
		return result;
	}

	public static JButton getMultiPill(SubstanceTheme... themes) {
		JButton result = new JButton(themes.length + "Pill");
		result.putClientProperty(
				SubstanceLookAndFeel.GRADIENT_PAINTER_PROPERTY,
				SpecularGradientPainter.class.getName());
		result.putClientProperty(SubstanceLookAndFeel.PAINT_ACTIVE_PROPERTY,
				Boolean.TRUE);
		result.putClientProperty(SubstanceLookAndFeel.THEME_PROPERTY,
				new SubstanceMixTheme(themes));
		result.putClientProperty(SubstanceLookAndFeel.BUTTON_SHAPER_PROPERTY,
				StandardButtonShaper.class.getName());
		return result;
	}

	public static void main(String[] args) {
		boolean hasLafSpecified = false;
		try {
			hasLafSpecified = (System.getProperty("swing.defaultlaf") != null);
		} catch (Throwable t) {
			// JNLP sandbox
		}

		try {
			if (!hasLafSpecified) {
				out(" CREATING LAF ");
				long time0 = System.currentTimeMillis();
				LookAndFeel laf = (LookAndFeel) Class.forName(
						"org.jvnet.substance.SubstanceLookAndFeel")
						.newInstance();
				long time1 = System.currentTimeMillis();
				out(" LAF CREATED " + (time1 - time0));
				out(" SETTING LAF ");
				long time2 = System.currentTimeMillis();
				UIManager.setLookAndFeel(laf);
				long time3 = System.currentTimeMillis();
				out(" LAF SET " + (time3 - time2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		SubstanceLookAndFeel.setToUseConstantThemesOnDialogs(true);

		UIManager.put(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_PROPERTY,
				Boolean.TRUE);
		// try {
		// if (System.getProperty("substancelaf.useDecorations") == null) {
		// JFrame.setDefaultLookAndFeelDecorated(true);
		// JDialog.setDefaultLookAndFeelDecorated(true);
		// }
		// } catch (AccessControlException ace) {
		// JFrame.setDefaultLookAndFeelDecorated(true);
		// JDialog.setDefaultLookAndFeelDecorated(true);
		// }
		// System.setProperty("sun.awt.noerasebackground", "false");
		long time2 = System.currentTimeMillis();

		SubstanceLookAndFeel.addMixedTheme(new SubstanceMixTheme(
				new SubstanceAquaTheme(), new SubstanceBottleGreenTheme()));
		SubstanceLookAndFeel.addMixedThemeBy(new SubstanceBarbyPinkTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceAquaTheme(),
				new SubstanceLightAquaTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceAquaTheme(),
				new SubstanceBottleGreenTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceBarbyPinkTheme(),
				new SubstanceRaspberryTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceBottleGreenTheme(),
				new SubstanceLimeGreenTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceBrownTheme(),
				new SubstanceSunGlareTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceSunsetTheme(),
				new SubstanceOrangeTheme());

		SubstanceLookAndFeel.addMixedTheme(new SubstanceBottleGreenTheme(),
				new SubstanceLimeGreenTheme(), new SubstanceBottleGreenTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceAquaTheme(),
				new SubstanceLimeGreenTheme(), new SubstanceBottleGreenTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceBarbyPinkTheme(),
				new SubstancePurpleTheme(), new SubstanceRaspberryTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceRaspberryTheme(),
				new SubstanceSunsetTheme(), new SubstanceOrangeTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceBrownTheme(),
				new SubstanceSunGlareTheme(), new SubstanceOrangeTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceAquaTheme(),
				new SubstanceLightAquaTheme(), new SubstancePurpleTheme(),
				new SubstanceBarbyPinkTheme());
		SubstanceLookAndFeel.addMixedTheme(new SubstanceBrownTheme(),
				new SubstanceTerracottaTheme(), new SubstanceSunGlareTheme(),
				new SubstanceOrangeTheme(), new SubstanceSunsetTheme());

		// SubstanceLookAndFeel.addMixedDarkThemeBy(new
		// SubstanceCharcoalTheme());

		Check c = new Check();
		c.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				super.componentResized(e);
				((JFrame) e.getComponent()).getRootPane().repaint();
			}
		});
		c.setPreferredSize(new Dimension(820, 560));
		c.setMinimumSize(new Dimension(150, 100));
		c.pack();
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		// center the frame in the physical screen
		c.setLocation((d.width - c.getWidth()) / 2,
				(d.height - c.getHeight()) / 2);

		c.setVisible(true);
		c.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		long time3 = System.currentTimeMillis();
		out("App " + (time3 - time2));
	}

	public static void out(Object obj) {
		try {
			System.out.println(obj);
		} catch (Exception exc) {
			// ignore - is thrown on Mac in WebStart (security access)
		}
	}

	public static void setTheme(final SubstanceTheme theme) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					SubstanceLookAndFeel.setCurrentTheme(theme);
					UIManager.setLookAndFeel(new SubstanceLookAndFeel());
				} catch (Exception exc) {
					exc.printStackTrace();
				}
				for (Frame frame : Frame.getFrames())
					SwingUtilities.updateComponentTreeUI(frame);
				out(UIManager.getColor("TabbedPane.selectHighlight"));
			}
		});
	}

	public static Icon getIcon(String iconName) {
		ClassLoader cl = Check.class.getClassLoader();
		URL url = cl.getResource("test/check/icons/" + iconName + ".gif");
		if (url != null)
			return new ImageIcon(url);
		url = cl.getResource("test/check/icons/" + iconName + ".png");
		if (url != null)
			return new ImageIcon(url);
		return null;
	}

	private static JToolBar getToolbar(String label) {
		JToolBar toolBar = new JToolBar("Formatting");
		toolBar.add(new JLabel(label));

		toolBar.add(new JSeparator(SwingConstants.VERTICAL));
		toolBar.add(new JComboBox(new String[] { "aa", "bb", "cc" }));

		final JToggleButton toggleButton1 = new JToggleButton("toggle",
				new ImageIcon(SubstanceImageCreator.getBigHexaMarker(5,
						SubstanceLookAndFeel.getTheme())));
		toolBar.add(toggleButton1);
		final JToggleButton toggleButton2 = new JToggleButton(new ImageIcon(
				SubstanceImageCreator.getBigHexaMarker(8, SubstanceLookAndFeel
						.getTheme())));
		toolBar.add(toggleButton2);
		// final JToggleButton toggleButton3 = new JToggleButton(new ImageIcon(
		// SubstanceImageCreator.getBigHexaMarker(12, SubstanceLookAndFeel
		// .getTheme())));
		// toolBar.add(toggleButton3);
		final JButton button1 = new JButton("regular", new ImageIcon(
				SubstanceImageCreator.getBigHexaMarker(7, SubstanceLookAndFeel
						.getTheme())));
		button1.putClientProperty(SubstanceLookAndFeel.CORNER_RADIUS, Float
				.valueOf(5.0f));
		toolBar.add(button1);
		final JButton button2 = new JButton(new ImageIcon(SubstanceImageCreator
				.getBigHexaMarker(15, SubstanceLookAndFeel.getTheme())));
		button2.putClientProperty(SubstanceLookAndFeel.CORNER_RADIUS, Float
				.valueOf(0.0f));
		toolBar.add(button2);

		final JButton button3 = new JButton(new ImageIcon(SubstanceImageCreator
				.getBigHexaMarker(15, SubstanceLookAndFeel.getTheme())));
		button3.setEnabled(false);
		toolBar.add(button3);
		final JToggleButton toggleButton4 = new JToggleButton(new ImageIcon(
				SubstanceImageCreator.getBigHexaMarker(15, SubstanceLookAndFeel
						.getTheme())));
		toggleButton4.setEnabled(false);
		toggleButton4.setSelected(true);
		toolBar.add(toggleButton4);
		toolBar.addSeparator();

		JPanel groupPanel = new JPanel();
		BoxLayout groupLayout = new BoxLayout(groupPanel, BoxLayout.LINE_AXIS);
		groupPanel.setLayout(groupLayout);
		final JToggleButton togEast = new JToggleButton(new ImageIcon(
				SubstanceImageCreator.getBigHexaMarker(10, SubstanceLookAndFeel
						.getTheme())));
		Set<Side> rightSide = new HashSet<Side>();
		rightSide.add(Side.RIGHT);
		togEast.putClientProperty(
				SubstanceLookAndFeel.BUTTON_OPEN_SIDE_PROPERTY, rightSide);
		togEast.putClientProperty(SubstanceLookAndFeel.CORNER_RADIUS, Float
				.valueOf(3.0f));
		final JToggleButton togCenter = new JToggleButton(new ImageIcon(
				SubstanceImageCreator.getBigHexaMarker(11, SubstanceLookAndFeel
						.getTheme())));
		togCenter.putClientProperty(SubstanceLookAndFeel.CORNER_RADIUS, Float
				.valueOf(0.0f));
		togCenter.putClientProperty(
				SubstanceLookAndFeel.BUTTON_OPEN_SIDE_PROPERTY, rightSide);
		final JToggleButton togWest = new JToggleButton(new ImageIcon(
				SubstanceImageCreator.getBigHexaMarker(12, SubstanceLookAndFeel
						.getTheme())));
		togWest.putClientProperty(SubstanceLookAndFeel.BUTTON_SIDE_PROPERTY,
				SubstanceConstants.Side.LEFT.name());
		togWest.putClientProperty(SubstanceLookAndFeel.CORNER_RADIUS, Float
				.valueOf(3.0f));
		togEast.setSelected(true);
		groupPanel.add(togEast);
		groupPanel.add(togCenter);
		groupPanel.add(togWest);

		toolBar.add(groupPanel);

		SubstanceLookAndFeel
				.registerThemeChangeListener(new ThemeChangeListener() {
					public void themeChanged() {
						toggleButton1.setIcon(new ImageIcon(
								SubstanceImageCreator.getBigHexaMarker(5,
										SubstanceLookAndFeel.getTheme())));
						toggleButton2.setIcon(new ImageIcon(
								SubstanceImageCreator.getBigHexaMarker(8,
										SubstanceLookAndFeel.getTheme())));
						button1.setIcon(new ImageIcon(SubstanceImageCreator
								.getBigHexaMarker(7, SubstanceLookAndFeel
										.getTheme())));
						button2.setIcon(new ImageIcon(SubstanceImageCreator
								.getBigHexaMarker(15, SubstanceLookAndFeel
										.getTheme())));
						button3.setIcon(new ImageIcon(SubstanceImageCreator
								.getBigHexaMarker(15, SubstanceLookAndFeel
										.getTheme())));
						toggleButton4.setIcon(new ImageIcon(
								SubstanceImageCreator.getBigHexaMarker(15,
										SubstanceLookAndFeel.getTheme())));
						togEast.setIcon(new ImageIcon(SubstanceImageCreator
								.getBigHexaMarker(10, SubstanceLookAndFeel
										.getTheme())));
						togCenter.setIcon(new ImageIcon(SubstanceImageCreator
								.getBigHexaMarker(11, SubstanceLookAndFeel
										.getTheme())));
						togWest.setIcon(new ImageIcon(SubstanceImageCreator
								.getBigHexaMarker(12, SubstanceLookAndFeel
										.getTheme())));
					}
				});

		return toolBar;
	}

	public static void setTheme(final ThemeInfo themeInfo,
			final boolean useInstance) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					if (useInstance)
						SubstanceLookAndFeel.setCurrentTheme(SubstanceTheme
								.createInstance(themeInfo));
					else
						SubstanceLookAndFeel.setCurrentTheme(themeInfo
								.getClassName());
					// UIManager.setLookAndFeel(new SubstanceLookAndFeel());
				} catch (Exception exc) {
					exc.printStackTrace();
				}
				for (Frame frame : Frame.getFrames())
					SwingUtilities.updateComponentTreeUI(frame);
			}
		});
	}

	public void setSpecificTaskPane(JPanel contents, String title, Icon icon) {
		if (this.currentSpecificTaskPane != null) {
			this.taskPaneContainer.remove(this.currentSpecificTaskPane);
		}
		this.currentSpecificTaskPane = new JXTaskPane();
		this.currentSpecificTaskPane.setLayout(new BorderLayout());
		this.currentSpecificTaskPane.setTitle(title);
		this.currentSpecificTaskPane.setIcon(icon);
		contents.setOpaque(false);
		this.currentSpecificTaskPane.setOpaque(false);
		this.currentSpecificTaskPane.add(contents, BorderLayout.CENTER);

		// this.mainTaskPane.setExpanded(false);
		this.taskPaneContainer.add(this.currentSpecificTaskPane);
	}

	public void clearSpecificTaskPane() {
		if (this.currentSpecificTaskPane != null) {
			this.taskPaneContainer.remove(this.currentSpecificTaskPane);
		}
		this.currentSpecificTaskPane = null;
		// this.mainTaskPane.setExpanded(true);
	}

	public class TabSwitchListener implements ChangeListener {
		public void stateChanged(ChangeEvent e) {
			Component selected = jtp.getSelectedComponent();
			if (selected instanceof Controllable) {
				JPanel controlPanel = ((Controllable) selected)
						.getControlPanel();
				if (controlPanel == null)
					clearSpecificTaskPane();
				else
					setSpecificTaskPane(controlPanel, jtp.getTitleAt(jtp
							.getSelectedIndex()), jtp.getIconAt(jtp
							.getSelectedIndex()));
			} else {
				clearSpecificTaskPane();
			}
		}
	}
}
