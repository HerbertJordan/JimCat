/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.net.URL;

import javax.swing.*;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.layout.TransitionLayoutManager;
import org.jvnet.substance.SubstanceImageCreator;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.SkinChangeListener;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.theme.ThemeInfo;

import test.check.*;
import test.check.AKDockLayout;

public class Check2 extends JFrame {
	private JTabbedPane jtp;

	public Check2() {
		super(
				"Substance test with very very very very very very very very very very very very very very long title");

		// this.setIconImage(SubstanceImageCreator.getBigHexaMarker(6,
		// SubstanceLookAndFeel.getTheme()));
		this.setIconImage(SubstanceImageCreator.getThemeImage(new ImageIcon(
				Check2.class.getClassLoader().getResource(
						"test/resource/image-x-generic.png")),
				SubstanceLookAndFeel.getTheme(), false));
		this.setLayout(new AKDockLayout());

		this.jtp = new JTabbedPane();
		TransitionLayoutManager.getInstance().track(this.jtp, true);
		UIManager.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if ("lookAndFeel".equals(evt.getPropertyName())) {
					LookAndFeel newLaf = (LookAndFeel) evt.getNewValue();
					if (newLaf.getID().contains("Substance")) {
						if (!(jtp.getLayout() instanceof TransitionLayout)) {
							TransitionLayoutManager.getInstance().track(jtp,
									true);
						}
					} else {
						TransitionLayoutManager.getInstance().untrack(jtp);
					}
				}
			}
		});
		this.add(jtp, AKDockLayout.CENTER);

		this.setPreferredSize(new Dimension(400, 400));
		this.setSize(this.getPreferredSize());
		this.setMinimumSize(this.getPreferredSize());

		this.jtp.addTab("Combo box", getIcon("JComboBoxColor16"),
				new CombosPanel());

		JPanel checkScrollPanePanel = new JPanel();
		checkScrollPanePanel.setLayout(new BorderLayout());
		checkScrollPanePanel.add(new ScrollDemo(), BorderLayout.CENTER);
		this.jtp.addTab("Scroll pane", getIcon("JScrollPaneColor16"),
				checkScrollPanePanel);

		JPanel checkDesktopPanePanel = new JPanel();
		checkDesktopPanePanel.setLayout(new BorderLayout());
		checkDesktopPanePanel.add(new DesktopPanel(), BorderLayout.CENTER);
		this.jtp.addTab("Desktop", getIcon("JDesktopPaneColor16"),
				checkDesktopPanePanel);

		JPanel checkTextFieldsPanel = new TextFieldsPanel();
		this.jtp.addTab("Text fields", getIcon("JTextPaneColor16"),
				checkTextFieldsPanel);

		JPanel checkTablePanel = new JPanel();
		checkTablePanel.setLayout(new BorderLayout());
		checkTablePanel.add(new TablePanel(), BorderLayout.CENTER);
		this.jtp.addTab("Table", getIcon("JTableColor16"), checkTablePanel);

		JPanel checkListPanel = new JPanel();
		checkListPanel.setLayout(new BorderLayout());
		checkListPanel.add(new ListPanel(), BorderLayout.CENTER);
		this.jtp.addTab("List", getIcon("JListColor16"), checkListPanel);

		// sample menu bar
		JMenuBar jmb = new JMenuBar();

		if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
			jmb.add(SampleMenuFactory.getSkinMenu());
		}
		this.setJMenuBar(jmb);

		SubstanceLookAndFeel
				.registerSkinChangeListener(new SkinChangeListener() {
					public void skinChanged() {
						TransitionLayoutManager.getInstance().track(jtp, true);
					}
				});
	}

	public static void main(String[] args) {
		boolean hasLafSpecified = false;
		try {
			hasLafSpecified = (System.getProperty("swing.defaultlaf") != null);
		} catch (Throwable t) {
			// JNLP sandbox
		}

		try {
			if (!hasLafSpecified) {
				out(" CREATING LAF ");
				long time0 = System.currentTimeMillis();
				LookAndFeel laf = (LookAndFeel) Class
						.forName(
								"org.jvnet.substance.skin.SubstanceModerateLookAndFeel")
						.newInstance();
				long time1 = System.currentTimeMillis();
				out(" LAF CREATED " + (time1 - time0));
				out(" SETTING LAF ");
				long time2 = System.currentTimeMillis();
				UIManager.setLookAndFeel(laf);
				long time3 = System.currentTimeMillis();
				out(" LAF SET " + (time3 - time2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		UIManager.put(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_PROPERTY,
				Boolean.TRUE);
		long time2 = System.currentTimeMillis();

		Check2 c = new Check2();
		c.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				super.componentResized(e);
				((JFrame) e.getComponent()).getRootPane().repaint();
			}
		});
		c.setPreferredSize(new Dimension(800, 500));
		c.setMinimumSize(new Dimension(150, 100));
		c.pack();
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		// center the frame in the physical screen
		c.setLocation((d.width - c.getWidth()) / 2,
				(d.height - c.getHeight()) / 2);

		c.setVisible(true);
		c.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		long time3 = System.currentTimeMillis();
		out("App " + (time3 - time2));
	}

	public static void out(Object obj) {
		try {
			System.out.println(obj);
		} catch (Exception exc) {
			// ignore - is thrown on Mac in WebStart (security access)
		}
	}

	public static void setTheme(final SubstanceTheme theme) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					SubstanceLookAndFeel.setCurrentTheme(theme);
					UIManager.setLookAndFeel(new SubstanceLookAndFeel());
				} catch (Exception exc) {
					exc.printStackTrace();
				}
				for (Frame frame : Frame.getFrames())
					SwingUtilities.updateComponentTreeUI(frame);
				out(UIManager.getColor("TabbedPane.selectHighlight"));
			}
		});
	}

	public static Icon getIcon(String iconName) {
		ClassLoader cl = Check2.class.getClassLoader();
		URL url = cl.getResource("test/check/icons/" + iconName + ".gif");
		if (url != null)
			return new ImageIcon(url);
		url = cl.getResource("test/check/icons/" + iconName + ".png");
		if (url != null)
			return new ImageIcon(url);
		return null;
	}

	public static void setTheme(final ThemeInfo themeInfo,
			final boolean useInstance) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					if (useInstance)
						SubstanceLookAndFeel.setCurrentTheme(SubstanceTheme
								.createInstance(themeInfo));
					else
						SubstanceLookAndFeel.setCurrentTheme(themeInfo
								.getClassName());
					// UIManager.setLookAndFeel(new SubstanceLookAndFeel());
				} catch (Exception exc) {
					exc.printStackTrace();
				}
				for (Frame frame : Frame.getFrames())
					SwingUtilities.updateComponentTreeUI(frame);
			}
		});
	}
}
