package test;

import java.awt.FlowLayout;

import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.theme.SubstanceEbonyTheme;

public class Walkthrough extends JFrame {
	public Walkthrough() {
		super("Sample app");
		this.setLayout(new FlowLayout());
		this.add(new JButton("button"));
		this.add(new JCheckBox("check"));
		this.add(new JLabel("label"));

		this.pack();
		this.setSize(this.getPreferredSize());
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// try {
		// UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		// SubstanceLookAndFeel.setCurrentTheme(new SubstanceEbonyTheme());
		// UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		// } catch (UnsupportedLookAndFeelException ulafe) {
		// System.out.println("Substance failed to set");
		// }
		//
		Walkthrough w = new Walkthrough();
		w.setVisible(true);
	}
}