package test;

import java.awt.*;

import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;

import com.sun.java.swing.plaf.windows.WindowsLookAndFeel;

public class SliderTest extends JFrame {
	public SliderTest() {
		this.setLayout(new FlowLayout());
		JSlider slider = new JSlider(JSlider.VERTICAL, 0, 100, 50);
		this.add(slider);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
	}
	
	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		new SliderTest().setVisible(true);
	}
}
