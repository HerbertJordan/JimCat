package test;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.plaf.metal.MetalLookAndFeel;

import org.jvnet.substance.SubstanceLookAndFeel;

public class RoTextField extends JFrame {
	public RoTextField() {
		this.setLayout(new FlowLayout());
		JFormattedTextField jtf = new JFormattedTextField();
		jtf.setColumns(20);
		jtf.setEditable(false);
		this.add(jtf);

		JButton metal = new JButton("Metal");
		metal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						try {
							UIManager.setLookAndFeel(new MetalLookAndFeel());
							SwingUtilities
									.updateComponentTreeUI(RoTextField.this);
						} catch (Exception exc) {
						}
					}
				});
			}
		});
		this.add(metal);
		this.setSize(300, 100);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) throws Exception {
		//UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new RoTextField().setVisible(true);
			}
		});
	}
}
