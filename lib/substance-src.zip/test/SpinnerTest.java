package test;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.SubstanceAbstractSkin;

public class SpinnerTest extends JFrame {
	public SpinnerTest() {
		this.setLayout(new FlowLayout());
		JSpinner spinner = new JSpinner();
		SpinnerNumberModel snm = new SpinnerNumberModel();
		snm.setMinimum(0);
		snm.setMaximum(100);
		snm.setValue(50);
		spinner.setModel(snm);

		this.add(spinner);
		this.setSize(200, 100);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		new SpinnerTest().setVisible(true);
	}
}
