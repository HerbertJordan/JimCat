package test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.UIManager;
import javax.swing.table.TableColumn;

import org.jvnet.lafwidget.LafWidget;

public class TableComboCompletion extends javax.swing.JDialog {
	private javax.swing.JTable mTable;

	public TableComboCompletion(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		initComponents();
		TableColumn comboColumn = mTable.getColumnModel().getColumn(1);
		DefaultComboBoxModel comboModel = new DefaultComboBoxModel();
		comboModel.addElement("");
		comboModel.addElement("abc");
		comboModel.addElement("abcd");
		comboModel.addElement("abcde");
		comboModel.addElement("def");
		comboModel.addElement("defg");
		comboModel.addElement("defgh");

		JComboBox editComboBox = new JComboBox(comboModel);
		editComboBox.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				System.out.println(evt.getPropertyName() + ":"
						+ evt.getOldValue() + "->" + evt.getNewValue());
			}
		});
		editComboBox.setEditable(true);
//		editComboBox.putClientProperty(LafWidget.COMBO_BOX_NO_AUTOCOMPLETION,
//				Boolean.TRUE);
		comboColumn.setCellEditor(new DefaultCellEditor(editComboBox));
	}

	private void initComponents() {
		javax.swing.JScrollPane jScrollPane1;

		jScrollPane1 = new javax.swing.JScrollPane();
		mTable = new javax.swing.JTable();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		mTable.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {
				{ "r1c1", "r1c2", "r1c3", "r1c4" },
				{ "r2c1", "r2c2", "r2c3", "r2c4" },
				{ "r3c1", "r3c2", "r3c3", "r3c4" },
				{ "r4c1", "r4c2", "r4c3", "r4c4" } }, new String[] { "Title 1",
				"Title 2", "Title 3", "Title 4" }) {
			Class[] types = new Class[] { java.lang.String.class,
					java.lang.String.class, java.lang.String.class,
					java.lang.String.class };

			public Class getColumnClass(int columnIndex) {
				return types[columnIndex];
			}
		});
		jScrollPane1.setViewportView(mTable);

		getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

		pack();
	}

	public static void main(String args[]) {
		try {
			UIManager
					.setLookAndFeel("org.jvnet.substance.SubstanceLookAndFeel");
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					new TableComboCompletion(new javax.swing.JFrame(), true)
							.setVisible(true);
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
