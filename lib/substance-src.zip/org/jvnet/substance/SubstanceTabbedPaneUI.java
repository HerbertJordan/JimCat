/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.text.View;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.LafConstants;
import org.jvnet.lafwidget.utils.FadeTracker.*;
import org.jvnet.substance.button.*;
import org.jvnet.substance.color.*;
import org.jvnet.substance.painter.ControlBackgroundComposite;
import org.jvnet.substance.painter.SubstanceGradientPainter;
import org.jvnet.substance.scroll.SubstanceScrollButton;
import org.jvnet.substance.tabbed.*;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.*;
import org.jvnet.substance.utils.SubstanceConstants.*;
import org.jvnet.substance.utils.icon.*;

/**
 * UI for tabbed panes in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceTabbedPaneUI extends BasicTabbedPaneUI {
	/**
	 * Default size of the tab close button.
	 */
	public static final int TAB_DEFAULT_BUTTON_DIMENSION = 11;

	/**
	 * Current mouse location.
	 */
	protected Point substanceMouseLocation;

	/**
	 * Hash map for storing already computed backgrounds.
	 */
	private static Map<String, BufferedImage> backgroundMap = new HashMap<String, BufferedImage>();

	/**
	 * Hash map for storing already computed backgrounds.
	 */
	private static Map<String, BufferedImage> closeButtonMap = new HashMap<String, BufferedImage>();

	/**
	 * Key - tab component. Value - ID of the (looping) fade transition that
	 * animates the tab component when it's marked as modified (with
	 * {@link SubstanceLookAndFeel#WINDOW_MODIFIED} property).
	 */
	private Map<Component, Long> fadeModifiedIds;

	/**
	 * Key - tab component. Value - ID of the (looping) fade transition that
	 * animates the tab component when it has icon animation (with
	 * {@link SubstanceLookAndFeel#TABBED_PANE_TAB_ANIMATION_KIND} property).
	 */
	private Map<Component, Long> fadeIconIds;

	/**
	 * Resets image maps (used when setting new theme).
	 * 
	 * @see SubstanceLookAndFeel#setCurrentTheme(String)
	 * @see SubstanceLookAndFeel#setCurrentTheme(SubstanceTheme)
	 */
	public static synchronized void reset() {
		SubstanceTabbedPaneUI.backgroundMap.clear();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent tabPane) {
		SubstanceTabbedPaneUI result = new SubstanceTabbedPaneUI();
		// Object proxy = UIDelegateProxy.newInstance(result);
		// SubstanceTabbedPaneUI sProxy = (SubstanceTabbedPaneUI)proxy;
		return result;
	}

	/**
	 * Mouse handler for rollover effects.
	 */
	protected MouseRolloverHandler substanceRolloverHandler;

	/**
	 * Tracks changes to the tabbed pane contents. Each tab component is tracked
	 * for changes on
	 * {@link SubstanceLookAndFeel#TABBED_PANE_TAB_ANIMATION_KIND} and
	 * {@link SubstanceLookAndFeel#WINDOW_MODIFIED} properties.
	 */
	protected TabbedContainerListener substanceContainerListener;

	/**
	 * Listener for animation effects on tab selection.
	 */
	protected ChangeListener substanceSelectionListener;

	/**
	 * Background delegate.
	 */
	private SubstanceFillBackgroundDelegate bgDelegate;

	/**
	 * Tracks changes to the tabbed pane contents. Each tab component is tracked
	 * for changes on
	 * {@link SubstanceLookAndFeel#TABBED_PANE_TAB_ANIMATION_KIND} and
	 * {@link SubstanceLookAndFeel#WINDOW_MODIFIED} properties.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected final class TabbedContainerListener extends ContainerAdapter {
		/**
		 * Property change listeners on the tab components.
		 * 
		 * Fixes defect 135 - memory leaks on tabbed panes.
		 */
		private Map<Component, List<PropertyChangeListener>> listeners = new HashMap<Component, List<PropertyChangeListener>>();

		/**
		 * Creates a new container listener.
		 */
		public TabbedContainerListener() {
		}

		/**
		 * Tracks all existing tab component.
		 */
		protected void trackExistingTabs() {
			// register listeners on all existing tabs
			for (int i = 0; i < SubstanceTabbedPaneUI.this.tabPane
					.getTabCount(); i++) {
				this.trackTab(SubstanceTabbedPaneUI.this.tabPane
						.getComponentAt(i));
			}
		}

		/**
		 * Tracks changes in a single tab component.
		 * 
		 * @param tabComponent
		 *            Tab component.
		 */
		protected void trackTab(final Component tabComponent) {
			if (tabComponent == null)
				return;

			PropertyChangeListener tabModifiedListener = new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					if (SubstanceLookAndFeel.WINDOW_MODIFIED.equals(evt
							.getPropertyName())) {
						Object oldValue = evt.getOldValue();
						Object newValue = evt.getNewValue();
						boolean wasModified = Boolean.TRUE.equals(oldValue);
						boolean isModified = Boolean.TRUE.equals(newValue);

						if (wasModified) {
							if (!isModified) {
								long fadeInstanceId = fadeModifiedIds
										.get(tabComponent);
								FadeTracker.getInstance().cancelFadeInstance(
										fadeInstanceId);
							}
						} else {
							if (isModified) {
								int tabIndex = tabPane
										.indexOfComponent(tabComponent);
								if (tabIndex >= 0) {
									long fadeInstanceId = FadeTracker
											.getInstance()
											.trackFadeLooping(
													ModifiedFadeStep.MARKED_MODIFIED_FADE_KIND,
													new LafConstants.AnimationKind(
															new ModifiedFadeStep(),
															"modified"),
													tabPane, tabIndex, false,
													getCallback(tabIndex), true);
									fadeModifiedIds.put(tabComponent,
											fadeInstanceId);
								}
							}
						}
					}
					if (SubstanceLookAndFeel.TABBED_PANE_TAB_ANIMATION_KIND
							.equals(evt.getPropertyName())) {
						Object oldValue = evt.getOldValue();
						if (oldValue != null) {
							long fadeInstanceId = fadeIconIds.get(tabComponent);
							FadeTracker.getInstance().requestStopOnCycleBreak(
									fadeInstanceId);
						} else {
							int tabIndex = tabPane
									.indexOfComponent(tabComponent);
							TabIconAnimationCallback callback = new TabIconAnimationCallback(
									tabPane, tabIndex);
							callback.startIconAnimation((TabAnimationKind) evt
									.getNewValue());
						}
					}
				}
			};
			tabComponent.addPropertyChangeListener(tabModifiedListener);
			// fix for defect 135 - memory leaks on tabbed panes
			List<PropertyChangeListener> currList = this.listeners
					.get(tabComponent);
			if (currList == null)
				currList = new LinkedList<PropertyChangeListener>();
			currList.add(tabModifiedListener);
			// System.err.println(this.hashCode() + " adding for " +
			// tabComponent.hashCode());
			this.listeners.put(tabComponent, currList);
			// Fix for defect 104 - a 'modified' component is added to
			// the tabbed pane. In this case it should be animated from the
			// beginning.
			if (tabComponent instanceof JComponent) {
				if (Boolean.TRUE
						.equals(((JComponent) tabComponent)
								.getClientProperty(SubstanceLookAndFeel.WINDOW_MODIFIED))) {
					// TabPulseTracker.update(SubstanceTabbedPaneUI.this.tabPane,
					// tabComponent);

					int tabIndex = tabPane.indexOfComponent(tabComponent);
					if (tabIndex >= 0) {
						long fadeInstanceId = FadeTracker
								.getInstance()
								.trackFadeLooping(
										ModifiedFadeStep.MARKED_MODIFIED_FADE_KIND,
										new LafConstants.AnimationKind(
												new ModifiedFadeStep(),
												"modified"), tabPane, tabIndex,
										false, getCallback(tabIndex), true);
						fadeModifiedIds.put(tabComponent, fadeInstanceId);
					}
				}
			}
		}

		/**
		 * Stops tracking changes to a single tab component.
		 * 
		 * @param tabComponent
		 *            Tab component.
		 */
		protected void stopTrackTab(final Component tabComponent) {
			if (tabComponent == null)
				return;

			List<PropertyChangeListener> pclList = this.listeners
					.get(tabComponent);
			if (pclList != null) {
				for (PropertyChangeListener pcl : pclList)
					tabComponent.removePropertyChangeListener(pcl);
			}

			this.listeners.put(tabComponent, null);
		}

		/**
		 * Stops tracking all tab components.
		 */
		protected void stopTrackExistingTabs() {
			// register listeners on all existing tabs
			for (int i = 0; i < SubstanceTabbedPaneUI.this.tabPane
					.getTabCount(); i++) {
				this.stopTrackTab(SubstanceTabbedPaneUI.this.tabPane
						.getComponentAt(i));
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.ContainerAdapter#componentAdded(java.awt.event.ContainerEvent)
		 */
		@Override
		public void componentAdded(final ContainerEvent e) {
			final Component tabComponent = e.getChild();
			if (tabComponent instanceof UIResource)
				return;
			this.trackTab(tabComponent);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.ContainerAdapter#componentRemoved(java.awt.event.ContainerEvent)
		 */
		@Override
		public void componentRemoved(ContainerEvent e) {
			// fix for defect 135 - memory leaks on tabbed panes
			final Component tabComponent = e.getChild();
			if (tabComponent == null)
				return;
			// System.err.println(this.hashCode() + " removing for " +
			// tabComponent.hashCode());
			if (tabComponent instanceof UIResource)
				return;
			for (PropertyChangeListener pcl : this.listeners.get(tabComponent))
				tabComponent.removePropertyChangeListener(pcl);
			this.listeners.get(tabComponent).clear();
			this.listeners.remove(tabComponent);
			//this.cleanListeners(tabComponent);
		}

		/**
		 * Cleans all listeners on the component.
		 * 
		 * @param comp
		 *            Component.
		 */
		private void cleanListeners(Component comp) {
			// if (comp instanceof JTabbedPane) {
			// JTabbedPane jtp = (JTabbedPane)comp;
			// SubstanceTabbedPaneUI ui = (SubstanceTabbedPaneUI)jtp
			// .getUI();
			// // TabbedContainerListener tcl = ui.containerListener;
			// // tcl.stopTrackExistingTabs();
			// // tcl.listeners.clear();
			// // //jtp.removeContainerListener(tcl);
			// //
			//				
			// ui.uninstallUI(jtp);
			// }

			if (comp instanceof Container) {
				Container cont = (Container) comp;
				for (int i = 0; i < cont.getComponentCount(); i++) {
					this.cleanListeners(cont.getComponent(i));
				}
			}
			if (comp instanceof JTabbedPane) {
				JTabbedPane jtp = (JTabbedPane) comp;
				SubstanceTabbedPaneUI ui = (SubstanceTabbedPaneUI) jtp.getUI();
				// TabbedContainerListener tcl = ui.containerListener;
				// tcl.stopTrackExistingTabs();
				// tcl.listeners.clear();
				// //jtp.removeContainerListener(tcl);
				//				

				ui.uninstallUI(jtp);
			}
		}
	}

	/**
	 * Listener for rollover animation effects.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class MouseRolloverHandler implements MouseListener,
			MouseMotionListener {
		/**
		 * Index of the tab that was rolloed over on the previous mouse event.
		 */
		int prevRolledOver = -1;

		/**
		 * Indicates whether the previous mouse event was located in a close
		 * button.
		 */
		boolean prevInCloseButton = false;

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
		 */
		public void mouseClicked(final MouseEvent e) {
			final int tabIndex = SubstanceTabbedPaneUI.this.tabForCoordinate(
					SubstanceTabbedPaneUI.this.tabPane, e.getX(), e.getY());
			TabCloseCallback closeCallback = SubstanceCoreUtilities
					.getTabCloseCallback(e, SubstanceTabbedPaneUI.this.tabPane,
							tabIndex);
			if (closeCallback == null)
				return;

			final TabCloseKind tabCloseKind = closeCallback.onAreaClick(
					SubstanceTabbedPaneUI.this.tabPane, tabIndex, e);
			if (tabCloseKind == TabCloseKind.NONE)
				return;

			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					SubstanceTabbedPaneUI.this.tryCloseTabs(tabIndex,
							tabCloseKind);
				}
			});
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
		 */
		public void mouseDragged(MouseEvent e) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
		 */
		public void mouseEntered(MouseEvent e) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
		 */
		public void mouseReleased(MouseEvent e) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
		 */
		public void mouseMoved(MouseEvent e) {
			if (e.getSource() != SubstanceTabbedPaneUI.this.tabPane)
				return;
			if (SubstanceLookAndFeel
					.toIgnoreAnimation(SubstanceTabbedPaneUI.this.tabPane
							.getClass()))
				return;

			SubstanceTabbedPaneUI.this.substanceMouseLocation = e.getPoint();
			int currRolledOver = SubstanceTabbedPaneUI.this.getRolloverTab();
			TabCloseCallback tabCloseCallback = SubstanceCoreUtilities
					.getTabCloseCallback(e, SubstanceTabbedPaneUI.this.tabPane,
							currRolledOver);
			if (currRolledOver == this.prevRolledOver) {
				if (currRolledOver >= 0) {
					Rectangle rect = new Rectangle();
					rect = SubstanceTabbedPaneUI.this.getTabBounds(
							currRolledOver, rect);
					Rectangle close = SubstanceTabbedPaneUI.this
							.getCloseButtonRectangleForEvents(currRolledOver,
									rect.x, rect.y, rect.width, rect.height);
					// System.out.println("move " + rect + " " + close + " "
					// + mouseLocation);
					boolean inCloseButton = close.contains(e.getPoint());
					if (this.prevInCloseButton == inCloseButton)
						return;
					this.prevInCloseButton = inCloseButton;
					if (tabCloseCallback != null) {
						if (inCloseButton) {
							SubstanceTabbedPaneUI.this.tabPane
									.setToolTipTextAt(
											currRolledOver,
											tabCloseCallback
													.getCloseButtonTooltip(
															SubstanceTabbedPaneUI.this.tabPane,
															currRolledOver));
						} else {
							SubstanceTabbedPaneUI.this.tabPane
									.setToolTipTextAt(
											currRolledOver,
											tabCloseCallback
													.getAreaTooltip(
															SubstanceTabbedPaneUI.this.tabPane,
															currRolledOver));
						}
					}
					if ((currRolledOver >= 0)
							&& (currRolledOver < SubstanceTabbedPaneUI.this.tabPane
									.getTabCount())) {
						FadeTrackerCallback currCallback = SubstanceTabbedPaneUI.this
								.getCallback(currRolledOver);
						currCallback.fadePerformed(FadeKind.ROLLOVER, 0.0f);
					}
				}
			} else {
				FadeTracker fadeTracker = FadeTracker.getInstance();
				if ((this.prevRolledOver >= 0)
						&& (this.prevRolledOver < SubstanceTabbedPaneUI.this.tabPane
								.getTabCount())
						&& SubstanceTabbedPaneUI.this.tabPane
								.isEnabledAt(this.prevRolledOver)) {
					// System.out.println("Fading out " + prevRolledOver);
					fadeTracker.trackFadeOut(FadeKind.ROLLOVER,
							SubstanceTabbedPaneUI.this.tabPane,
							this.prevRolledOver, true, new TabRepaintCallback(
									SubstanceTabbedPaneUI.this.tabPane,
									this.prevRolledOver));
				}
				if ((currRolledOver >= 0)
						&& (currRolledOver < SubstanceTabbedPaneUI.this.tabPane
								.getTabCount())
						&& SubstanceTabbedPaneUI.this.tabPane
								.isEnabledAt(currRolledOver)) {
					fadeTracker.trackFadeIn(FadeKind.ROLLOVER,
							SubstanceTabbedPaneUI.this.tabPane, currRolledOver,
							true, new TabRepaintCallback(
									SubstanceTabbedPaneUI.this.tabPane,
									currRolledOver));
				}
			}
			this.prevRolledOver = currRolledOver;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
		 */
		public void mouseExited(MouseEvent e) {
			// fix for bug 69 - non-selected non-rollover tab
			// may remain with close button after moving mouse quickly
			// to inner JTabbedPane
			if ((this.prevRolledOver >= 0)
					&& (this.prevRolledOver < SubstanceTabbedPaneUI.this.tabPane
							.getTabCount())
					&& SubstanceTabbedPaneUI.this.tabPane
							.isEnabledAt(this.prevRolledOver)) {
				// only the previously rolled-over tab needs to be
				// repainted (fade-out) instead of repainting the
				// whole tab as before.
				FadeTracker fadeTracker = FadeTracker.getInstance();
				fadeTracker.trackFadeOut(FadeKind.ROLLOVER,
						SubstanceTabbedPaneUI.this.tabPane,
						this.prevRolledOver, true, new TabRepaintCallback(
								SubstanceTabbedPaneUI.this.tabPane,
								this.prevRolledOver));
			}
			this.prevRolledOver = -1;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
		 */
		public void mousePressed(final MouseEvent e) {
			final int tabIndex = SubstanceTabbedPaneUI.this.tabForCoordinate(
					SubstanceTabbedPaneUI.this.tabPane, e.getX(), e.getY());
			if (SubstanceCoreUtilities.hasCloseButton(
					SubstanceTabbedPaneUI.this.tabPane, tabIndex)) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						if ((tabIndex >= 0)
								&& SubstanceTabbedPaneUI.this.tabPane
										.isEnabledAt(tabIndex)) {
							Rectangle rect = new Rectangle();
							rect = SubstanceTabbedPaneUI.this.getTabBounds(
									tabIndex, rect);

							Rectangle close = SubstanceTabbedPaneUI.this
									.getCloseButtonRectangleForEvents(tabIndex,
											rect.x, rect.y, rect.width,
											rect.height);
							// System.out.println("press " + close + " "
							// + e.getPoint());
							if (close.contains(e.getPoint())) {
								TabCloseCallback closeCallback = SubstanceCoreUtilities
										.getTabCloseCallback(
												e,
												SubstanceTabbedPaneUI.this.tabPane,
												tabIndex);

								TabCloseKind tabCloseKind = (closeCallback == null) ? TabCloseKind.THIS
										: closeCallback
												.onCloseButtonClick(
														SubstanceTabbedPaneUI.this.tabPane,
														tabIndex, e);

								SubstanceTabbedPaneUI.this.tryCloseTabs(
										tabIndex, tabCloseKind);
							}
						}
					}
				});
			}
		}
	}

	/**
	 * Creates the new UI delegate.
	 */
	public SubstanceTabbedPaneUI() {
		super();
		this.bgDelegate = new SubstanceFillBackgroundDelegate();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		// Install listener to repaint the tabbed pane
		// on mouse move (for rollover effects).
		this.substanceRolloverHandler = new MouseRolloverHandler();
		this.tabPane.addMouseMotionListener(this.substanceRolloverHandler);
		this.tabPane.addMouseListener(this.substanceRolloverHandler);

		// Add container listener to wire property change listener
		// on each tab in the tabbed pane.
		this.substanceContainerListener = new TabbedContainerListener();
		this.substanceContainerListener.trackExistingTabs();

		for (int i = 0; i < this.tabPane.getTabCount(); i++) {
			Component tabComp = this.tabPane.getComponentAt(i);
			if (SubstanceCoreUtilities.isTabModified(tabComp)) {
				// TabPulseTracker.update(this.tabPane, tabComp);
				long fadeInstanceId = FadeTracker.getInstance()
						.trackFadeLooping(
								ModifiedFadeStep.MARKED_MODIFIED_FADE_KIND,
								new LafConstants.AnimationKind(
										new ModifiedFadeStep(), "modified"),
								tabPane, i, false, getCallback(i), true);
				fadeModifiedIds.put(tabComp, fadeInstanceId);
			}
			TabAnimationKind animKind = SubstanceCoreUtilities
					.getTabAnimationKind(tabComp);
			if (animKind != null) {
				TabIconAnimationCallback callback = new TabIconAnimationCallback(
						this.tabPane, i);
				callback.startIconAnimation(animKind);
			}
		}

		this.tabPane.addContainerListener(this.substanceContainerListener);

		this.substanceSelectionListener = new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						if (SubstanceTabbedPaneUI.this.tabPane == null)
							return;
						int selected = SubstanceTabbedPaneUI.this.tabPane
								.getSelectedIndex();
						FadeTracker fadeTracker = FadeTracker.getInstance();
						if ((selected >= 0)
								&& (selected < SubstanceTabbedPaneUI.this.tabPane
										.getTabCount())
								&& SubstanceTabbedPaneUI.this.tabPane
										.isEnabledAt(selected)) {
							fadeTracker.trackFadeIn(FadeKind.ROLLOVER,
									SubstanceTabbedPaneUI.this.tabPane,
									selected, true, new TabRepaintCallback(
											SubstanceTabbedPaneUI.this.tabPane,
											selected));
						}
					}
				});
			}
		};
		this.tabPane.getModel().addChangeListener(
				this.substanceSelectionListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		super.uninstallListeners();
		if (this.substanceRolloverHandler != null) {
			this.tabPane
					.removeMouseMotionListener(this.substanceRolloverHandler);
			this.tabPane.removeMouseListener(this.substanceRolloverHandler);
			this.substanceRolloverHandler = null;
		}
		if (this.substanceContainerListener != null) {
			for (Map.Entry<Component, List<PropertyChangeListener>> entry : this.substanceContainerListener.listeners
					.entrySet()) {
				Component comp = entry.getKey();
				// System.out.println(this.containerListener.hashCode() + "
				// removing all for " + comp.hashCode());
				for (PropertyChangeListener pcl : entry.getValue()) {
					comp.removePropertyChangeListener(pcl);
				}
			}
			this.substanceContainerListener.listeners.clear();

			this.tabPane
					.removeContainerListener(this.substanceContainerListener);
			this.substanceContainerListener = null;
		}
		this.tabPane.getModel().removeChangeListener(
				this.substanceSelectionListener);
		this.substanceSelectionListener = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#installDefaults()
	 */
	@Override
	protected void installDefaults() {
		super.installDefaults();
		this.fadeModifiedIds = new HashMap<Component, Long>();
		this.fadeIconIds = new HashMap<Component, Long>();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#uninstallDefaults()
	 */
	@Override
	protected void uninstallDefaults() {
		this.fadeModifiedIds.clear();
		this.fadeIconIds.clear();
		super.uninstallDefaults();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		for (Map.Entry<Component, Long> fadeIconInstanceEntry : this.fadeIconIds
				.entrySet()) {
			int tabIndex = this.tabPane.indexOfComponent(fadeIconInstanceEntry
					.getKey());
			Icon icon = this.tabPane.getIconAt(tabIndex);
			if (icon instanceof IconWrapper) {
				this.tabPane.setIconAt(tabIndex, ((IconWrapper) icon)
						.getOriginalIcon());
			}
			FadeTracker.getInstance().cancelFadeInstance(
					fadeIconInstanceEntry.getValue());
		}
		super.uninstallUI(c);
	}

	/**
	 * Retrieves tab background.
	 * 
	 * @param width
	 *            Tab width.
	 * @param height
	 *            Tab height.
	 * @param isSelected
	 *            Indication whether the tab is selected.
	 * @param cyclePos
	 *            Tab cycle position (for rollover effects).
	 * @param tabPlacement
	 *            Tab placement.
	 * @param side
	 *            Tab open side.
	 * @param colorScheme
	 *            Color scheme for coloring the background.
	 * @param colorScheme2
	 *            Second color scheme for coloring the background.
	 * @return Tab background of specified parameters.
	 */
	private static synchronized BufferedImage getTabBackground(int width,
			int height, boolean isSelected, float cyclePos, int tabPlacement,
			SubstanceConstants.Side side, ColorScheme colorScheme,
			ColorScheme colorScheme2) {
		SubstanceGradientPainter gradientPainter = SubstanceLookAndFeel
				.getCurrentGradientPainter();
		if (gradientPainter == null)
			return null;

		int dx = 0;
		int ox = 0;
		int oy = 0;
		int dy = 0;
		switch (side) {
		case BOTTOM:
			dy = 2;
			break;
		case TOP:
			dy = 2;
			oy = 2;
			break;
		case RIGHT:
			dx = 2;
			break;
		case LEFT:
			dx = 2;
			ox = -2;
		}

		SubstanceButtonShaper shaper = SubstanceLookAndFeel
				.getCurrentButtonShaper();
		String key = (width + dx) + ":" + (height + dy) + ":" + isSelected
				+ ":" + cyclePos + ":" + side.toString() + ":"
				+ gradientPainter.getDisplayName() + ":"
				+ shaper.getDisplayName() + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme) + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme2);
		BufferedImage result = SubstanceTabbedPaneUI.backgroundMap.get(key);
		if (result == null) {
			Set<Side> straightSides = new HashSet<Side>();
			straightSides.add(side);

			int cornerRadius = height / 3;
			if (shaper instanceof ClassicButtonShaper) {
				cornerRadius = 2;
				if ((tabPlacement == TOP) || (tabPlacement == BOTTOM))
					width -= 1;
				else
					height -= 1;
			}

			GeneralPath contour = BaseButtonShaper.getBaseOutline(width + dx,
					height + dy, cornerRadius, straightSides);

			result = gradientPainter.getContourBackground(width + dx, height
					+ dy, contour, false, colorScheme, colorScheme2, cyclePos,
					true, colorScheme != colorScheme2);

			BufferedImage finalImage = SubstanceCoreUtilities.getBlankImage(
					width, height);
			Graphics2D finalGraphics = (Graphics2D) finalImage.getGraphics();
			finalGraphics.drawImage(result, ox, oy, null);
			SubstanceTabbedPaneUI.backgroundMap.put(key, finalImage);

			// fix for defect 138
			result = finalImage;
		}
		return result;
	}

	/**
	 * Retrieves the image of the close button.
	 * 
	 * @param width
	 *            Close button width.
	 * @param height
	 *            Close button height.
	 * @param cyclePos10
	 *            Tab cycle position (for rollover effects).
	 * @param toPaintBackground
	 *            Indication whether the button background (including contour)
	 *            needs to be painted.
	 * @param colorScheme
	 *            Color scheme for coloring the background.
	 * @param colorScheme2
	 *            Second color scheme for coloring the background.
	 * @return Image of the close button of specified parameters.
	 */
	private static synchronized BufferedImage getCloseButtonImage(int width,
			int height, float cyclePos10, boolean toPaintBackground,
			ColorScheme colorScheme, ColorScheme colorScheme2) {
		SubstanceGradientPainter gradientPainter = SubstanceLookAndFeel
				.getCurrentGradientPainter();
		if (gradientPainter == null)
			return null;

		String key = width + ":" + height + ":" + toPaintBackground + ":"
				+ cyclePos10 + ":" + gradientPainter.getDisplayName() + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme) + ":"
				+ SubstanceCoreUtilities.getSchemeId(colorScheme2);
		BufferedImage result = SubstanceTabbedPaneUI.closeButtonMap.get(key);
		if (result == null) {
			result = SubstanceCoreUtilities.getBlankImage(width, height);
			Graphics2D finalGraphics = (Graphics2D) result.getGraphics();
			finalGraphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);

			if (toPaintBackground) {
				GeneralPath contour = BaseButtonShaper.getBaseOutline(width,
						height, 1, null);
				BufferedImage background = gradientPainter
						.getContourBackground(width, height, contour, false,
								colorScheme, colorScheme2, cyclePos10, true,
								colorScheme != colorScheme2);
				finalGraphics.drawImage(background, 0, 0, null);
			}

			finalGraphics.setColor(colorScheme.getForegroundColor());
			finalGraphics.setStroke(new BasicStroke(1.2f));
			finalGraphics.drawLine(2, 2, width - 3, height - 3);
			finalGraphics.drawLine(2, height - 3, width - 3, 2);

			SubstanceTabbedPaneUI.closeButtonMap.put(key, result);
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#paintTabBackground(java.awt.Graphics,
	 *      int, int, int, int, int, int, boolean)
	 */
	@Override
	protected void paintTabBackground(Graphics g, int tabPlacement,
			int tabIndex, int x, int y, int w, int h, boolean isSelected) {

		BufferedImage backgroundImage = null;
		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		graphics.setComposite(TransitionLayout.getAlphaComposite(this.tabPane));

		// fix for defect 138
		graphics.clip(new Rectangle(x, y, w, h));

		boolean isRollover = (this.getRolloverTab() == tabIndex);
		boolean isEnabled = this.tabPane.isEnabledAt(tabIndex);
		Component tabComponent = this.tabPane.getComponentAt(tabIndex);

		ColorScheme colorScheme = SubstanceCoreUtilities.getActiveScheme(
				tabComponent, this.tabPane);
		boolean hasActivePresence = isSelected || (isRollover && isEnabled);
		if (!isSelected && !isRollover)
			colorScheme = SubstanceCoreUtilities.getDefaultScheme(tabComponent,
					this.tabPane);
		if (!isEnabled)
			colorScheme = SubstanceCoreUtilities.getDisabledScheme(
					tabComponent, this.tabPane);
		float cyclePos = (isRollover && isEnabled) ? 5 : 0;

		ColorScheme colorScheme2 = colorScheme;
		// check if have windowModified property
		Component comp = this.tabPane.getComponentAt(tabIndex);
		boolean isWindowModified = SubstanceCoreUtilities.isTabModified(comp);
		boolean toMarkModifiedCloseButton = SubstanceCoreUtilities
				.toAnimateCloseIconOfModifiedTab(this.tabPane, tabIndex);
		if (isWindowModified && isEnabled && !toMarkModifiedCloseButton) {
			colorScheme2 = SubstanceTheme.YELLOW;
			colorScheme = SubstanceTheme.ORANGE;

			cyclePos = FadeTracker.getInstance().getFade10(this.tabPane,
					tabIndex, ModifiedFadeStep.MARKED_MODIFIED_FADE_KIND);
			//			
			// cyclePos = (int) TabPulseTracker.getCycles(this.tabPane, comp);
			// if (cyclePos > 10) {
			// cyclePos = 19 - cyclePos;
			// }
			hasActivePresence = true;
		}

		// see if need to use fade animation. Important - don't do it
		// on pulsating tabs.
		FadeTracker fadeTracker = FadeTracker.getInstance();
		if (!isWindowModified) {
			if (fadeTracker
					.isTracked(this.tabPane, tabIndex, FadeKind.ROLLOVER)) {
				hasActivePresence = true;
				ColorScheme defaultScheme = SubstanceCoreUtilities
						.getDefaultScheme(tabComponent, this.tabPane);
				if (!isRollover) {
					// Came from rollover state
					colorScheme2 = SubstanceCoreUtilities
							.getActiveScheme(this.tabPane
									.getComponentAt(tabIndex), this.tabPane);
					colorScheme = isSelected ? colorScheme : defaultScheme;
					cyclePos = fadeTracker.getFade10(this.tabPane, tabIndex,
							null);
					// System.out.println("Fading out from rollover "
					// + colorScheme.getClass().getSimpleName() + " -> "
					// + colorScheme2.getClass().getSimpleName() + " at "
					// + cyclePos);
				} else {
					// Came from default state
					colorScheme2 = colorScheme;
					colorScheme = isSelected ? colorScheme : defaultScheme;
					cyclePos = fadeTracker.getFade10(this.tabPane, tabIndex,
							null);
				}
			}
		}

		boolean toSwap = SubstanceCoreUtilities
				.toLayoutVertically(this.tabPane);

		switch (tabPlacement) {
		case LEFT:
			backgroundImage = SubstanceTabbedPaneUI.getTabBackground(w, h,
					isSelected, cyclePos, toSwap ? SwingConstants.TOP
							: tabPlacement,
					toSwap ? SubstanceConstants.Side.BOTTOM
							: SubstanceConstants.Side.RIGHT, colorScheme,
					colorScheme2);
			// y++;
			if (isSelected) {
				int fw = backgroundImage.getWidth();
				int fh = backgroundImage.getHeight();
				SubstanceTheme tabTheme = SubstanceCoreUtilities.getTheme(
						tabComponent, this.tabPane, true);
				BufferedImage fade = SubstanceCoreUtilities.getBlankImage(fw,
						fh);
				Graphics2D fadeGraphics = fade.createGraphics();
				fadeGraphics.setColor((tabComponent != null) ? tabComponent
						.getBackground() : tabPane.getBackground());
				fadeGraphics.fillRect(0, 0, fw, fh);
				SubstanceLookAndFeel.getCurrentWatermark().drawWatermarkImage(
						fadeGraphics, tabPane, 0, 0, fw, fh);
				fadeGraphics.setColor(darkShadow);
				if (toSwap) {
					fadeGraphics.drawLine(0, 0, 0, fh - 1);
					fadeGraphics.drawLine(fw - 1, 0, fw - 1, fh - 1);
					backgroundImage = SubstanceCoreUtilities
							.blendImagesVertical(backgroundImage, fade,
									tabTheme.getSelectedTabFadeStart(),
									tabTheme.getSelectedTabFadeEnd());
				} else {
					fadeGraphics.drawLine(0, 0, fw - 1, 0);
					fadeGraphics.drawLine(0, fh - 1, fw - 1, fh - 1);
					backgroundImage = SubstanceCoreUtilities
							.blendImagesHorizontal(backgroundImage, fade,
									tabTheme.getSelectedTabFadeStart(),
									tabTheme.getSelectedTabFadeEnd());
				}
			}
			break;
		case RIGHT:
			backgroundImage = SubstanceTabbedPaneUI.getTabBackground(w, h,
					isSelected, cyclePos, toSwap ? SwingConstants.BOTTOM
							: tabPlacement,
					toSwap ? SubstanceConstants.Side.BOTTOM
							: SubstanceConstants.Side.LEFT, colorScheme,
					colorScheme2);
			// y--;
			// if (toSwap)
			// x--;
			if (isSelected) {
				int fw = backgroundImage.getWidth();
				int fh = backgroundImage.getHeight();
				SubstanceTheme tabTheme = SubstanceCoreUtilities.getTheme(
						tabComponent, this.tabPane, true);
				BufferedImage fade = SubstanceCoreUtilities.getBlankImage(fw,
						fh);
				Graphics2D fadeGraphics = fade.createGraphics();
				fadeGraphics.setColor((tabComponent != null) ? tabComponent
						.getBackground() : tabPane.getBackground());
				fadeGraphics.fillRect(0, 0, fw, fh);
				SubstanceLookAndFeel.getCurrentWatermark().drawWatermarkImage(
						fadeGraphics, tabPane, 0, 0, fw, fh);
				fadeGraphics.setColor(darkShadow);
				if (toSwap) {
					fadeGraphics.drawLine(0, 0, 0, fh - 1);
					fadeGraphics.drawLine(fw - 1, 0, fw - 1, fh - 1);
					backgroundImage = SubstanceCoreUtilities
							.blendImagesVertical(backgroundImage, fade,
									tabTheme.getSelectedTabFadeStart(),
									tabTheme.getSelectedTabFadeEnd());
				} else {
					fadeGraphics.drawLine(0, 0, fw - 1, 0);
					fadeGraphics.drawLine(0, fh - 1, fw - 1, fh - 1);
					backgroundImage = SubstanceCoreUtilities
							.blendImagesHorizontal(fade, backgroundImage,
									1.0 - tabTheme.getSelectedTabFadeEnd(),
									1.0 - tabTheme.getSelectedTabFadeStart());
				}
			}
			break;
		case BOTTOM:
			backgroundImage = SubstanceTabbedPaneUI.getTabBackground(w, h,
					isSelected, cyclePos, tabPlacement,
					SubstanceConstants.Side.BOTTOM, colorScheme, colorScheme2);
			backgroundImage = SubstanceImageCreator.getRotated(backgroundImage,
					2);
			if (isSelected) {
				int fw = backgroundImage.getWidth();
				int fh = backgroundImage.getHeight();
				SubstanceTheme tabTheme = SubstanceCoreUtilities.getTheme(
						tabComponent, this.tabPane, true);
				BufferedImage fade = SubstanceCoreUtilities.getBlankImage(fw,
						fh);
				Graphics2D fadeGraphics = fade.createGraphics();
				fadeGraphics.setColor((tabComponent != null) ? tabComponent
						.getBackground() : tabPane.getBackground());
				fadeGraphics.fillRect(0, 0, fw, fh);
				SubstanceLookAndFeel.getCurrentWatermark().drawWatermarkImage(
						fadeGraphics, tabPane, 0, 0, fw, fh);
				fadeGraphics.setColor(darkShadow);
				fadeGraphics.drawLine(0, 0, 0, fh - 1);
				fadeGraphics.drawLine(fw - 1, 0, fw - 1, fh - 1);
				// backgroundImage = fade;
				backgroundImage = SubstanceCoreUtilities.blendImagesVertical(
						fade, backgroundImage, 1.0 - tabTheme
								.getSelectedTabFadeEnd(), 1.0 - tabTheme
								.getSelectedTabFadeStart());
			}
			break;
		case TOP:
		default:
			backgroundImage = SubstanceTabbedPaneUI.getTabBackground(w, h,
					isSelected, cyclePos, tabPlacement,
					SubstanceConstants.Side.BOTTOM, colorScheme, colorScheme2);
			if (isSelected) {
				int fw = backgroundImage.getWidth();
				int fh = backgroundImage.getHeight();
				SubstanceTheme tabTheme = SubstanceCoreUtilities.getTheme(
						tabComponent, this.tabPane, true);
				BufferedImage fade = SubstanceCoreUtilities.getBlankImage(fw,
						fh);
				Graphics2D fadeGraphics = fade.createGraphics();
				fadeGraphics.setColor((tabComponent != null) ? tabComponent
						.getBackground() : tabPane.getBackground());
				fadeGraphics.fillRect(0, 0, fw, fh);
				SubstanceLookAndFeel.getCurrentWatermark().drawWatermarkImage(
						fadeGraphics, tabPane, 0, 0, fw, fh);
				fadeGraphics.setColor(darkShadow);
				fadeGraphics.drawLine(0, 0, 0, fh - 1);
				fadeGraphics.drawLine(fw - 1, 0, fw - 1, fh - 1);
				backgroundImage = SubstanceCoreUtilities.blendImagesVertical(
						backgroundImage, fade, tabTheme
								.getSelectedTabFadeStart(), tabTheme
								.getSelectedTabFadeEnd());
			}
		}

		BufferedImage result = SubstanceCoreUtilities.getBlankImage(
				backgroundImage.getWidth(), backgroundImage.getHeight());
		Graphics2D resultGr = (Graphics2D) result.createGraphics();

		if (backgroundImage != null) {
			ControlBackgroundComposite composite = SubstanceCoreUtilities
					.getControlBackgroundComposite(this.tabPane);
			resultGr.setComposite(composite.getBackgroundComposite(
					tabComponent, this.tabPane, tabIndex, hasActivePresence));
			resultGr.drawImage(backgroundImage, 0, 0, null);
		}

		// Check if requested to paint close buttons.
		if (SubstanceCoreUtilities.hasCloseButton(this.tabPane, tabIndex)
				&& isEnabled) {

			float alpha = (isSelected || isRollover) ? 1.0f : 0.0f;
			if (!isSelected
					&& fadeTracker.isTracked(this.tabPane, tabIndex,
							FadeKind.ROLLOVER)) {
				alpha = fadeTracker.getFade10(this.tabPane, tabIndex,
						FadeKind.ROLLOVER) / 10.0f;
			}
			if (alpha > 0.0) {
				resultGr.setComposite(AlphaComposite.getInstance(
						AlphaComposite.SRC_OVER, alpha));

				// paint close button
				Rectangle orig = this.getCloseButtonRectangleForDraw(tabIndex,
						x, y, w, h);

				boolean toPaintCloseBorder = false;
				if (isRollover) {
					if (this.substanceMouseLocation != null) {
						Rectangle bounds = new Rectangle();
						bounds = this.getTabBounds(tabIndex, bounds);
						if (toSwap) {
							bounds = new Rectangle(bounds.x, bounds.y,
									bounds.height, bounds.width);
						}
						Rectangle rect = this.getCloseButtonRectangleForEvents(
								tabIndex, bounds.x, bounds.y, bounds.width,
								bounds.height);
						// System.out.println("paint " + bounds + " " + rect + "
						// "
						// + mouseLocation);
						if (rect.contains(this.substanceMouseLocation)) {
							toPaintCloseBorder = true;
						}
					}
				}

				if (isWindowModified && isEnabled && toMarkModifiedCloseButton) {
					colorScheme2 = SubstanceTheme.YELLOW;
					colorScheme = SubstanceTheme.ORANGE;
					// cyclePos = (int) TabPulseTracker.getCycles(this.tabPane,
					// comp);
					// if (cyclePos > 10) {
					// cyclePos = 19 - cyclePos;
					// }
					cyclePos = FadeTracker.getInstance().getFade10(
							this.tabPane, tabIndex,
							ModifiedFadeStep.MARKED_MODIFIED_FADE_KIND);
				}
				BufferedImage closeButtonImage = SubstanceTabbedPaneUI
						.getCloseButtonImage(orig.width, orig.height, cyclePos,
								toPaintCloseBorder, colorScheme, colorScheme2);
				resultGr.drawImage(closeButtonImage, orig.x - x, orig.y - y,
						null);
			}
		}

		graphics.drawImage(result, x, y, null);
		resultGr.dispose();
		graphics.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#paintFocusIndicator(java.awt.Graphics,
	 *      int, java.awt.Rectangle[], int, java.awt.Rectangle,
	 *      java.awt.Rectangle, boolean)
	 */
	@Override
	protected void paintFocusIndicator(Graphics g, int tabPlacement,
			Rectangle[] rects, int tabIndex, Rectangle iconRect,
			Rectangle textRect, boolean isSelected) {
		// empty to remove Basic functionality
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#paintTabBorder(java.awt.Graphics,
	 *      int, int, int, int, int, int, boolean)
	 */
	@Override
	protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex,
			int x, int y, int w, int h, boolean isSelected) {
		// empty to remove Basic functionality
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#createScrollButton(int)
	 */
	@Override
	protected JButton createScrollButton(int direction) {
		Icon icon = SubstanceImageCreator.getArrowIcon(9, 5, direction,
				SubstanceCoreUtilities.getActiveTheme(this.tabPane, true));

		SubstanceScrollButton ssb = new SubstanceScrollButton(icon, direction);
		// ssb.addComponentListener(new ComponentAdapter() {
		// @Override
		// public void componentMoved(ComponentEvent e) {
		// Component comp = e.getComponent();
		// System.out.println("Bounds " + comp.getBounds());
		// }
		// });
		return ssb;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#createChangeListener()
	 */
	@Override
	protected ChangeListener createChangeListener() {
		return new TabSelectionHandler();
	}

	/**
	 * Handler for tab selection.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class TabSelectionHandler implements ChangeListener {
		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
		 */
		public void stateChanged(ChangeEvent e) {
			JTabbedPane tabbedPane = (JTabbedPane) e.getSource();
			tabbedPane.revalidate();
			tabbedPane.repaint();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#getTabAreaInsets(int)
	 */
	@Override
	protected Insets getTabAreaInsets(int tabPlacement) {
		Insets result = super.getTabAreaInsets(tabPlacement);
		// result.right += 10;
		// result.left += 10;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#getTabInsets(int, int)
	 */
	@Override
	protected Insets getTabInsets(int tabPlacement, int tabIndex) {
		Insets result = super.getTabInsets(tabPlacement, tabIndex);
		// result.right += 10;
		return result;
	}

	// @Override
	// protected int calculateTabAreaWidth(int tabPlacement, int vertRunCount,
	// int maxTabWidth) {
	// return 20 + super.calculateTabAreaWidth(tabPlacement, vertRunCount,
	// maxTabWidth);
	// }

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#calculateTabHeight(int,
	 *      int, int)
	 */
	@Override
	protected int calculateTabHeight(int tabPlacement, int tabIndex,
			int fontHeight) {
		boolean toSwap = SubstanceCoreUtilities
				.toLayoutVertically(this.tabPane);
		if (toSwap)
			return this.getTabExtraWidth(tabPlacement, tabIndex)
					+ super.calculateTabWidth(tabPlacement, tabIndex, this
							.getFontMetrics());
		return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#calculateTabWidth(int, int,
	 *      java.awt.FontMetrics)
	 */
	@Override
	protected int calculateTabWidth(int tabPlacement, int tabIndex,
			FontMetrics metrics) {
		boolean toSwap = SubstanceCoreUtilities
				.toLayoutVertically(this.tabPane);
		if (toSwap)
			return super.calculateTabHeight(tabPlacement, tabIndex, metrics
					.getHeight());
		int result = this.getTabExtraWidth(tabPlacement, tabIndex)
				+ super.calculateTabWidth(tabPlacement, tabIndex, metrics);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#calculateMaxTabHeight(int)
	 */
	@Override
	protected int calculateMaxTabHeight(int tabPlacement) {
		if ((tabPlacement == SwingConstants.TOP)
				|| (tabPlacement == SwingConstants.BOTTOM))
			return super.calculateMaxTabHeight(tabPlacement);
		int result = 0;
		for (int i = 0; i < this.tabPane.getTabCount(); i++)
			result = Math.max(result, this.calculateTabHeight(tabPlacement, i,
					this.getFontMetrics().getHeight()));
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#getTabRunOverlay(int)
	 */
	@Override
	protected int getTabRunOverlay(int tabPlacement) {
		boolean toSwap = SubstanceCoreUtilities
				.toLayoutVertically(this.tabPane);
		if (!toSwap)
			return super.getTabRunOverlay(tabPlacement);

		return 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#paintTab(java.awt.Graphics,
	 *      int, java.awt.Rectangle[], int, java.awt.Rectangle,
	 *      java.awt.Rectangle)
	 */
	@Override
	protected void paintTab(Graphics g, int tabPlacement, Rectangle[] rects,
			int tabIndex, Rectangle iconRect, Rectangle textRect) {
		boolean toSwap = SubstanceCoreUtilities
				.toLayoutVertically(this.tabPane);
		if (toSwap) {
			Graphics2D tempG = (Graphics2D) g.create();
			Rectangle tabRect = rects[tabIndex];
			Rectangle correctRect = new Rectangle(tabRect.x, tabRect.y,
					tabRect.height, tabRect.width);
			if (tabPlacement == SwingConstants.LEFT) {
				// rotate 90 degrees counterclockwise for LEFT orientation
				tempG.rotate(-Math.PI / 2, tabRect.x, tabRect.y);
				tempG.translate(-tabRect.height, 0);
			} else {
				// rotate 90 degrees clockwise for RIGHT orientation
				tempG.rotate(Math.PI / 2, tabRect.x, tabRect.y);
				tempG.translate(0, -tabRect.getWidth());
			}
			tempG.setColor(Color.red);
			rects[tabIndex] = correctRect;
			super.paintTab(tempG, tabPlacement, rects, tabIndex, iconRect,
					textRect);
			rects[tabIndex] = tabRect;
			tempG.dispose();
		} else {
			super
					.paintTab(g, tabPlacement, rects, tabIndex, iconRect,
							textRect);
		}
		// Rectangle rect = new Rectangle();
		// rect = getTabBounds(tabIndex, rect);
		// Rectangle close = getCloseButtonRectangleForEvents(
		// tabIndex, rect.x, rect.y, rect.width,
		// rect.height);
		// g.setColor(Color.red);
		// g.drawRect(close.x, close.y, close.width, close.height);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#paintTabArea(java.awt.Graphics,
	 *      int, int)
	 */
	@Override
	protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex) {
		// System.out.println("Painting tab area");
		this.bgDelegate.update(g, this.tabPane);
		super.paintTabArea(g, tabPlacement, selectedIndex);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#getIconForTab(int)
	 */
	@Override
	protected Icon getIconForTab(int tabIndex) {
		Icon superResult = super.getIconForTab(tabIndex);
		if (!SubstanceCoreUtilities.toLayoutVertically(this.tabPane))
			return superResult;
		if (!SubstanceCoreUtilities.toShowIconUnrotated(this.tabPane, tabIndex))
			return superResult;

		boolean rotateClockwise = (this.tabPane.getTabPlacement() == SwingConstants.LEFT);
		return new RotatableIcon(superResult, rotateClockwise);
	}

	/**
	 * Retrieves the close button rectangle for drawing purposes.
	 * 
	 * @param tabIndex
	 *            Tab index.
	 * @param x
	 *            X coordinate of the tab.
	 * @param y
	 *            Y coordinate of the tab.
	 * @param width
	 *            The tab width.
	 * @param height
	 *            The tab height.
	 * @return The close button rectangle.
	 */
	protected Rectangle getCloseButtonRectangleForDraw(int tabIndex, int x,
			int y, int width, int height) {
		int dimension = SubstanceCoreUtilities.getCloseButtonSize(this.tabPane,
				tabIndex);
		int xs = this.tabPane.getComponentOrientation().isLeftToRight() ? (x
				+ width - dimension - 4) : (x + 4);
		int ys = y + (height - dimension) / 2;
		return new Rectangle(xs, ys, dimension, dimension);
	}

	/**
	 * Retrieves the close button rectangle for event handling.
	 * 
	 * @param tabIndex
	 *            Tab index.
	 * @param x
	 *            X coordinate of the tab.
	 * @param y
	 *            Y coordinate of the tab.
	 * @param w
	 *            The tab width.
	 * @param h
	 *            The tab height.
	 * @return The close button rectangle.
	 */
	protected Rectangle getCloseButtonRectangleForEvents(int tabIndex, int x,
			int y, int w, int h) {
		int tabPlacement = this.tabPane.getTabPlacement();
		boolean toSwap = SubstanceCoreUtilities
				.toLayoutVertically(this.tabPane);
		if (!toSwap) {
			return this.getCloseButtonRectangleForDraw(tabIndex, x, y, w, h);
		}
		int dimension = SubstanceCoreUtilities.getCloseButtonSize(this.tabPane,
				tabIndex);

		Point2D transCorner = null;
		Rectangle rectForDraw = this.getCloseButtonRectangleForDraw(tabIndex,
				x, y, h, w);
		if (tabPlacement == SwingConstants.LEFT) {
			AffineTransform trans = new AffineTransform();
			trans.rotate(-Math.PI / 2, x, y);
			trans.translate(-h, 0);
			Point2D.Double origCorner = new Point2D.Double(rectForDraw
					.getMaxX(), rectForDraw.getMinY());
			transCorner = trans.transform(origCorner, null);
		} else {
			// rotate 90 degrees clockwise for RIGHT orientation
			AffineTransform trans = new AffineTransform();
			trans.rotate(Math.PI / 2, x, y);
			trans.translate(0, -w);
			Point2D.Double origCorner = new Point2D.Double(rectForDraw
					.getMinX(), rectForDraw.getMaxY());
			transCorner = trans.transform(origCorner, null);
		}
		return new Rectangle((int) transCorner.getX(),
				(int) transCorner.getY(), dimension, dimension);
	}

	/**
	 * Implementation of the fade tracker callback that repaints a single tab.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class TabRepaintCallback implements FadeTrackerCallback {
		/**
		 * The associated tabbed pane.
		 */
		protected JTabbedPane tabbedPane;

		/**
		 * The associated tab index.
		 */
		protected int tabIndex;

		/**
		 * Creates new tab repaint callback.
		 * 
		 * @param tabPane
		 *            The associated tabbed pane.
		 * @param tabIndex
		 *            The associated tab index.
		 */
		public TabRepaintCallback(JTabbedPane tabPane, int tabIndex) {
			this.tabbedPane = tabPane;
			this.tabIndex = tabIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed(org.jvnet.lafwidget.utils.FadeTracker.FadeKind,
		 *      float)
		 */
		public void fadePerformed(FadeKind fadeKind, float fade10) {
			this.repaintTab();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback2#fadeEnded(org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		public void fadeEnded(FadeKind fadeKind) {
			this.repaintTab();
		}

		/**
		 * Repaints the relevant tab.
		 */
		protected void repaintTab() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (SubstanceTabbedPaneUI.this.tabPane == null) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					SubstanceTabbedPaneUI.this.ensureCurrentLayout();
					int tabCount = SubstanceTabbedPaneUI.this.tabPane
							.getTabCount();
					if ((tabCount > 0)
							&& (TabRepaintCallback.this.tabIndex < tabCount)
							&& (TabRepaintCallback.this.tabIndex < SubstanceTabbedPaneUI.this.rects.length)) {
						// need to retrieve the tab rectangle since the tabs
						// can be moved while animating (especially when the
						// current layout is SCROLL_LAYOUT)
						Rectangle rect = SubstanceTabbedPaneUI.this
								.getTabBounds(
										SubstanceTabbedPaneUI.this.tabPane,
										TabRepaintCallback.this.tabIndex);
						// System.out.println("Repainting " + tabIndex);
						SubstanceTabbedPaneUI.this.tabPane.repaint(rect);
					}
				}
			});
		}
	}

	/**
	 * Implementation of the fade tracker callback that repaints a single tab.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class TabIconAnimationCallback implements FadeTrackerCallback {
		/**
		 * The associated tabbed pane.
		 */
		protected JTabbedPane tabbedPane;

		/**
		 * The associated tab index.
		 */
		protected int tabIndex;

		/**
		 * Creates new tab repaint callback.
		 * 
		 * @param tabPane
		 *            The associated tabbed pane.
		 * @param tabIndex
		 *            The associated tab index.
		 */
		public TabIconAnimationCallback(JTabbedPane tabPane, int tabIndex) {
			this.tabbedPane = tabPane;
			this.tabIndex = tabIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed(org.jvnet.lafwidget.utils.FadeTracker.FadeKind,
		 *      float)
		 */
		public void fadePerformed(FadeKind fadeKind, float fade10) {
			Component comp = this.tabbedPane.getComponent(tabIndex);
			if (comp == null) {
				return;
			}

			Icon icon = this.tabbedPane.getIconAt(this.tabIndex);
			if (icon instanceof IconWrapper) {
				((IconWrapper) icon).setCyclePos(fade10 / 10.0);
			}

			// maybe LAF has changed
			if (UIManager.getLookAndFeel() instanceof SubstanceLookAndFeel) {
				// fix for defect 113 - check if the tab was closed in the
				// meanwhile
				FadeTrackerCallback callback = getCallback(tabIndex);
				callback.fadePerformed(IconFadeStep.ICON_ANIMATION_FADE_KIND,
						0.0f);
			} else {
				if (icon instanceof IconWrapper) {
					this.tabbedPane.setIconAt(this.tabIndex,
							((IconWrapper) icon).getOriginalIcon());
				}
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback2#fadeEnded(org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		public void fadeEnded(FadeKind fadeKind) {
			Icon currentIcon = this.tabbedPane.getIconAt(this.tabIndex);
			Icon originalIcon = null;
			if (currentIcon instanceof IconWrapper)
				originalIcon = ((IconWrapper) currentIcon).getOriginalIcon();

			Component tabComponent = this.tabbedPane
					.getComponent(this.tabIndex);
			TabAnimationKind nextKind = SubstanceCoreUtilities
					.getTabAnimationKind(tabComponent);

			fadeIconIds.remove(tabComponent);
			this.tabbedPane.setIconAt(tabIndex, originalIcon);
			if (nextKind != null) {
				// start new animation
				this.startIconAnimation(nextKind);
			}
		}

		/**
		 * Starts the icon animation sequence.
		 * 
		 * @param nextKind
		 *            Icon animation kind.
		 */
		public void startIconAnimation(TabAnimationKind nextKind) {
			Icon origIcon = this.tabbedPane.getIconAt(this.tabIndex);
			switch (nextKind) {
			case ERROR:
				MixIcon mErrorIcon = new MixIcon(origIcon,
						SubstanceImageCreator.getErrorMarkerIcon(origIcon
								.getIconWidth(), new SunfireRedColorScheme()));
				this.tabbedPane.setIconAt(this.tabIndex, mErrorIcon);
				break;
			case WARNING:
				MixIcon mWarningIcon = new MixIcon(origIcon,
						SubstanceImageCreator.getWarningMarkerIcon(origIcon
								.getIconWidth(), new SunsetColorScheme()));
				this.tabbedPane.setIconAt(this.tabIndex, mWarningIcon);
				break;
			case LOADING:
				ProgressIcon pIcon = new ProgressIcon(origIcon);
				this.tabbedPane.setIconAt(this.tabIndex, pIcon);
				break;
			}

			long fadeInstanceId = FadeTracker.getInstance()
					.trackFadeLooping(
							IconFadeStep.ICON_ANIMATION_FADE_KIND,
							new LafConstants.AnimationKind(new IconFadeStep(),
									"iconAnimation"),
							this.tabbedPane,
							this.tabIndex,
							false,
							new TabIconAnimationCallback(this.tabbedPane,
									this.tabIndex),
							nextKind != TabAnimationKind.LOADING);
			Component tabComponent = this.tabbedPane
					.getComponent(this.tabIndex);
			fadeIconIds.put(tabComponent, fadeInstanceId);
		}
	}

	/**
	 * Ensures the current layout.
	 */
	protected void ensureCurrentLayout() {
		if (!this.tabPane.isValid()) {
			this.tabPane.validate();
		}
		/*
		 * If tabPane doesn't have a peer yet, the validate() call will silently
		 * fail. We handle that by forcing a layout if tabPane is still invalid.
		 * See bug 4237677.
		 */
		if (!this.tabPane.isValid()) {
			LayoutManager lm = this.tabPane.getLayout();
			if (lm instanceof TabbedPaneLayout) {
				TabbedPaneLayout layout = (TabbedPaneLayout) lm;
				layout.calculateLayoutInfo();
			} else {
				if (lm instanceof TransitionLayout) {
					lm = ((TransitionLayout) lm).getDelegate();
					if (lm instanceof TabbedPaneLayout) {
						TabbedPaneLayout layout = (TabbedPaneLayout) lm;
						layout.calculateLayoutInfo();
					}
				}
			}
		}
	}

	/**
	 * Returns the repaint callback for the specified tab index.
	 * 
	 * @param tabIndex
	 *            Tab index.
	 * @return Repaint callback for the specified tab index.
	 */
	public FadeTrackerCallback getCallback(int tabIndex) {
		return new TabRepaintCallback(this.tabPane, tabIndex);
	}

	/**
	 * Tries closing tabs based on the specified tab index and tab close kind.
	 * 
	 * @param tabIndex
	 *            Tab index.
	 * @param tabCloseKind
	 *            Tab close kind.
	 */
	protected void tryCloseTabs(int tabIndex, TabCloseKind tabCloseKind) {
		if (tabCloseKind == null)
			return;
		if (tabCloseKind == TabCloseKind.NONE)
			return;

		if (tabCloseKind == TabCloseKind.ALL_BUT_THIS) {
			// close all but this
			Set<Integer> indexes = new HashSet<Integer>();
			for (int i = 0; i < this.tabPane.getTabCount(); i++)
				if (i != tabIndex)
					indexes.add(i);
			this.tryCloseTabs(indexes);
			return;
		}
		if (tabCloseKind == TabCloseKind.ALL) {
			// close all
			Set<Integer> indexes = new HashSet<Integer>();
			for (int i = 0; i < this.tabPane.getTabCount(); i++)
				indexes.add(i);
			this.tryCloseTabs(indexes);
			return;
		}
		this.tryCloseTab(tabIndex);
	}

	/**
	 * Tries closing a single tab.
	 * 
	 * @param tabIndex
	 *            Tab index.
	 */
	protected void tryCloseTab(int tabIndex) {
		Component component = this.tabPane.getComponentAt(tabIndex);
		Set<Component> componentSet = new HashSet<Component>();
		componentSet.add(component);

		// check if there's at least one listener
		// that vetoes the closing
		boolean isVetoed = false;
		for (BaseTabCloseListener listener : SubstanceLookAndFeel
				.getAllTabCloseListeners(this.tabPane)) {
			if (listener instanceof VetoableTabCloseListener) {
				VetoableTabCloseListener vetoableListener = (VetoableTabCloseListener) listener;
				isVetoed = isVetoed
						|| vetoableListener.vetoTabClosing(this.tabPane,
								component);
			}
			if (listener instanceof VetoableMultipleTabCloseListener) {
				VetoableMultipleTabCloseListener vetoableListener = (VetoableMultipleTabCloseListener) listener;
				isVetoed = isVetoed
						|| vetoableListener.vetoTabsClosing(this.tabPane,
								componentSet);
			}
		}
		if (isVetoed)
			return;

		for (BaseTabCloseListener listener : SubstanceLookAndFeel
				.getAllTabCloseListeners(this.tabPane)) {
			if (listener instanceof TabCloseListener)
				((TabCloseListener) listener).tabClosing(this.tabPane,
						component);
			if (listener instanceof MultipleTabCloseListener)
				((MultipleTabCloseListener) listener).tabsClosing(this.tabPane,
						componentSet);
		}

		this.tabPane.remove(tabIndex);
		if (this.tabPane.getTabCount() > 0) {
			this.selectPreviousTab(0);
			this.selectNextTab(this.tabPane.getSelectedIndex());
		}
		this.tabPane.repaint();

		for (BaseTabCloseListener listener : SubstanceLookAndFeel
				.getAllTabCloseListeners(this.tabPane)) {
			if (listener instanceof TabCloseListener)
				((TabCloseListener) listener)
						.tabClosed(this.tabPane, component);
			if (listener instanceof MultipleTabCloseListener)
				((MultipleTabCloseListener) listener).tabsClosed(this.tabPane,
						componentSet);
		}
	}

	/**
	 * Tries closing the specified tabs.
	 * 
	 * @param tabIndexes
	 *            Tab indexes.
	 */
	protected void tryCloseTabs(Set<Integer> tabIndexes) {
		Set<Component> componentSet = new HashSet<Component>();
		for (int tabIndex : tabIndexes) {
			componentSet.add(this.tabPane.getComponentAt(tabIndex));
		}

		// check if there's at least one listener
		// that vetoes the closing
		boolean isVetoed = false;
		for (BaseTabCloseListener listener : SubstanceLookAndFeel
				.getAllTabCloseListeners(this.tabPane)) {
			if (listener instanceof VetoableMultipleTabCloseListener) {
				VetoableMultipleTabCloseListener vetoableListener = (VetoableMultipleTabCloseListener) listener;
				isVetoed = isVetoed
						|| vetoableListener.vetoTabsClosing(this.tabPane,
								componentSet);
			}
		}
		if (isVetoed)
			return;

		for (BaseTabCloseListener listener : SubstanceLookAndFeel
				.getAllTabCloseListeners(this.tabPane)) {
			if (listener instanceof MultipleTabCloseListener)
				((MultipleTabCloseListener) listener).tabsClosing(this.tabPane,
						componentSet);
		}

		for (Component toRemove : componentSet) {
			this.tabPane.remove(toRemove);
		}

		if (this.tabPane.getTabCount() > 0) {
			this.selectPreviousTab(0);
			this.selectNextTab(this.tabPane.getSelectedIndex());
		}
		this.tabPane.repaint();

		for (BaseTabCloseListener listener : SubstanceLookAndFeel
				.getAllTabCloseListeners(this.tabPane)) {
			if (listener instanceof MultipleTabCloseListener)
				((MultipleTabCloseListener) listener).tabsClosed(this.tabPane,
						componentSet);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#layoutLabel(int,
	 *      java.awt.FontMetrics, int, java.lang.String, javax.swing.Icon,
	 *      java.awt.Rectangle, java.awt.Rectangle, java.awt.Rectangle, boolean)
	 */
	@Override
	protected void layoutLabel(int tabPlacement, FontMetrics metrics,
			int tabIndex, String title, Icon icon, Rectangle tabRect,
			Rectangle iconRect, Rectangle textRect, boolean isSelected) {
		textRect.x = textRect.y = iconRect.x = iconRect.y = 0;

		View v = this.getTextViewForTab(tabIndex);
		if (v != null) {
			this.tabPane.putClientProperty("html", v);
		}

		SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon,
				SwingConstants.CENTER, this.getTextAlignment(tabPlacement),
				SwingConstants.CENTER, SwingConstants.TRAILING, tabRect,
				iconRect, textRect, this.textIconGap);

		this.tabPane.putClientProperty("html", null);

		int xNudge = this.getTabLabelShiftX(tabPlacement, tabIndex, isSelected);
		int yNudge = this.getTabLabelShiftY(tabPlacement, tabIndex, isSelected);
		iconRect.x += xNudge;
		iconRect.y += yNudge;
		textRect.x += xNudge;
		textRect.y += yNudge;
	}

	/**
	 * Returns the text alignment for the specified tab placement.
	 * 
	 * @param tabPlacement
	 *            Tab placement.
	 * @return Tab text alignment.
	 */
	protected int getTextAlignment(int tabPlacement) {
		TabTextAlignmentKind textAlignmentKind = SubstanceCoreUtilities
				.getTabTextAlignmentKind(this.tabPane);

		if (SubstanceCoreUtilities.toLayoutVertically(this.tabPane)) {
			return SwingConstants.CENTER;
		}

		if ((tabPlacement == SwingConstants.LEFT)) {
			switch (textAlignmentKind) {
			case ALWAYS_LEFT:
			case FOLLOW_PLACEMENT:
				return SwingConstants.LEFT;
			case FOLLOW_ORIENTATION:
				if (this.tabPane.getComponentOrientation().isLeftToRight())
					return SwingConstants.LEFT;
				else
					return SwingConstants.RIGHT;
			case ALWAYS_RIGHT:
				return SwingConstants.RIGHT;
			}
		}
		if ((tabPlacement == SwingConstants.RIGHT)) {
			switch (textAlignmentKind) {
			case ALWAYS_RIGHT:
			case FOLLOW_PLACEMENT:
				return SwingConstants.RIGHT;
			case FOLLOW_ORIENTATION:
				if (this.tabPane.getComponentOrientation().isLeftToRight())
					return SwingConstants.LEFT;
				else
					return SwingConstants.RIGHT;
			case ALWAYS_LEFT:
				return SwingConstants.LEFT;
			}
		}

		return SwingConstants.CENTER;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#getTabLabelShiftX(int, int,
	 *      boolean)
	 */
	@Override
	protected int getTabLabelShiftX(int tabPlacement, int tabIndex,
			boolean isSelected) {
		int textAlignment = this.getTextAlignment(tabPlacement);
		int delta = 0;
		if (textAlignment == SwingConstants.LEFT)
			delta = 10;
		if (textAlignment == SwingConstants.RIGHT)
			delta = -10
					- SubstanceCoreUtilities.getCloseButtonSize(this.tabPane,
							tabIndex);
		if ((textAlignment == SwingConstants.CENTER)
				&& (SubstanceCoreUtilities.hasCloseButton(this.tabPane,
						tabIndex))) {
			if (this.tabPane.getComponentOrientation().isLeftToRight()) {
				delta = 5 - SubstanceCoreUtilities.getCloseButtonSize(
						this.tabPane, tabIndex);
			} else {
				delta = SubstanceCoreUtilities.getCloseButtonSize(this.tabPane,
						tabIndex) - 5;
			}
		}
		return delta
				+ super.getTabLabelShiftX(tabPlacement, tabIndex, isSelected);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#getTabLabelShiftY(int, int,
	 *      boolean)
	 */
	@Override
	protected int getTabLabelShiftY(int tabPlacement, int tabIndex,
			boolean isSelected) {
		int result = 0;
		if (tabPlacement == SwingConstants.BOTTOM)
			result = -1;
		else
			result = 1;
		return result;
	}

	/**
	 * Returns extra width for the specified tab.
	 * 
	 * @param tabPlacement
	 *            Tab placement.
	 * @param tabIndex
	 *            Tab index.
	 * @return Extra width for the specified tab.
	 */
	protected int getTabExtraWidth(int tabPlacement, int tabIndex) {
		int extraWidth = 0;
		SubstanceButtonShaper shaper = SubstanceLookAndFeel
				.getCurrentButtonShaper();
		if (shaper instanceof ClassicButtonShaper)
			extraWidth = 2;
		else
			extraWidth = super.calculateTabHeight(tabPlacement, tabIndex, this
					.getFontMetrics().getHeight()) / 3;

		if (SubstanceCoreUtilities.hasCloseButton(this.tabPane, tabIndex)
				&& this.tabPane.isEnabledAt(tabIndex)) {
			extraWidth += (4 + SubstanceCoreUtilities.getCloseButtonSize(
					this.tabPane, tabIndex));
		}
		return extraWidth;
	}

	/**
	 * Returns the index of the tab currently being rolled-over.
	 * 
	 * @return Index of the tab currently being rolled-over.
	 */
	public int getRolloverTabIndex() {
		return this.getRolloverTab();
	}

	/**
	 * Sets new value for tab area insets.
	 * 
	 * @param insets
	 *            Tab area insets.
	 */
	public void setTabAreaInsets(Insets insets) {
		this.tabAreaInsets = insets;
	}

	/**
	 * Returns tab area insets.
	 * 
	 * @return Tab area insets.
	 */
	public Insets getTabAreaInsets() {
		return this.tabAreaInsets;
	}

	/**
	 * Returns the tab rectangle for the specified tab.
	 * 
	 * @param tabIndex
	 *            Index of a tab.
	 * @return The tab rectangle for the specified parameters.
	 */
	public Rectangle getTabRectangle(int tabIndex) {
		return this.rects[tabIndex];
	}

	/**
	 * Returns the memory usage string.
	 * 
	 * @return The memory usage string.
	 */
	public static String getMemoryUsage() {
		StringBuffer sb = new StringBuffer();
		sb.append("SubstanceTabbedPaneUI: \n");
		sb.append("\t" + SubstanceTabbedPaneUI.backgroundMap.size()
				+ " backgrounds");
		return sb.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#shouldPadTabRun(int, int)
	 */
	protected boolean shouldPadTabRun(int tabPlacement, int run) {
		// Don't pad last run
		return runCount > 1 && run < runCount - 1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTabbedPaneUI#createLayoutManager()
	 */
	@Override
	protected LayoutManager createLayoutManager() {
		if (tabPane.getTabLayoutPolicy() == JTabbedPane.SCROLL_TAB_LAYOUT) {
			return super.createLayoutManager();
		}
		return new TabbedPaneLayout();
	}

	/**
	 * Layout for the tabbed pane.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public class TabbedPaneLayout extends BasicTabbedPaneUI.TabbedPaneLayout {
		/**
		 * Creates a new layout.
		 */
		public TabbedPaneLayout() {
			SubstanceTabbedPaneUI.this.super();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.plaf.basic.BasicTabbedPaneUI$TabbedPaneLayout#normalizeTabRuns(int,
		 *      int, int, int)
		 */
		protected void normalizeTabRuns(int tabPlacement, int tabCount,
				int start, int max) {
			// Only normalize the runs for top & bottom; normalizing
			// doesn't look right for Metal's vertical tabs
			// because the last run isn't padded and it looks odd to have
			// fat tabs in the first vertical runs, but slimmer ones in the
			// last (this effect isn't noticeable for horizontal tabs).
			if (tabPlacement == TOP || tabPlacement == BOTTOM) {
				super.normalizeTabRuns(tabPlacement, tabCount, start, max);
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.plaf.basic.BasicTabbedPaneUI$TabbedPaneLayout#rotateTabRuns(int,
		 *      int)
		 */
		protected void rotateTabRuns(int tabPlacement, int selectedRun) {
			// Don't rotate runs!
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.plaf.basic.BasicTabbedPaneUI$TabbedPaneLayout#padSelectedTab(int,
		 *      int)
		 */
		protected void padSelectedTab(int tabPlacement, int selectedIndex) {
			// Don't pad selected tab
		}
	}

	@Override
	protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement,
			int selectedIndex, int x, int y, int w, int h) {
		Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(
				selectedIndex, calcRect);

		// Draw unbroken line if tabs are not on BOTTOM, OR
		// selected tab is not in run adjacent to content, OR
		// selected tab is not visible (SCROLL_TAB_LAYOUT)
		//
		if (tabPlacement != BOTTOM || selectedIndex < 0 || (selRect.y - 1 > h)
				|| (selRect.x < x || selRect.x > x + w)) {
			g.setColor(highlight);
			g.drawLine(x + 1, y + h - 2, x + w - 2, y + h - 2);
			g.setColor(darkShadow);
			g.drawLine(x + 1, y + h - 1, x + w - 2, y + h - 1);
		} else {
			// Break line to show visual connection to selected tab
			SubstanceButtonShaper shaper = SubstanceLookAndFeel
					.getCurrentButtonShaper();
			int delta = (shaper instanceof ClassicButtonShaper) ? 0 : 1;
			g.setColor(highlight);
			g.drawLine(x + 1, y + h - 2, selRect.x + 1, y + h - 2);
			g.setColor(darkShadow);
			g.drawLine(x + 1, y + h - 1, selRect.x, y + h - 1);
			if (selRect.x + selRect.width < x + w - 2) {
				g.setColor(highlight);
				g.drawLine(selRect.x + selRect.width + delta - 2, y + h - 2, x
						+ w - 2, y + h - 2);
				g.setColor(darkShadow);
				g.drawLine(selRect.x + selRect.width + delta - 2, y + h - 1, x
						+ w - 2, y + h - 1);
			}
		}
		g.setColor(SubstanceColorUtilities.getInterpolatedColor(darkShadow,
				highlight, 0.5));
		g.drawLine(x, y + h - 1, x, y + h - 1);
		g.drawLine(x + w - 1, y + h - 1, x + w - 1, y + h - 1);
	}

	@Override
	protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement,
			int selectedIndex, int x, int y, int w, int h) {
		Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(
				selectedIndex, calcRect);

		// Draw unbroken line if tabs are not on LEFT, OR
		// selected tab is not in run adjacent to content, OR
		// selected tab is not visible (SCROLL_TAB_LAYOUT)
		//
		if (tabPlacement != LEFT || selectedIndex < 0
				|| (selRect.x + selRect.width + 1 < x)
				|| (selRect.y < y || selRect.y > y + h)) {
			g.setColor(darkShadow);
			g.drawLine(x, y + 1, x, y + h - 2);
			g.setColor(highlight);
			g.drawLine(x + 1, y + 1, x + 1, y + h - 2);
		} else {
			// Break line to show visual connection to selected tab
			SubstanceButtonShaper shaper = SubstanceLookAndFeel
					.getCurrentButtonShaper();
			int delta = (shaper instanceof ClassicButtonShaper) ? 1 : 0;
			g.setColor(darkShadow);
			g.drawLine(x, y + 1, x, selRect.y + 1);
			g.setColor(highlight);
			g.drawLine(x + 1, y + 1, x + 1, selRect.y);
			if (selRect.y + selRect.height < y + h - 2) {
				g.setColor(darkShadow);
				g.drawLine(x, selRect.y + selRect.height - delta - 1, x, y + h
						- 2);
				g.setColor(highlight);
				g.drawLine(x + 1, selRect.y + selRect.height - delta, x + 1, y
						+ h - 2);
			}
		}
	}

	@Override
	protected void paintContentBorderRightEdge(Graphics g, int tabPlacement,
			int selectedIndex, int x, int y, int w, int h) {
		Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(
				selectedIndex, calcRect);

		// Draw unbroken line if tabs are not on RIGHT, OR
		// selected tab is not in run adjacent to content, OR
		// selected tab is not visible (SCROLL_TAB_LAYOUT)
		//
		if (tabPlacement != RIGHT || selectedIndex < 0 || (selRect.x - 1 > w)
				|| (selRect.y < y || selRect.y > y + h)) {
			g.setColor(highlight);
			g.drawLine(x + w - 2, y + 1, x + w - 2, y + h - 2);
			g.setColor(darkShadow);
			g.drawLine(x + w - 1, y + 1, x + w - 1, y + h - 2);
		} else {
			// Break line to show visual connection to selected tab
			g.setColor(highlight);
			g.drawLine(x + w - 2, y + 1, x + w - 2, selRect.y);
			g.setColor(darkShadow);
			g.drawLine(x + w - 1, y + 1, x + w - 1, selRect.y);

			SubstanceButtonShaper shaper = SubstanceLookAndFeel
					.getCurrentButtonShaper();
			int delta = (shaper instanceof ClassicButtonShaper) ? 1 : 0;
			if (selRect.y + selRect.height < y + h - 2) {
				g.setColor(highlight);
				g.drawLine(x + w - 2, selRect.y + selRect.height - delta - 2, x
						+ w - 2, y + h - 2);
				g.setColor(darkShadow);
				g.drawLine(x + w - 1, selRect.y + selRect.height - delta - 1, x
						+ w - 1, y + h - 2);
			}
		}
	}

	@Override
	protected void paintContentBorderTopEdge(Graphics g, int tabPlacement,
			int selectedIndex, int x, int y, int w, int h) {
		Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(
				selectedIndex, calcRect);

		// Draw unbroken line if tabs are not on TOP, OR
		// selected tab is not in run adjacent to content, OR
		// selected tab is not visible (SCROLL_TAB_LAYOUT)
		//
		if (tabPlacement != TOP || selectedIndex < 0
				|| (selRect.y + selRect.height + 1 < y)
				|| (selRect.x < x || selRect.x > x + w)) {
			g.setColor(darkShadow);
			g.drawLine(x + 1, y, x + w - 2, y);
			g.setColor(highlight);
			g.drawLine(x + 1, y + 1, x + w - 2, y + 1);
		} else {
			// Break line to show visual connection to selected tab
			SubstanceButtonShaper shaper = SubstanceLookAndFeel
					.getCurrentButtonShaper();
			int delta = (shaper instanceof ClassicButtonShaper) ? 0 : 1;
			g.setColor(darkShadow);
			g.drawLine(x + 1, y, selRect.x, y);
			g.setColor(highlight);
			g.drawLine(x + 1, y + 1, selRect.x - 1, y + 1);
			if (selRect.x + selRect.width < x + w - 2) {
				g.setColor(darkShadow);
				g.drawLine(selRect.x + selRect.width + delta - 2, y, x + w - 2,
						y);
				g.setColor(highlight);
				g.drawLine(selRect.x + selRect.width + delta - 1, y + 1, x + w
						- 2, y + 1);
				// } else {
				// g.setColor(shadow);
				// g.drawLine(x + w - 2, y, x + w - 2, y);
			}
		}
		g.setColor(SubstanceColorUtilities.getInterpolatedColor(darkShadow,
				highlight, 0.5));
		g.drawLine(x, y, x, y);
		g.drawLine(x + w - 1, y, x + w - 1, y);
	}

	@Override
	public Rectangle getTabBounds(JTabbedPane pane, int i) {
		ensureCurrentLayout();
		Rectangle tabRect = new Rectangle();
		return getTabBounds(i, tabRect);
	}
}