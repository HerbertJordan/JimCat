/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.scroll;

import java.awt.*;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.plaf.UIResource;

import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.painter.SimplisticSoftBorderGradientPainter;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Default border on {@link JScrollPane}s. Provides continuous appearance of
 * the border + scroll bars.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceScrollPaneBorder implements Border, UIResource {
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#getBorderInsets(java.awt.Component)
	 */
	public Insets getBorderInsets(Component c) {
		return new Insets(1, 1, 1, 1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#isBorderOpaque()
	 */
	public boolean isBorderOpaque() {
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.border.Border#paintBorder(java.awt.Component,
	 *      java.awt.Graphics, int, int, int, int)
	 */
	public void paintBorder(Component c, Graphics g, int x, int y, int width,
			int height) {
		JScrollPane scrollPane = (JScrollPane) c;
		JScrollBar vertical = scrollPane.getVerticalScrollBar();
		JScrollBar horizontal = scrollPane.getHorizontalScrollBar();

		StandardGradientPainter painter = new SimplisticSoftBorderGradientPainter();
		ColorScheme scheme = SubstanceCoreUtilities.getDefaultScheme(c);
		if (scrollPane.getComponentOrientation().isLeftToRight()) {
			// top portion
			g.setColor(painter.getTopBorderColor(scheme, scheme, 0, false));
			if (vertical.isVisible()) {
				g.drawLine(x, y, x + width - vertical.getWidth(), y);
			} else {
				g.drawLine(x, y, x + width, y);
			}

			// left portion
			g.setColor(painter.getTopBorderColor(scheme, scheme, 0, false));
			if (horizontal.isVisible()) {
				g.drawLine(x, y, x, y + height - horizontal.getHeight());
			} else {
				g.drawLine(x, y, x, y + height);
			}

			// bottom portion
			g.setColor(painter.getBottomBorderColor(scheme, scheme, 0, false));
			if (horizontal.isVisible()) {
				// g.drawLine(x + horizontal.getWidth(), y + height - 1,
				// x + width, y + height - 1);
			} else {
				if (vertical.isVisible()) {
					g.drawLine(x, y + height - 1, x + width
							- vertical.getWidth(), y + height - 1);
				} else {
					g.drawLine(x, y + height - 1, x + width, y + height - 1);
				}
			}

			// right portion
			g.setColor(painter.getBottomBorderColor(scheme, scheme, 0, false));
			if (vertical.isVisible()) {
				// g.drawLine(x + width - 1, y + vertical.getHeight(), x + width
				// - 1, y + height);
			} else {
				if (horizontal.isVisible())
					g.drawLine(x + width - 1, y, x + width - 1, y + height
							- horizontal.getHeight());
				else
					g.drawLine(x + width - 1, y, x + width - 1, y + height);
			}
		} else {
			// top portion
			g.setColor(painter.getTopBorderColor(scheme, scheme, 0, false));
			if (vertical.isVisible()) {
				g.drawLine(x + vertical.getWidth(), y, x + width, y);
			} else {
				g.drawLine(x, y, x + width, y);
			}

			// left portion
			g.setColor(painter.getBottomBorderColor(scheme, scheme, 0, false));
			if (vertical.isVisible()) {
				// g.drawLine(x, y, x, y + height - horizontal.getHeight());
			} else {
				if (horizontal.isVisible()) {
					g.drawLine(x, y, x, y + height - horizontal.getHeight());
				} else {
					g.drawLine(x, y, x, y + height - 1);
				}
			}

			// bottom portion
			g.setColor(painter.getBottomBorderColor(scheme, scheme, 0, false));
			if (horizontal.isVisible()) {
				// g.drawLine(x + horizontal.getWidth(), y + height - 1,
				// x + width, y + height - 1);
			} else {
				if (vertical.isVisible()) {
					g.drawLine(x + vertical.getWidth(), y + height - 1, x
							+ width, y + height - 1);
				} else {
					g.drawLine(x, y + height - 1, x + width, y + height - 1);
				}
			}

			// right portion
			g.setColor(painter.getTopBorderColor(scheme, scheme, 0, false));
			if (horizontal.isVisible()) {
				g.drawLine(x + width - 1, y, x + width - 1, y + height
						- horizontal.getHeight());
			} else {
				g.drawLine(x + width - 1, y, x + width - 1, y + height);
			}
		}
	}
}
