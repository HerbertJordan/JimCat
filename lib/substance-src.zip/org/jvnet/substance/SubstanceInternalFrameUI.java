/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;

import javax.swing.*;
import javax.swing.JInternalFrame.JDesktopIcon;
import javax.swing.event.MouseInputAdapter;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.title.*;
import org.jvnet.substance.title.TitleButtonManager.TitleButton;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for internal frames in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceInternalFrameUI extends BasicInternalFrameUI {
	/**
	 * Title pane
	 */
	private SubstanceInternalFrameTitlePane titlePane;

	/**
	 * Property name for the pinned indication. For internal use only.
	 */
	public static final String INTERNAL_FRAME_PINNED = "substancelaf.internal.internalFramePinned";

	/**
	 * List of core custom title buttons. Currently contains the pin/unpin
	 * button.
	 */
	protected List<TitleButton> coreCustomTitleButtons;

	/**
	 * Property listener on the associated internal frame.
	 */
	protected PropertyChangeListener substancePropertyListener;

	/**
	 * Simple constructor.
	 * 
	 * @param b
	 *            Associated internal frame.
	 */
	public SubstanceInternalFrameUI(JInternalFrame b) {
		super(b);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new SubstanceInternalFrameUI((JInternalFrame) c);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameUI#createNorthPane(javax.swing.JInternalFrame)
	 */
	@Override
	protected JComponent createNorthPane(JInternalFrame w) {
		this.titlePane = new SubstanceInternalFrameTitlePane(w,
				SubstanceCoreUtilities.toShowExtraElements(w));

		// f.putClientProperty(INTERNAL_FRAME_PINNED, Boolean.TRUE);

		return this.titlePane;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameUI#installComponents()
	 */
	@Override
	protected void installComponents() {
		super.installComponents();
		if (SubstanceLookAndFeel.toShowExtraElements()
				&& SubstanceCoreUtilities.canBePinned(this.frame)) {
			// Add pin toggle button
			final TitleButtonInfo tbInfo = new TitleButtonInfo();
			tbInfo.setActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (tbInfo.isSelected()) {
						frame.putClientProperty(INTERNAL_FRAME_PINNED,
								Boolean.TRUE);
					} else {
						frame.putClientProperty(INTERNAL_FRAME_PINNED, null);
					}
				}
			});
			tbInfo.setSelected(Boolean.TRUE.equals(frame
					.getClientProperty(INTERNAL_FRAME_PINNED)));
			tbInfo.setTooltipText(SubstanceLookAndFeel.getLabelBundle()
					.getString("InternalFrame.pinTooltip"));
			tbInfo.setButtonCallback(new TitleButtonCallback() {
				public Icon getTitleButtonIcon(
						SubstanceTheme currSubstanceTheme, int iconMaxWidth,
						int iconMaxHeight) {
					if (tbInfo.isSelected())
						return SubstanceImageCreator
								.getPinDownIcon(currSubstanceTheme);
					else
						return SubstanceImageCreator
								.getPinUpIcon(currSubstanceTheme);
				}
			});
			tbInfo.setToggle(true);

			List<TitleButtonInfo> infoList = new LinkedList<TitleButtonInfo>();
			infoList.add(tbInfo);

			this.coreCustomTitleButtons = TitleButtonManager.getManager()
					.addRootPaneCustomTitleButtons(frame.getRootPane(),
							infoList, true);

			if (SubstanceCoreUtilities.isPermanentlyPinned(this.frame)) {
				TitleButton pinButton = getPinButton();
				pinButton.tButtonInfo.setSelected(true);
				pinButton.tButton.setEnabled(false);
				pinButton.tButton.putClientProperty(
						SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY,
						Boolean.TRUE);
				TitleButtonManager.getManager().updateButton(pinButton);
			}
		} else {
			this.coreCustomTitleButtons = Collections.emptyList();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameUI#uninstallComponents()
	 */
	@Override
	protected void uninstallComponents() {
		TitleButtonManager.getManager().removeRootPaneCustomTitleButtons(
				frame.getRootPane(), this.coreCustomTitleButtons);

		this.titlePane.uninstall();
		super.uninstallComponents();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		this.substancePropertyListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (JInternalFrame.IS_CLOSED_PROPERTY.equals(evt
						.getPropertyName())) {
					TitleButtonManager
							.getManager()
							.removeRootPaneCustomTitleButtons(
									frame.getRootPane(), coreCustomTitleButtons);
					coreCustomTitleButtons.clear();
					titlePane.uninstall();
					JDesktopIcon jdi = frame.getDesktopIcon();
					SubstanceDesktopIconUI ui = (SubstanceDesktopIconUI) jdi
							.getUI();
					ui.uninstallUI(jdi);
				}

				if (SubstanceLookAndFeel.CAN_BE_PINNED.equals(evt
						.getPropertyName())) {
					boolean canBePinned = SubstanceLookAndFeel
							.toShowExtraElements()
							&& SubstanceCoreUtilities.canBePinned(frame);
					if (canBePinned) {
						// wasn't there before
						// Add pin toggle button
						final TitleButtonInfo tbInfo = new TitleButtonInfo();
						tbInfo.setActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								if (tbInfo.isSelected()) {
									frame
											.putClientProperty(
													INTERNAL_FRAME_PINNED,
													Boolean.TRUE);
								} else {
									frame.putClientProperty(
											INTERNAL_FRAME_PINNED, null);
								}
							}
						});
						tbInfo.setSelected(Boolean.TRUE.equals(frame
								.getClientProperty(INTERNAL_FRAME_PINNED)));
						tbInfo.setTooltipText(SubstanceLookAndFeel
								.getLabelBundle().getString(
										"InternalFrame.pinTooltip"));
						tbInfo.setButtonCallback(new TitleButtonCallback() {
							public Icon getTitleButtonIcon(
									SubstanceTheme currSubstanceTheme,
									int iconMaxWidth, int iconMaxHeight) {
								if (tbInfo.isSelected())
									return SubstanceImageCreator
											.getPinDownIcon(currSubstanceTheme);
								else
									return SubstanceImageCreator
											.getPinUpIcon(currSubstanceTheme);
							}
						});
						tbInfo.setToggle(true);

						List<TitleButtonInfo> infoList = new LinkedList<TitleButtonInfo>();
						infoList.add(tbInfo);

						TitleButtonManager.getManager()
								.removeRootPaneCustomTitleButtons(
										frame.getRootPane(),
										coreCustomTitleButtons);
						coreCustomTitleButtons = TitleButtonManager
								.getManager().addRootPaneCustomTitleButtons(
										frame.getRootPane(), infoList, true);
						TitleButtonManager.getManager().updateButton(
								getPinButton());
					} else {
						// is there - remove
						TitleButtonManager.getManager()
								.removeRootPaneCustomTitleButtons(
										frame.getRootPane(),
										coreCustomTitleButtons);
						coreCustomTitleButtons.clear();
					}
				}

				if (SubstanceLookAndFeel.PERMANENTLY_PINNED.equals(evt
						.getPropertyName())) {
					boolean isPinned = SubstanceCoreUtilities
							.isPermanentlyPinned(frame);
					TitleButton pinButton = getPinButton();
					if (pinButton != null) {
						if (isPinned) {
							// select the button and mark frame as pinned
							pinButton.tButtonInfo.setSelected(true);
							frame.putClientProperty(INTERNAL_FRAME_PINNED,
									Boolean.TRUE);

							// disable the button and mark it to not
							// paint its background
							pinButton.tButton.setEnabled(false);
							pinButton.tButton
									.putClientProperty(
											SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY,
											Boolean.TRUE);
						} else {
							pinButton.tButton.setEnabled(true);
							pinButton.tButton
									.putClientProperty(
											SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY,
											null);
						}
						TitleButtonManager.getManager().updateButton(pinButton);
					}
				}
			}
		};
		this.frame.addPropertyChangeListener(this.substancePropertyListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		this.frame.removePropertyChangeListener(this.substancePropertyListener);
		this.substancePropertyListener = null;
		super.uninstallListeners();
	}

	/**
	 * Returns the pin button of the associated internal frame.
	 * 
	 * @return The pin button of the associated internal frame.
	 */
	protected TitleButton getPinButton() {
		if (this.coreCustomTitleButtons != null)
			return this.coreCustomTitleButtons.get(0);
		return null;
	}

	// private class BorderListener1 extends BorderListener implements
	// SwingConstants {
	//
	// Rectangle getIconBounds() {
	// int xOffset = 5;
	// Rectangle rect = null;
	//
	// Icon icon = SubstanceInternalFrameUI.this.frame.getFrameIcon();
	// if (icon != null) {
	// int iconY = ((SubstanceInternalFrameUI.this.titlePane.getHeight() / 2) -
	// (icon
	// .getIconHeight() / 2));
	// rect = new Rectangle(xOffset, iconY, icon.getIconWidth(), icon
	// .getIconHeight());
	// }
	// return rect;
	// }
	//
	// @Override
	// public void mouseClicked(MouseEvent e) {
	// if ((e.getClickCount() == 2) && (e.getSource() ==
	// SubstanceInternalFrameUI.this.getNorthPane())
	// && SubstanceInternalFrameUI.this.frame.isClosable() &&
	// !SubstanceInternalFrameUI.this.frame.isIcon()) {
	// Rectangle rect = this.getIconBounds();
	// if ((rect != null) && rect.contains(e.getX(), e.getY())) {
	// SubstanceInternalFrameUI.this.frame.doDefaultCloseAction();
	// } else {
	// super.mouseClicked(e);
	// }
	// } else {
	// super.mouseClicked(e);
	// }
	// }
	// } // / End BorderListener Class
	//
	// /**
	// * Returns the <code>MouseInputAdapter<code> that will be installed
	// * on the TitlePane.
	// *
	// * @param w the <code>JInternalFrame</code>
	// * @return the <code>MouseInputAdapter</code> that will be installed
	// * on the TitlePane.
	// * @since 1.6
	// */
	// @Override
	// protected MouseInputAdapter createBorderListener(JInternalFrame w) {
	// return new BorderListener1();
	// }
	//
	/**
	 * Returns the title pane of the associated internal frame. This method is
	 * <b>for internal use only</b>.
	 * 
	 * @return Title pane of the associated internal frame.
	 */
	public SubstanceInternalFrameTitlePane getTitlePane() {
		return titlePane;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameUI#createBorderListener(javax.swing.JInternalFrame)
	 */
	@Override
	protected MouseInputAdapter createBorderListener(JInternalFrame w) {
		return new SubstanceBorderListener();
	}

	/**
	 * Border listener on the internal frame. Provides pin / unpin
	 * functionality.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class SubstanceBorderListener extends BorderListener {
		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.plaf.basic.BasicInternalFrameUI$BorderListener#mouseDragged(java.awt.event.MouseEvent)
		 */
		@Override
		public void mouseDragged(MouseEvent e) {
			if (Boolean.TRUE.equals(frame
					.getClientProperty(INTERNAL_FRAME_PINNED)))
				return;
			super.mouseDragged(e);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.plaf.basic.BasicInternalFrameUI$BorderListener#mouseMoved(java.awt.event.MouseEvent)
		 */
		@Override
		public void mouseMoved(MouseEvent e) {
			if (Boolean.TRUE.equals(frame
					.getClientProperty(INTERNAL_FRAME_PINNED)))
				return;
			super.mouseMoved(e);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.plaf.basic.BasicInternalFrameUI$BorderListener#mouseClicked(java.awt.event.MouseEvent)
		 */
		@Override
		public void mouseClicked(MouseEvent e) {
			if (Boolean.TRUE.equals(frame
					.getClientProperty(INTERNAL_FRAME_PINNED)))
				return;
			super.mouseClicked(e);
		}
	}
}
