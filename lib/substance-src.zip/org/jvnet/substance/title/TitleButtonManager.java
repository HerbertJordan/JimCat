/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.title;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.*;

import javax.swing.*;

import org.jvnet.substance.*;
import org.jvnet.substance.theme.ThemeChangeListener;
import org.jvnet.substance.utils.SubstanceTitlePane;

/**
 * Manager for custom buttons on title panes. This class is <b>for internal use
 * only</b>.
 * 
 * @author Kirill Grouchnikov
 * @since version 3.0
 */
public class TitleButtonManager {
	/**
	 * Maps between root panes and associated title pane buttons.
	 */
	private Map<JRootPane, List<AbstractButton>> customTitlePaneButtons;

	/**
	 * Maps between root panes and associated information on title pane buttons.
	 */
	private Map<JRootPane, List<TitleButton>> customTitlePaneButtonsExtra;

	/**
	 * Maps between root panes and theme change listeners.
	 */
	private Map<JRootPane, ThemeChangeListener> themeChangeListeners;

	/**
	 * Singleton instance of title button manager.
	 */
	private static TitleButtonManager instance;

	/**
	 * Information on a single title pane button.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static class TitleButton {
		/**
		 * Button component itself.
		 */
		public AbstractButton tButton;

		/**
		 * Information on the button.
		 */
		public TitleButtonInfo tButtonInfo;

		/**
		 * Creates new info object.
		 * 
		 * @param button
		 *            Button component itself.
		 * @param buttonInfo
		 *            Information on the button.
		 */
		public TitleButton(AbstractButton button, TitleButtonInfo buttonInfo) {
			super();
			tButton = button;
			tButtonInfo = buttonInfo;
		}
	}

	/**
	 * Creates a new title button manager.
	 */
	private TitleButtonManager() {
		this.customTitlePaneButtons = new WeakHashMap<JRootPane, List<AbstractButton>>();
		this.customTitlePaneButtonsExtra = new WeakHashMap<JRootPane, List<TitleButton>>();
		this.themeChangeListeners = new WeakHashMap<JRootPane, ThemeChangeListener>();
	}

	/**
	 * Returns an instance of title button manager.
	 * 
	 * @return Instance of title button manager.
	 */
	public static synchronized TitleButtonManager getManager() {
		if (instance == null)
			instance = new TitleButtonManager();
		return instance;
	}

	/**
	 * Registers custom title pane buttons for the specified root pane.
	 * 
	 * @param rootPane
	 *            Root pane.
	 * @param infoList
	 *            Information on custom title pane buttons.
	 * @param addAtBeginning
	 *            Indicates whether the buttons should be added before the
	 *            buttons that are already registered.
	 * @return The list of the buttons that have been added.
	 */
	public synchronized List<TitleButton> addRootPaneCustomTitleButtons(
			final JRootPane rootPane, List<TitleButtonInfo> infoList,
			boolean addAtBeginning) {
		ThemeChangeListener currThemeChangeListener = themeChangeListeners
				.get(rootPane);
		if (currThemeChangeListener != null)
			SubstanceLookAndFeel
					.unregisterThemeChangeListener(currThemeChangeListener);

		List<TitleButton> newButtonsExtra = new LinkedList<TitleButton>();
		List<AbstractButton> newButtons = new LinkedList<AbstractButton>();
		for (final TitleButtonInfo tButtonInfo : infoList) {
			final AbstractButton tButton = tButtonInfo.isToggle() ? new JToggleButton()
					: new JButton();
			tButton.setToolTipText(tButtonInfo.getTooltipText());
			tButton.addActionListener(tButtonInfo.getActionListener());
			tButton.putClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY,
					Boolean.TRUE);
			tButton.setFocusable(false);
			tButton.setFocusPainted(false);
			tButton.setSelected(tButtonInfo.isSelected());

			final TitleButton titleButton = new TitleButton(tButton,
					tButtonInfo);
			newButtonsExtra.add(titleButton);
			newButtons.add(0, tButton);

			if (tButtonInfo.isToggle()) {
				tButton.getModel().addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent e) {
						tButtonInfo
								.setSelected(tButton.getModel().isSelected());
						updateButton(titleButton);
					}
				});
			}
		}
		if (this.customTitlePaneButtons.get(rootPane) != null)
			this.customTitlePaneButtons.get(rootPane).addAll(newButtons);
		else
			this.customTitlePaneButtons.put(rootPane, newButtons);
		if (this.customTitlePaneButtonsExtra.get(rootPane) != null)
			this.customTitlePaneButtonsExtra.get(rootPane).addAll(
					newButtonsExtra);
		else
			this.customTitlePaneButtonsExtra.put(rootPane, newButtonsExtra);
		this.updateButtonIcons(rootPane);

		ThemeChangeListener newThemeChangeListener = new ThemeChangeListener() {
			public void themeChanged() {
				updateButtonIcons(rootPane);
			}
		};
		this.themeChangeListeners.put(rootPane, newThemeChangeListener);
		SubstanceLookAndFeel
				.registerThemeChangeListener(newThemeChangeListener);

		if (rootPane.getParent() instanceof JInternalFrame) {
			SubstanceInternalFrameUI ifUi = (SubstanceInternalFrameUI) ((JInternalFrame) rootPane
					.getParent()).getUI();
			SubstanceInternalFrameTitlePane titlePane = ifUi.getTitlePane();
			if (titlePane != null) {
				titlePane.addCustomTitleButtons(newButtons, addAtBeginning);
				titlePane.doLayout();
				titlePane.repaint();
			}
		} else {
			SubstanceRootPaneUI rootPaneUi = (SubstanceRootPaneUI) rootPane
					.getUI();
			SubstanceTitlePane titlePane = (SubstanceTitlePane) rootPaneUi
					.getTitlePane();
			if (titlePane != null) {
				titlePane.setCustomTitleButtons(newButtons);
				titlePane.doLayout();
				titlePane.repaint();
			}
		}
		List<TitleButton> result = new LinkedList<TitleButton>();
		for (TitleButton tb : newButtonsExtra)
			result.add(tb);
		return result;
	}

	/**
	 * Removes all custom title pane buttons registered on the specified root
	 * pane.
	 * 
	 * @param rootPane
	 *            Root pane.
	 */
	public synchronized void removeRootPaneCustomTitleButtons(
			final JRootPane rootPane) {
		ThemeChangeListener currThemeChangeListener = this.themeChangeListeners
				.remove(rootPane);
		if (currThemeChangeListener != null)
			SubstanceLookAndFeel
					.unregisterThemeChangeListener(currThemeChangeListener);
		this.themeChangeListeners.remove(rootPane);

		if (rootPane.getParent() instanceof JInternalFrame) {
			SubstanceInternalFrameUI ifUi = (SubstanceInternalFrameUI) ((JInternalFrame) rootPane
					.getParent()).getUI();
			SubstanceInternalFrameTitlePane titlePane = ifUi.getTitlePane();
			if (titlePane != null) {
				Collection<AbstractButton> removed = titlePane
						.removeAllCustomTitleButtons();
				titlePane.doLayout();
				titlePane.repaint();
				for (AbstractButton b : removed) {
					this.customTitlePaneButtons.get(rootPane).remove(b);
				}
				for (Iterator<TitleButton> it = this.customTitlePaneButtonsExtra
						.get(rootPane).iterator(); it.hasNext();) {
					TitleButton tb = it.next();
					if (removed.contains(tb.tButton))
						it.remove();
				}
			}
		} else {
			this.customTitlePaneButtons.remove(rootPane);
			this.customTitlePaneButtonsExtra.remove(rootPane);
			SubstanceRootPaneUI rootPaneUi = (SubstanceRootPaneUI) rootPane
					.getUI();
			SubstanceTitlePane titlePane = (SubstanceTitlePane) rootPaneUi
					.getTitlePane();
			if (titlePane != null) {
				titlePane.setCustomTitleButtons(null);
				titlePane.doLayout();
				titlePane.repaint();
			}
		}

		this.cleanup(rootPane);
	}

	/**
	 * Removes the specified custom title pane buttons registered on the
	 * specified root pane.
	 * 
	 * @param rootPane
	 *            Root pane.
	 * @param buttonList
	 *            Buttons to remove.
	 */
	public synchronized void removeRootPaneCustomTitleButtons(
			final JRootPane rootPane, List<TitleButton> buttonList) {
		// this.customTitlePaneButtons.remove(rootPane);
		// this.customTitlePaneButtonsExtra.remove(rootPane);
		// ThemeChangeListener currThemeChangeListener =
		// this.themeChangeListeners
		// .remove(rootPane);
		// if (currThemeChangeListener != null)
		// SubstanceLookAndFeel
		// .unregisterThemeChangeListener(currThemeChangeListener);

		List<AbstractButton> titleButtons = this.customTitlePaneButtons
				.get(rootPane);
		List<TitleButton> titleButtonsExtra = this.customTitlePaneButtonsExtra
				.get(rootPane);

		List<AbstractButton> toRemove = new LinkedList<AbstractButton>();

		if (buttonList != null) {
			for (TitleButton tb : buttonList) {
				toRemove.add(tb.tButton);
				titleButtons.remove(tb.tButton);
				titleButtonsExtra.remove(tb);
			}
		}

		if (rootPane.getParent() instanceof JInternalFrame) {
			SubstanceInternalFrameUI ifUi = (SubstanceInternalFrameUI) ((JInternalFrame) rootPane
					.getParent()).getUI();
			SubstanceInternalFrameTitlePane titlePane = ifUi.getTitlePane();
			if (titlePane != null) {
				titlePane.removeCustomTitleButtons(toRemove);
				titlePane.doLayout();
				titlePane.repaint();
			}
		} else {
		}

		this.cleanup(rootPane);
	}

	/**
	 * Cleans up all references to the specified root pane.
	 * 
	 * @param rootPane
	 *            Root pane.
	 */
	private synchronized void cleanup(JRootPane rootPane) {
		List<AbstractButton> btns = this.customTitlePaneButtons.get(rootPane);
		if ((btns != null) && (btns.size() == 0)) {
			this.customTitlePaneButtons.remove(rootPane);
		}
		List<TitleButton> xtra = this.customTitlePaneButtonsExtra.get(rootPane);
		if ((xtra != null) && (xtra.size() == 0)) {
			this.customTitlePaneButtonsExtra.remove(rootPane);
		}
		ThemeChangeListener tcl = this.themeChangeListeners.get(rootPane);
		if (tcl != null) {
			SubstanceLookAndFeel.unregisterThemeChangeListener(tcl);
			this.themeChangeListeners.remove(rootPane);
		}
	}

	/**
	 * Updates a single custom title pane button.
	 * 
	 * @param button
	 *            Title button.
	 */
	public void updateButton(TitleButton button) {
		Icon tIcon = button.tButtonInfo.getButtonCallback()
				.getTitleButtonIcon(SubstanceLookAndFeel.getTheme(),
						SubstanceTitlePane.IMAGE_WIDTH,
						SubstanceTitlePane.IMAGE_HEIGHT);
		if ((tIcon.getIconWidth() > SubstanceTitlePane.IMAGE_WIDTH)
				|| (tIcon.getIconHeight() > SubstanceTitlePane.IMAGE_HEIGHT))
			throw new IllegalArgumentException(
					"Title button callback returned image icon of illegal size");
		button.tButton.setIcon(tIcon);
		button.tButton.setDisabledIcon(tIcon);
		button.tButton.setDisabledSelectedIcon(tIcon);
		button.tButton.setSelected(button.tButtonInfo.isSelected());
	}

	/**
	 * Updates button icons of title pane of the specified root pane.
	 * 
	 * @param rootPane
	 *            Root pane.
	 */
	private void updateButtonIcons(JRootPane rootPane) {
		List<TitleButton> tButtons = this.customTitlePaneButtonsExtra
				.get(rootPane);
		if (tButtons == null)
			return;
		for (TitleButton tButton : tButtons) {
			updateButton(tButton);
		}
	}

	/**
	 * Returns custom buttons of title pane of the specified root pane.
	 * 
	 * @param rootPane
	 *            Root pane.
	 * @return Custom buttons of title pane of the specified root pane.
	 */
	public List<AbstractButton> getCustomButtons(JRootPane rootPane) {
		return this.customTitlePaneButtons.get(rootPane);
	}
}
