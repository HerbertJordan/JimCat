/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.JInternalFrame.JDesktopIcon;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;

import org.jvnet.lafwidget.LafWidgetUtilities;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.title.SubstanceTitlePainter;
import org.jvnet.substance.title.TitleButtonManager;
import org.jvnet.substance.title.TitleButtonManager.TitleButton;
import org.jvnet.substance.utils.*;
import org.jvnet.substance.utils.SubstanceConstants.ButtonTitleKind;
import org.jvnet.substance.utils.icon.SubstanceIconFactory;

/**
 * UI for internal frame title pane in <b>Substance </b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceInternalFrameTitlePane extends
		BasicInternalFrameTitlePane {
	/**
	 * Listens on the changes to the internal frame title.
	 */
	protected PropertyChangeListener substancePropertyListener;

	/**
	 * Listens to the changes to the
	 * {@link SubstanceLookAndFeel#WINDOW_MODIFIED} property on the internal
	 * frame and its root pane.
	 */
	protected PropertyChangeListener substanceWinModifiedListener;

	/**
	 * Custom title buttons for the associated internal frame.
	 */
	protected List<AbstractButton> customTitleButtons;

	/**
	 * Simple constructor.
	 * 
	 * @param f
	 *            Associated internal frame.
	 * @param setCustomButtons
	 *            if <code>true</code>, the {@link TitleButtonManager} will
	 *            be queried for the registered custom title buttons.
	 */
	public SubstanceInternalFrameTitlePane(JInternalFrame f,
			boolean setCustomButtons) {
		super(f);
		this.setToolTipText(f.getTitle());

		this.customTitleButtons = new ArrayList<AbstractButton>();
		if (setCustomButtons) {
			this.addCustomTitleButtons(TitleButtonManager.getManager()
					.getCustomButtons(f.getRootPane()), false);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameTitlePane#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		this.substancePropertyListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (JInternalFrame.TITLE_PROPERTY.equals(evt.getPropertyName())) {
					SubstanceInternalFrameTitlePane.this
							.setToolTipText((String) evt.getNewValue());
				}
				if (SubstanceInternalFrameUI.INTERNAL_FRAME_PINNED.equals(evt
						.getPropertyName())) {
					enableActions();
				}
			}
		};
		this.frame.addPropertyChangeListener(this.substancePropertyListener);

		// Property change listener for pulsating close button
		// when window has been marked as changed.
		this.substanceWinModifiedListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (SubstanceLookAndFeel.WINDOW_MODIFIED.equals(evt
						.getPropertyName())) {
					syncCloseButtonTooltip();
					// if (Boolean.TRUE.equals(evt.getNewValue())) {
					// SubstanceInternalFrameTitlePane.this.closeButton
					// .setToolTipText(SubstanceLookAndFeel
					// .getLabelBundle().getString(
					// "SystemMenu.close")
					// + " ["
					// + SubstanceLookAndFeel
					// .getLabelBundle()
					// .getString(
					// "Tooltip.contentsNotSaved")
					// + "]");
					// } else {
					// SubstanceInternalFrameTitlePane.this.closeButton
					// .setToolTipText(SubstanceLookAndFeel
					// .getLabelBundle().getString(
					// "SystemMenu.close"));
					// }
				}
			}
		};
		// Wire it on the frame itself and its root pane.
		this.frame.addPropertyChangeListener(this.substanceWinModifiedListener);
		this.frame.getRootPane().addPropertyChangeListener(
				this.substanceWinModifiedListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameTitlePane#uninstallListeners()
	 */
	@Override
	public void uninstallListeners() {
		this.frame.removePropertyChangeListener(this.substancePropertyListener);
		this.substancePropertyListener = null;

		this.frame
				.removePropertyChangeListener(this.substanceWinModifiedListener);
		this.frame.getRootPane().removePropertyChangeListener(
				this.substanceWinModifiedListener);
		this.substanceWinModifiedListener = null;

		ButtonBackgroundDelegate.untrackTitleButton(this.closeButton);
		ButtonBackgroundDelegate.untrackTitleButton(this.iconButton);
		ButtonBackgroundDelegate.untrackTitleButton(this.maxButton);

		// if ((this.menuBar != null) && (this.menuBar.getMenuCount() > 0)) {
		// if (this.getParent() instanceof JInternalFrame)
		// this.menuBar.getUI().uninstallUI(this.menuBar);
		// SubstanceTitlePane.uninstallMenu(this.menuBar.getMenu(0));
		// }

		super.uninstallListeners();
	}

	/**
	 * Uninstalls <code>this</code> title pane.
	 */
	public void uninstall() {
		if ((this.menuBar != null) && (this.menuBar.getMenuCount() > 0)) {
			this.menuBar.getUI().uninstallUI(this.menuBar);
			SubstanceTitlePane.uninstallMenu(this.menuBar.getMenu(0));
		}
		this.uninstallListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameTitlePane#enableActions()
	 */
	@Override
	protected void enableActions() {
		super.enableActions();

		boolean isPinned = Boolean.TRUE
				.equals(this.frame
						.getClientProperty(SubstanceInternalFrameUI.INTERNAL_FRAME_PINNED));
		if (!this.frame.isIcon()) {
			if (isPinned) {
				this.maximizeAction.setEnabled(false);
				this.restoreAction.setEnabled(false);
				this.iconifyAction.setEnabled(false);
			}
			if (this.maxButton != null)
				this.maxButton.setEnabled(this.maximizeAction.isEnabled()
						|| this.restoreAction.isEnabled());
			if (this.iconButton != null)
				this.iconButton.setEnabled(this.iconifyAction.isEnabled());
		}
	}

	// protected static Map<String, BufferedImage> imageCache = new
	// LinkedHashMap<String, BufferedImage>() {
	// @Override
	// protected boolean removeEldestEntry(Entry<String, BufferedImage> eldest)
	// {
	// return this.size() > 50;
	// }
	// };
	//
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	@Override
	public void paintComponent(Graphics g) {
		// if (this.isPalette) {
		// this.paintPalette(g);
		// return;
		// }
		Graphics2D graphics = (Graphics2D) g.create();
		// Desktop icon is translucent.
		float coef = (this.getParent() instanceof JDesktopIcon) ? 0.6f : 1.0f;
		graphics.setComposite(TransitionLayout.getAlphaComposite(this.frame,
				coef));

		boolean isSelected = this.frame.isSelected();
		boolean leftToRight = this.frame.getComponentOrientation()
				.isLeftToRight();

		int width = this.getWidth();
		int height = this.getHeight() + 2;

		SubstanceTheme theme = isSelected ? SubstanceLookAndFeel.getTheme()
				.getActiveTitlePaneTheme() : SubstanceCoreUtilities
				.getDefaultTheme(this.frame, true);
		String theTitle = this.frame.getTitle();

		// offset of border
		int xOffset = 0;
		int leftEnd;
		int rightEnd;

		if (leftToRight) {
			xOffset = 5;
			Icon icon = this.frame.getFrameIcon();
			if (icon != null) {
				xOffset += icon.getIconWidth() + 5;
			}

			leftEnd = (this.menuBar == null) ? 0
					: (this.menuBar.getWidth() + 5);
			xOffset += leftEnd;
			if (icon != null)
				leftEnd += (icon.getIconWidth() + 5);

			rightEnd = width - 5;

			// find the leftmost button for the right end
			AbstractButton leftmostButton = null;
			if (this.frame.isIconifiable()) {
				leftmostButton = this.iconButton;
			} else {
				if (this.frame.isMaximizable()) {
					leftmostButton = this.maxButton;
				} else {
					if (this.frame.isClosable()) {
						leftmostButton = this.closeButton;
					}
				}
			}

			if (customTitleButtons.size() > 0) {
				leftmostButton = customTitleButtons.get(customTitleButtons
						.size() - 1);
			}

			if (leftmostButton != null) {
				Rectangle rect = leftmostButton.getBounds();
				rightEnd = rect.getBounds().x - 5;
			}
			if (theTitle != null) {
				FontMetrics fm = this.frame.getFontMetrics(graphics.getFont());
				int titleWidth = rightEnd - leftEnd - 30;
				String clippedTitle = SubstanceCoreUtilities.clipString(fm,
						titleWidth, theTitle);
				// show tooltip with full title only if necessary
				if (theTitle.equals(clippedTitle))
					this.setToolTipText(null);
				else
					this.setToolTipText(theTitle);
				theTitle = clippedTitle;
			}
		} else {
			xOffset = width - 5;

			Icon icon = this.frame.getFrameIcon();
			if (icon != null) {
				xOffset -= (icon.getIconWidth() + 5);
			}

			rightEnd = (this.menuBar == null) ? xOffset : xOffset
					- this.menuBar.getWidth() - 5;

			// find the rightmost button for the left end
			AbstractButton rightmostButton = null;
			if (this.frame.isIconifiable()) {
				rightmostButton = this.iconButton;
			} else {
				if (this.frame.isMaximizable()) {
					rightmostButton = this.maxButton;
				} else {
					if (this.frame.isClosable()) {
						rightmostButton = this.closeButton;
					}
				}
			}
			if (customTitleButtons.size() > 0) {
				rightmostButton = customTitleButtons.get(customTitleButtons
						.size() - 1);
			}

			leftEnd = 5;
			if (rightmostButton != null) {
				Rectangle rect = rightmostButton.getBounds();
				leftEnd = rect.getBounds().x + 5;
			}
			if (theTitle != null) {
				FontMetrics fm = this.frame.getFontMetrics(graphics.getFont());
				int titleWidth = rightEnd - leftEnd - 30;
				String clippedTitle = SubstanceCoreUtilities.clipString(fm,
						titleWidth, theTitle);
				// show tooltip with full title only if necessary
				if (theTitle.equals(clippedTitle)) {
					this.setToolTipText(null);
				} else {
					this.setToolTipText(theTitle);
				}
				theTitle = clippedTitle;
				xOffset = rightEnd - fm.stringWidth(theTitle);
			}
		}

		SubstanceTitlePainter titlePainter = SubstanceCoreUtilities
				.getTitlePainter(this.frame);

		titlePainter.paintTitleBackground(graphics, this.frame, width,
				height + 1, leftEnd, rightEnd, theme, false);

		if (SubstanceCoreUtilities.toDrawWatermark(this)) {
			// paint the watermark over the title pane
			if (!Boolean.TRUE.equals(this
					.getClientProperty(LafWidgetUtilities.PREVIEW_MODE)))
				SubstanceLookAndFeel.getCurrentWatermark().drawWatermarkImage(
						graphics, this, 0, 0, width, height);

			// paint the background second time with 50% translucency, making
			// the watermark 'bleed' through.
			Composite oldComp = graphics.getComposite();
			graphics.setComposite(TransitionLayout.getAlphaComposite(
					this.frame, coef * 0.5f));
			titlePainter.paintTitleBackground(graphics, this.frame, width,
					height + 1, leftEnd, rightEnd, theme, false);
			graphics.setComposite(oldComp);
		}

		Icon icon = this.frame.getFrameIcon();
		if (icon != null) {
			if (leftToRight) {
				int iconY = ((height / 2) - (icon.getIconHeight() / 2));
				icon.paintIcon(this.frame, graphics, 5, iconY);
			} else {
				int iconY = ((height / 2) - (icon.getIconHeight() / 2));
				icon.paintIcon(this.frame, graphics, width - 5
						- icon.getIconWidth(), iconY);
			}
		}

		// draw the title (if needed)
		if (theTitle != null) {
			FontMetrics fm = this.frame.getFontMetrics(graphics.getFont());
			int yOffset = ((height - fm.getHeight()) / 2) + fm.getAscent();

			Object oldAAValue = graphics
					.getRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING);
			graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
			Color foregroundColor = SubstanceCoreUtilities.isThemeDark(theme) ? theme
					.getColorScheme().getForegroundColor()
					: theme.getColorScheme().getUltraDarkColor().darker();

			// blur the text shadow
			BufferedImage blurred = SubstanceCoreUtilities.getBlankImage(width,
					height);
			Graphics2D gBlurred = (Graphics2D) blurred.getGraphics();
			gBlurred.setFont(graphics.getFont());
			gBlurred.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
			gBlurred.setColor(SubstanceColorUtilities
					.getNegativeColor(foregroundColor));
			ConvolveOp convolve = new ConvolveOp(new Kernel(3, 3, new float[] {
					.0f, .05f, .1f, .05f, .0f, .1f, .1f, .1f, .1f }),
					ConvolveOp.EDGE_NO_OP, null);
			gBlurred.drawString(theTitle, xOffset + 1, yOffset + 1);
			blurred = convolve.filter(blurred, null);

			graphics.drawImage(blurred, 0, 0, null);

			graphics.setColor(foregroundColor);
			graphics.drawString(theTitle, xOffset, yOffset);
			graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					oldAAValue);
		}
		graphics.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameTitlePane#setButtonIcons()
	 */
	@Override
	protected void setButtonIcons() {
		super.setButtonIcons();
		SubstanceTheme iconTheme = SubstanceLookAndFeel.getTheme();

		Icon restoreIcon = SubstanceIconFactory.getTitlePaneIcon(
				SubstanceIconFactory.IconKind.RESTORE, iconTheme);
		Icon maximizeIcon = SubstanceIconFactory.getTitlePaneIcon(
				SubstanceIconFactory.IconKind.MAXIMIZE, iconTheme);
		Icon minimizeIcon = SubstanceIconFactory.getTitlePaneIcon(
				SubstanceIconFactory.IconKind.MINIMIZE, iconTheme);
		Icon closeIcon = SubstanceIconFactory.getTitlePaneIcon(
				SubstanceIconFactory.IconKind.CLOSE, iconTheme);
		if (this.frame.isIcon()) {
			this.iconButton.setIcon(restoreIcon);
			this.iconButton.setToolTipText(SubstanceLookAndFeel
					.getLabelBundle().getString("SystemMenu.restore"));
			this.maxButton.setIcon(maximizeIcon);
			this.maxButton.setToolTipText(SubstanceLookAndFeel.getLabelBundle()
					.getString("SystemMenu.maximize"));
		} else {
			this.iconButton.setIcon(minimizeIcon);
			this.iconButton.setToolTipText(SubstanceLookAndFeel
					.getLabelBundle().getString("SystemMenu.iconify"));
			if (this.frame.isMaximum()) {
				this.maxButton.setIcon(restoreIcon);
				this.maxButton.setToolTipText(SubstanceLookAndFeel
						.getLabelBundle().getString("SystemMenu.restore"));
			} else {
				this.maxButton.setIcon(maximizeIcon);
				this.maxButton.setToolTipText(SubstanceLookAndFeel
						.getLabelBundle().getString("SystemMenu.maximize"));
			}
		}
		if (closeIcon != null) {
			this.closeButton.setIcon(closeIcon);
			// this.closeButton.setToolTipText(SubstanceLookAndFeel
			// .getLabelBundle().getString("SystemMenu.close"));
			syncCloseButtonTooltip();
		}
	}

	/**
	 * Click correction listener that resets models of minimize and restore
	 * buttons on click (so that the rollover behaviour will be preserved
	 * correctly).
	 * 
	 * @author Kirill Grouchnikov.
	 */
	public static class ClickListener implements ActionListener {
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		public void actionPerformed(ActionEvent e) {
			AbstractButton src = (AbstractButton) e.getSource();
			ButtonModel model = src.getModel();
			model.setArmed(false);
			model.setPressed(false);
			model.setRollover(false);
			model.setSelected(false);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameTitlePane#createButtons()
	 */
	@Override
	protected void createButtons() {
		super.createButtons();
		for (ActionListener listener : this.iconButton.getActionListeners())
			if (listener instanceof ClickListener)
				return;
		this.iconButton.addActionListener(new ClickListener());
		for (ActionListener listener : this.maxButton.getActionListeners())
			if (listener instanceof ClickListener)
				return;
		this.maxButton.addActionListener(new ClickListener());
		ButtonBackgroundDelegate.trackTitleButton(this.iconButton,
				ButtonTitleKind.REGULAR);
		this.iconButton.putClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY,
				Boolean.TRUE);

		ButtonBackgroundDelegate.trackTitleButton(this.maxButton,
				ButtonTitleKind.REGULAR);
		this.maxButton.putClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY,
				Boolean.TRUE);

		ButtonBackgroundDelegate.trackTitleButton(this.closeButton,
				ButtonTitleKind.CLOSE);
		this.closeButton.putClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY,
				Boolean.TRUE);

		this.enableActions();
	}

	/**
	 * Adds a list of custom title buttons. This method is <b>for internal use
	 * only</b>.
	 * 
	 * @param customTitleButtons
	 *            List of custom title buttons.
	 * @param addAtBeginning
	 *            Indicates whether the specified buttons should be added before
	 *            the existing custom buttons.
	 */
	public void addCustomTitleButtons(List<AbstractButton> customTitleButtons,
			boolean addAtBeginning) {
		if (customTitleButtons != null) {
			for (AbstractButton tButton : customTitleButtons) {
				if (addAtBeginning)
					this.customTitleButtons.add(0, tButton);
				else
					this.customTitleButtons.add(tButton);
				this.add(tButton);
			}
		}
	}

	/**
	 * Removes a list of custom title buttons. This method is <b>for internal
	 * use only</b>.
	 * 
	 * @param customTitleButtons
	 *            List of custom title buttons.
	 */
	public void removeCustomTitleButtons(List<AbstractButton> customTitleButtons) {
		if (customTitleButtons != null) {
			for (AbstractButton tButton : customTitleButtons) {
				this.customTitleButtons.remove(tButton);
				this.remove(tButton);
			}
		}
	}

	/**
	 * Removes all custom title buttons. This method is <b>for internal use only</b>.
	 * 
	 * @return The set of the removed buttons.
	 */
	public Collection<AbstractButton> removeAllCustomTitleButtons() {
		SubstanceInternalFrameUI ui = (SubstanceInternalFrameUI) frame.getUI();
		List<TitleButton> coreButtons = ui.coreCustomTitleButtons;
		Set<AbstractButton> coreSet = new HashSet<AbstractButton>();
		for (TitleButton tb : coreButtons)
			coreSet.add(tb.tButton);

		Set<AbstractButton> result = new HashSet<AbstractButton>();
		for (Iterator<AbstractButton> it = this.customTitleButtons.iterator(); it
				.hasNext();) {
			AbstractButton b = it.next();
			if (coreSet.contains(b))
				continue;
			this.remove(b);
			result.add(b);
			it.remove();
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicInternalFrameTitlePane#createLayout()
	 */
	protected LayoutManager createLayout() {
		return new SubstanceTitlePaneLayout();
	}

	/**
	 * Synchronizes the tooltip of the close button.
	 */
	protected void syncCloseButtonTooltip() {
		if (SubstanceCoreUtilities.isInternalFrameModified(this.frame)) {
			this.closeButton.setToolTipText(SubstanceLookAndFeel
					.getLabelBundle().getString("SystemMenu.close")
					+ " ["
					+ SubstanceLookAndFeel.getLabelBundle().getString(
							"Tooltip.contentsNotSaved") + "]");
		} else {
			this.closeButton.setToolTipText(SubstanceLookAndFeel
					.getLabelBundle().getString("SystemMenu.close"));
		}
		this.closeButton.repaint();
	}

	/**
	 * Layout manager for this title pane.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class SubstanceTitlePaneLayout extends TitlePaneLayout {
		public void addLayoutComponent(String name, Component c) {
		}

		public void removeLayoutComponent(Component c) {
		}

		public Dimension preferredLayoutSize(Container c) {
			return minimumLayoutSize(c);
		}

		public Dimension minimumLayoutSize(Container c) {
			// Compute width.
			int width = 30;
			if (frame.isClosable()) {
				width += 21;
			}
			if (frame.isMaximizable()) {
				width += 16 + (frame.isClosable() ? 10 : 4);
			}
			if (frame.isIconifiable()) {
				width += 16 + (frame.isMaximizable() ? 2
						: (frame.isClosable() ? 10 : 4));
			}
			FontMetrics fm = frame.getFontMetrics(getFont());
			String frameTitle = frame.getTitle();
			int title_w = frameTitle != null ? fm.stringWidth(frameTitle) : 0;
			int title_length = frameTitle != null ? frameTitle.length() : 0;

			if (title_length > 2) {
				int subtitle_w = fm.stringWidth(frame.getTitle()
						.substring(0, 2)
						+ "...");
				width += (title_w < subtitle_w) ? title_w : subtitle_w;
			} else {
				width += title_w;
			}

			// Compute height.
			int height = 0;
			// if (isPalette) {
			// height = paletteTitleHeight;
			// } else {
			int fontHeight = fm.getHeight();
			fontHeight += 7;
			Icon icon = frame.getFrameIcon();
			int iconHeight = 0;
			if (icon != null) {
				// SystemMenuBar forces the icon to be 16x16 or less.
				iconHeight = Math.min(icon.getIconHeight(), 16);
			}
			iconHeight += 5;
			height = Math.max(fontHeight, iconHeight);
			// }

			return new Dimension(width, height);
		}

		public void layoutContainer(Container c) {
			boolean leftToRight = frame.getComponentOrientation()
					.isLeftToRight();

			int w = getWidth();
			int x = leftToRight ? w : 0;
			int y = 2;
			int spacing;

			// assumes all buttons have the same dimensions
			// these dimensions include the borders
			int buttonHeight = closeButton.getIcon().getIconHeight();
			int buttonWidth = closeButton.getIcon().getIconWidth();

			if (frame.isClosable()) {
				// if (isPalette) {
				// spacing = 3;
				// x += leftToRight ? -spacing - (buttonWidth + 2) : spacing;
				// closeButton.setBounds(x, y, buttonWidth + 2,
				// getHeight() - 4);
				// if (!leftToRight)
				// x += (buttonWidth + 2);
				// } else {
				spacing = 4;
				x += leftToRight ? -spacing - buttonWidth : spacing;
				closeButton.setBounds(x, y, buttonWidth, buttonHeight);
				if (!leftToRight)
					x += buttonWidth;
				// }
			}

			if (frame.isMaximizable()) {// && !isPalette) {
				spacing = frame.isClosable() ? 10 : 4;
				x += leftToRight ? -spacing - buttonWidth : spacing;
				maxButton.setBounds(x, y, buttonWidth, buttonHeight);
				if (!leftToRight)
					x += buttonWidth;
			}

			if (frame.isIconifiable()) {// && !isPalette) {
				spacing = frame.isMaximizable() ? 2 : (frame.isClosable() ? 10
						: 4);
				x += leftToRight ? -spacing - buttonWidth : spacing;
				iconButton.setBounds(x, y, buttonWidth, buttonHeight);
				if (!leftToRight)
					x += buttonWidth;
			}

			if (customTitleButtons.size() > 0) {
				for (AbstractButton tButton : customTitleButtons) {
					spacing = 2;
					x += leftToRight ? -spacing - buttonWidth : spacing;
					tButton.setBounds(x, y, buttonWidth, buttonHeight);
					if (!leftToRight) {
						x += buttonWidth;
					}
				}
			}

			//        
			// buttonsWidth = leftToRight ? w - x : x;
		}
	}
}
