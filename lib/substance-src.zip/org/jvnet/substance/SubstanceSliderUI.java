/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.event.MouseEvent;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicSliderUI;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.button.BaseButtonShaper;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.utils.*;
import org.jvnet.substance.utils.SubstanceConstants.FocusKind;

/**
 * UI for sliders in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceSliderUI extends BasicSliderUI implements Trackable {
	/**
	 * Background delegate.
	 */
	private static SubstanceFillBackgroundDelegate bgDelegate = new SubstanceFillBackgroundDelegate();

	/**
	 * Surrogate button model for tracking the thumb transitions.
	 */
	private ButtonModel thumbModel;

	/**
	 * Listener for fade animations.
	 */
	private RolloverControlListener substanceRolloverListener;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new SubstanceSliderUI();
	}

	/**
	 * Simple constructor.
	 */
	public SubstanceSliderUI() {
		super(null);
		this.thumbModel = new DefaultButtonModel();
		this.thumbModel.setArmed(false);
		this.thumbModel.setSelected(false);
		this.thumbModel.setPressed(false);
		this.thumbModel.setRollover(false);
	}

	/**
	 * Returns the rectangle of track for painting.
	 * 
	 * @return The rectangle of track for painting.
	 */
	private Rectangle getPaintTrackRect() {
		int trackLeft = 0, trackRight = 0, trackTop = 0, trackBottom = 0;
		if (this.slider.getOrientation() == SwingConstants.HORIZONTAL) {
			trackBottom = (this.trackRect.height - 1) - this.getThumbOverhang();
			trackTop = trackBottom - (this.getTrackWidth() - 1);
			trackRight = this.trackRect.width - 1;
		} else {
			if (this.slider.getComponentOrientation().isLeftToRight()) {
				trackLeft = (this.trackRect.width - this.getTrackWidth()) / 2;
				// - this.getThumbOverhang();// (this.trackRect.width -
				// this.getThumbOverhang())
				// - this.getTrackWidth();
				trackRight = trackLeft + this.getTrackWidth();// (this.trackRect.width
																// -
																// this.getThumbOverhang())
																// - 1;
			} else {
				trackRight = (this.trackRect.width + this.getTrackWidth()) / 2;
				// - this.getThumbOverhang();// (this.trackRect.width -
				// this.getThumbOverhang())
				// - this.getTrackWidth();
				trackLeft = trackRight - this.getTrackWidth();// (this.trackRect.width
																// -
																// this.getThumbOverhang())
																// - 1;
				// trackLeft = this.getThumbOverhang();
				// trackRight = this.getThumbOverhang() + this.getTrackWidth() -
				// 1;
			}
			trackBottom = this.trackRect.height - 1;
		}
		return new Rectangle(this.trackRect.x + trackLeft, this.trackRect.y
				+ trackTop, trackRight - trackLeft, trackBottom - trackTop);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSliderUI#paintTrack(java.awt.Graphics)
	 */
	@Override
	public void paintTrack(Graphics g) {
		Graphics2D graphics = (Graphics2D) g;
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		boolean drawInverted = this.drawInverted();

		// Translate to the origin of the painting rectangle
		Rectangle paintRect = this.getPaintTrackRect();
		graphics.translate(paintRect.x, paintRect.y);

		// Width and height of the painting rectangle.
		int width = paintRect.width;
		int height = paintRect.height;

		boolean isDark = SubstanceCoreUtilities
				.isThemeDark(SubstanceLookAndFeel.getTheme());
		ColorScheme borderColorScheme = this.slider.isEnabled() ? SubstanceCoreUtilities
				.getActiveScheme(this.slider)
				: SubstanceCoreUtilities.getDefaultScheme(this.slider);

		Color borderColor1 = isDark ? borderColorScheme.getExtraLightColor()
				: borderColorScheme.getUltraDarkColor();
		Color borderColor2 = isDark ? borderColorScheme.getUltraLightColor()
				: borderColorScheme.getDarkColor();

		// draw border
		// graphics.setColor(borderColorSchemeEnum.getColorScheme().getDarkColor());
		graphics.setStroke(new BasicStroke((float) 1.1, BasicStroke.CAP_ROUND,
				BasicStroke.JOIN_ROUND));

		int radius = 0;
		if (SubstanceLookAndFeel.getCurrentButtonShaper() instanceof ClassicButtonShaper) {
			radius = 4;
		} else {
			if (this.slider.getOrientation() == SwingConstants.HORIZONTAL) {
				radius = height;
			} else {
				radius = width;
			}
		}

		if (this.slider.getOrientation() == SwingConstants.HORIZONTAL) {
			graphics.setPaint(new GradientPaint(0, 0, borderColor1, 0,
					height - 1, borderColor2));
			graphics.drawRoundRect(0, 0, width, height, radius, radius);
		} else {
			graphics.setPaint(new GradientPaint(0, 0, borderColor1, width - 1,
					0, borderColor2));
			graphics.drawRoundRect(0, 0, width, height, radius, radius);
		}

		Color fillColor1 = isDark ? borderColorScheme.getUltraLightColor()
				: borderColorScheme.getUltraLightColor();
		Color fillColor2 = isDark ? borderColorScheme.getExtraLightColor()
				: borderColorScheme.getLightColor();

		// fill selected portion
		if (this.slider.isEnabled()) {
			if (this.slider.getOrientation() == SwingConstants.HORIZONTAL) {
				int middleOfThumb = this.thumbRect.x
						+ (this.thumbRect.width / 2) - paintRect.x;
				int fillMinX;
				int fillMaxX;

				graphics.setPaint(new GradientPaint(0, 1, fillColor1, 0,
						height - 1, fillColor2));

				if (drawInverted) {
					fillMinX = middleOfThumb;
					fillMaxX = width - 2;
				} else {
					fillMinX = 1;
					fillMaxX = middleOfThumb;
				}

				graphics.fillRoundRect(fillMinX, 1, fillMaxX - fillMinX + 2,
						height - 1, (radius - 2), (radius - 2));
			} else {
				int middleOfThumb = this.thumbRect.y
						+ (this.thumbRect.height / 2) - paintRect.y;
				int fillMinY;
				int fillMaxY;

				graphics.setPaint(new GradientPaint(1, 0, fillColor1,
						width - 1, 0, fillColor2));

				if (this.drawInverted()) {
					fillMinY = 1;
					fillMaxY = middleOfThumb;
				} else {
					fillMinY = middleOfThumb;
					fillMaxY = height - 2;
				}
				graphics.fillRoundRect(1, fillMinY, width - 1, fillMaxY
						- fillMinY + 2, (radius - 2), (radius - 2));
			}
		}

		g.translate(-paintRect.x, -paintRect.y);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSliderUI#paintThumb(java.awt.Graphics)
	 */
	public void paintThumb(Graphics g) {
		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setComposite(TransitionLayout.getAlphaComposite(this.slider));
		Rectangle knobBounds = thumbRect;

		graphics.translate(knobBounds.x, knobBounds.y);

		if (slider.getOrientation() == JSlider.HORIZONTAL) {
			UIManager.getIcon("Slider.horizontalThumbIcon").paintIcon(slider,
					graphics, 0, 2);
		} else {
			UIManager.getIcon("Slider.verticalThumbIcon").paintIcon(slider,
					graphics, 2, 0);
		}

		// graphics.translate(-knobBounds.x, -knobBounds.y);
		graphics.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public synchronized void paint(Graphics g, JComponent c) {
		// important to synchronize on the slider as we are
		// about to fiddle with its opaqueness
		synchronized (c) {
			SubstanceSliderUI.bgDelegate.update(g, c);
			// remove opaqueness
			boolean isOpaque = c.isOpaque();
			c.setOpaque(false);
			super.paint(g, c);
			// restore opaqueness
			c.setOpaque(isOpaque);
		}
	}

	/**
	 * Returns the button model for tracking the thumb transitions.
	 * 
	 * @return Button model for tracking the thumb transitions.
	 */
	public ButtonModel getButtonModel() {
		return this.thumbModel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.Trackable#isInside(java.awt.event.MouseEvent)
	 */
	public boolean isInside(MouseEvent me) {
		Rectangle thumbB = this.thumbRect;
		if (thumbB == null)
			return false;
		return thumbB.contains(me.getX(), me.getY());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSliderUI#installListeners(javax.swing.JSlider)
	 */
	@Override
	protected void installListeners(JSlider slider) {
		super.installListeners(slider);

		// fix for defect 109 - memory leak on changing theme
		this.substanceRolloverListener = new RolloverControlListener(this,
				this.thumbModel);
		slider.addMouseListener(this.substanceRolloverListener);
		slider.addMouseMotionListener(this.substanceRolloverListener);
	}

	@Override
	protected void uninstallListeners(JSlider slider) {
		super.uninstallListeners(slider);

		// fix for defect 109 - memory leak on changing theme
		slider.removeMouseListener(this.substanceRolloverListener);
		slider.removeMouseMotionListener(this.substanceRolloverListener);
		this.substanceRolloverListener = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSliderUI#paintFocus(java.awt.Graphics)
	 */
	@Override
	public void paintFocus(Graphics g) {
		FadeTracker fadeTracker = FadeTracker.getInstance();
		FocusKind focusKind = SubstanceCoreUtilities.getFocusKind(this.slider);
		if ((focusKind == FocusKind.NONE)
				&& (!fadeTracker.isTracked(this.slider, FadeKind.FOCUS)))
			return;
		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		float alpha = 1.0f;
		if (fadeTracker.isTracked(this.slider, FadeKind.FOCUS)) {
			alpha = fadeTracker.getFade10(this.slider, FadeKind.FOCUS) / 10.f;
		}
		// System.out.println(button.getText() + " -> " + alpha);
		graphics.setComposite(TransitionLayout.getAlphaComposite(this.slider,
				alpha));
		ColorScheme currScheme = SubstanceCoreUtilities
				.getActiveScheme(this.slider);
		Color color = SubstanceCoreUtilities.isThemeDark(SubstanceCoreUtilities
				.getActiveTheme(this.slider, true)) ? SubstanceColorUtilities
				.getInterpolatedColor(currScheme.getUltraLightColor(),
						currScheme.getForegroundColor(), 0.4)
				: SubstanceColorUtilities.getInterpolatedColor(currScheme
						.getMidColor(), currScheme.getDarkColor(), 0.5);
		graphics.setColor(color);

		graphics.translate(this.focusRect.x, this.focusRect.y);
		Shape contour = BaseButtonShaper.getBaseOutline(this.focusRect.width,
				this.focusRect.height, 3, null);
		graphics
				.setStroke(new BasicStroke(1.1f, BasicStroke.CAP_BUTT,
						BasicStroke.JOIN_ROUND, 0.0f,
						new float[] { 2.0f, 1.0f }, 0.0f));
		graphics.draw(contour);

		graphics.dispose();
	}

	/**
	 * Returns the amount that the thumb goes past the slide bar.
	 * 
	 * @return Amount that the thumb goes past the slide bar.
	 */
	protected int getThumbOverhang() {
		return (int) (getThumbSize().getHeight() - getTrackWidth()) / 2;
	}

	/**
	 * Returns the shorter dimension of the track.
	 * 
	 * @return Shorter dimension of the track.
	 */
	protected int getTrackWidth() {
		// This strange calculation is here to keep the
		// track in proportion to the thumb.
		final double kIdealTrackWidth = 7.0;
		final double kIdealThumbHeight = 16.0;
		final double kWidthScalar = kIdealTrackWidth / kIdealThumbHeight;

		if (slider.getOrientation() == JSlider.HORIZONTAL) {
			return (int) (kWidthScalar * thumbRect.height);
		} else {
			return (int) (kWidthScalar * thumbRect.width);
		}
	}
}
