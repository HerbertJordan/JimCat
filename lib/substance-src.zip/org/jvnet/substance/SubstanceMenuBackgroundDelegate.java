/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;

import javax.swing.*;

import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.SubstanceConstants.MenuGutterFillKind;

/**
 * Delegate for painting background of menu items.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceMenuBackgroundDelegate {
	/**
	 * Delegate for painting gradient background.
	 */
	private static SubstanceGradientBackgroundDelegate activeBackgroundDelegate = new SubstanceGradientBackgroundDelegate();

	/**
	 * Delegate for painting fill background.
	 */
	private SubstanceFillBackgroundDelegate fillBackgroundDelegate;

	/**
	 * Creates a new background delegate for menu items.
	 * 
	 * @param fillAlpha
	 *            Alphs attribute for the fill.
	 */
	public SubstanceMenuBackgroundDelegate(float fillAlpha) {
		this.fillBackgroundDelegate = new SubstanceFillBackgroundDelegate(
				fillAlpha);
	}

	/**
	 * Updates the specified menu item with the background that matches the
	 * provided parameters.
	 * 
	 * @param g
	 *            Graphic context.
	 * @param menuItem
	 *            Menu item.
	 * @param width
	 *            Background width.
	 * @param height
	 *            Background height.
	 * @param theme
	 *            Theme for the background.
	 * @param hasDarkBorder
	 *            If <code>true</code>, the resulting image will have dark
	 *            border.
	 */
	private void paintBackground(Graphics g, JMenuItem menuItem, int width,
			int height, SubstanceTheme theme, boolean hasDarkBorder) {
		SubstanceMenuBackgroundDelegate.activeBackgroundDelegate.update(g,
				menuItem, width, height, theme, hasDarkBorder);
	}

	/**
	 * Updates the specified menu item with the background that matches the
	 * provided parameters.
	 * 
	 * @param g
	 *            Graphic context.
	 * @param menuItem
	 *            Menu item.
	 * @param bgColor
	 *            Current background color.
	 * @param hasDarkBorder
	 *            If <code>true</code>, the resulting image will have dark
	 *            border.
	 * @param textOffset
	 *            The offset of the menu item text.
	 */
	public void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor,
			boolean hasDarkBorder, int textOffset) {
		if (!menuItem.isShowing())
			return;
		ButtonModel model = menuItem.getModel();
		int menuWidth = menuItem.getWidth();
		int menuHeight = menuItem.getHeight();

		// fix for defect 103 - no rollover effects on menu items
		// that are not in the selected menu path
		MenuElement[] selectedMenuPath = MenuSelectionManager.defaultManager()
				.getSelectedPath();
		boolean isRollover = (selectedMenuPath.length == 0);
		for (MenuElement elem : selectedMenuPath) {
			if (elem == menuItem) {
				isRollover = true;
				break;
			}
		}
		isRollover = isRollover && model.isRollover();

		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setComposite(TransitionLayout
				.getAlphaComposite(menuItem, 0.7f));

		if (TransitionLayout.isOpaque(menuItem)) {
			// menu item is opaque and selected (or armed) -
			// use background color of the item (with watermark)
			graphics.setColor(menuItem.getBackground());
			graphics.fillRect(0, 0, menuWidth, menuHeight);
			Component comp = menuItem.getParent();
			// System.out.println(menuItem.getText());
			this.fillBackgroundDelegate.setAlphaComposite(0.4f);
			while (comp != null) {
				// System.out.println("\t" + comp.getClass().getName());
				if (comp instanceof JMenuItem) {
					break;
				}
				if (comp instanceof JMenuBar) {
					// top-level
					this.fillBackgroundDelegate.setAlphaComposite(0.7f);
					break;
				}
				comp = comp.getParent();
			}

			this.fillBackgroundDelegate.update(graphics, menuItem);
			if (menuItem.getParent() instanceof JPopupMenu) {
				if (menuItem.getComponentOrientation().isLeftToRight()) {
					MenuGutterFillKind fillKind = SubstanceCoreUtilities
							.getMenuGutterFillKind();
					if (fillKind != MenuGutterFillKind.NONE) {
						ColorScheme scheme = SubstanceCoreUtilities
								.getActiveScheme(menuItem);
						Color leftColor = ((fillKind == MenuGutterFillKind.SOFT_FILL) || (fillKind == MenuGutterFillKind.HARD)) ? scheme
								.getUltraLightColor()
								: scheme.getLightColor();
						Color rightColor = ((fillKind == MenuGutterFillKind.SOFT_FILL) || (fillKind == MenuGutterFillKind.SOFT)) ? scheme
								.getUltraLightColor()
								: scheme.getLightColor();
						GradientPaint gp = new GradientPaint(0, 0, leftColor,
								textOffset, 0, rightColor);
						graphics.setPaint(gp);
						graphics.fillRect(0, 0, textOffset - 2, menuHeight);
					}
				} else {
					// fix for defect 125 - support of RTL menus
					MenuGutterFillKind fillKind = SubstanceCoreUtilities
							.getMenuGutterFillKind();
					if (fillKind != MenuGutterFillKind.NONE) {
						ColorScheme scheme = SubstanceCoreUtilities
								.getActiveScheme(menuItem);
						Color leftColor = ((fillKind == MenuGutterFillKind.HARD_FILL) || (fillKind == MenuGutterFillKind.HARD)) ? scheme
								.getLightColor()
								: scheme.getUltraLightColor();
						Color rightColor = ((fillKind == MenuGutterFillKind.HARD_FILL) || (fillKind == MenuGutterFillKind.SOFT)) ? scheme
								.getLightColor()
								: scheme.getUltraLightColor();
						GradientPaint gp = new GradientPaint(menuWidth
								- textOffset, 0, leftColor, menuWidth, 0,
								rightColor);
						graphics.setPaint(gp);
						graphics.fillRect(menuWidth - textOffset - 2, 0,
								menuWidth, menuHeight);
					}
				}
			}
		}

		FadeTracker fadeTracker = FadeTracker.getInstance();
		boolean isRolloverAnim = fadeTracker.isTracked(menuItem,
				FadeKind.ROLLOVER);
		boolean isArmedAnim = fadeTracker.isTracked(menuItem, FadeKind.ARM);
		boolean isSelectedAnim = fadeTracker.isTracked(menuItem,
				FadeKind.SELECTION);
		if (model.isArmed()
				|| isArmedAnim
				|| isRollover
				|| isRolloverAnim
				|| ((menuItem instanceof JMenu) && (model.isSelected() || isSelectedAnim))) {
			float alpha = 0.0f;
			if (isRolloverAnim) {
				float cyclePos = fadeTracker.getFade10(menuItem,
						FadeKind.ROLLOVER);
				alpha = Math.max(alpha, 0.4f * cyclePos / 10.f);
			} else {
				if (isRollover) {
					alpha = Math.max(alpha, 0.4f);
				}
			}
			if (isArmedAnim) {
				float cyclePos = fadeTracker.getFade10(menuItem, FadeKind.ARM);
				alpha = Math.max(alpha, 0.4f * cyclePos / 10.f);
			} else {
				if (model.isArmed()) {
					alpha = Math.max(alpha, 0.4f);
				}
			}
			if (isSelectedAnim) {
				float cyclePos = fadeTracker.getFade10(menuItem,
						FadeKind.SELECTION);
				alpha = Math.max(alpha, 0.7f * cyclePos / 10.f);
			} else {
				// This is not needed
				// if (model.isSelected()) {
				// alpha = Math.max(alpha, 0.7f);
				// }
			}
			graphics.setComposite(TransitionLayout.getAlphaComposite(menuItem,
					alpha));
			// fix for enhancement 182 - using highlight background theme
			// for armed / roll over menus.
			this.paintBackground(graphics, menuItem, menuWidth, menuHeight,
					SubstanceCoreUtilities.getHighlightBackgroundTheme(
							menuItem, true), hasDarkBorder);
		}
		graphics.dispose();
	}
}
