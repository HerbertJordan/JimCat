/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.utils;

import org.jvnet.substance.SubstanceLookAndFeel;

/**
 * <b>Substance</b> constants.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceConstants {
	/**
	 * Default icon dimension.
	 */
	public static final int ICON_DIMENSION = 16;

	/**
	 * Combobox button arrow default width.
	 */
	public static final int ARROW_WIDTH = 9;

	/**
	 * Combobox button arrow default height.
	 */
	public static final int ARROW_HEIGHT = 6;

	/**
	 * Drag bump diameter.
	 */
	public static final int DRAG_BUMP_DIAMETER = 2;

	/**
	 * Side enum.
	 * 
	 * @author Kirill Grouchnikov
	 * @see SubstanceLookAndFeel#BUTTON_OPEN_SIDE_PROPERTY
	 * @see SubstanceLookAndFeel#BUTTON_SIDE_PROPERTY
	 */
	public static enum Side {
		/**
		 * Left side.
		 */
		LEFT,

		/**
		 * Right side.
		 */
		RIGHT,

		/**
		 * Top side.
		 */
		TOP,

		/**
		 * Bottom side.
		 */
		BOTTOM;
	}

	/**
	 * Enum for various tree node states. This enum is <b>for internal use only</b>.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static enum TreeIcon {
		CLOSED, OPENED, UP, NONE
	}

	/**
	 * Kind of focus indication.
	 * 
	 * @author Kirill Grouchnikov
	 * @see SubstanceLookAndFeel#FOCUS_KIND
	 */
	public enum FocusKind {
		/**
		 * No focus indication.
		 */
		NONE,

		/**
		 * Focus indication around the text.
		 */
		TEXT,

		/**
		 * Focus indication around the whole component.
		 */
		ALL,

		/**
		 * Focus indication around the whole component, but moved 1 pixel inside
		 * the component.
		 */
		ALL_INNER,

		/**
		 * Focus indication under the component text.
		 */
		UNDERLINE,

		/**
		 * Strong focus indication under the component text.
		 */
		STRONG_UNDERLINE
	}

	/**
	 * Button kind in title pane. This enum is <b>for internal use only</b>.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public enum ButtonTitleKind {
		NONE, REGULAR, CLOSE, REGULAR_DI, CLOSE_DI
	}

	public enum ImageWatermarkKind {
		SCREEN_CENTER_SCALE, SCREEN_TILE, APP_ANCHOR, APP_CENTER, APP_TILE
	}

	public enum TabCloseKind {
		NONE, THIS, ALL, ALL_BUT_THIS
	}

	public enum TabTextAlignmentKind {
		DEFAULT, ALWAYS_LEFT, ALWAYS_RIGHT, FOLLOW_PLACEMENT, FOLLOW_ORIENTATION
	}

	public enum TabAnimationKind {
		LOADING, ERROR, WARNING
	}

	/**
	 * Enumerates possible button policies for scroll panes.
	 * 
	 * @author Kirill Grouchnikov
	 * @see SubstanceLookAndFeel#SCROLL_PANE_BUTTONS_POLICY
	 */
	public enum ScrollPaneButtonPolicyKind {
		/**
		 * The <code>empty</code> button policy - no buttons.
		 */
		NONE,

		/**
		 * The <code>opposite</code> (default) button policy - the decrease
		 * button is on one side of the scroll bar, and the increase button is
		 * on the other side of the scroll bar.
		 */
		OPPOSITE,

		/**
		 * The <code>adjacent</code> button policy - both the decrease button
		 * and the increase button are on the same side of the scroll bar
		 * adjacent to each other (like on Mac).
		 */
		ADJACENT,

		/**
		 * The <code>multiple</code> button policy - there are two decrease
		 * buttons on the opposite side of the scroll bar and the increase
		 * button is adjacent to the second decrease button. This combines the
		 * {@link #OPPOSITE} and the {@link #ADJACENT} policies together.
		 */
		MULTIPLE,

		/**
		 * The <code>multiple both</code> button policy - there are two pairs
		 * of decrease-increase buttons on the opposite sides of the scroll bar.
		 * This extends the {@link #MULTIPLE} policy.
		 */
		MULTIPLE_BOTH
	}

	/**
	 * Enumerates possible values for menu gutter fill kind.
	 * 
	 * @author Kirill Grouchnikov
	 * @see SubstanceLookAndFeel#MENU_GUTTER_FILL_KIND
	 */
	public enum MenuGutterFillKind {
		/**
		 * The <code>none</code> fill kind - draws no background in the menu
		 * gutter.
		 */
		NONE,

		/**
		 * The <code>soft fill</code> fill kind - draws light fill background
		 * in the menu gutter.
		 */
		SOFT_FILL,

		/**
		 * The <code>hard fill</code> fill kind - draws darker fill background
		 * in the menu gutter.
		 */
		HARD_FILL,

		/**
		 * The <code>soft</code> fill kind - draws gradient ranging from
		 * darker to light in the menu gutter.
		 */
		SOFT,

		/**
		 * The <code>hard</code> (default) fill kind - draws gradient ranging
		 * from darker to light in the menu gutter.
		 */
		HARD
	}

	public enum PinState {
		CANNOT_BE_PINNED, PERMANENTLY_PINNED, PINNED, NOT_PINNED
	}
}
