/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.utils;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;

import org.jvnet.substance.*;
import org.jvnet.substance.button.SubstanceButtonShaper;
import org.jvnet.substance.color.*;
import org.jvnet.substance.combo.ComboPopupPrototypeCallback;
import org.jvnet.substance.combo.SubstanceComboBoxButton;
import org.jvnet.substance.painter.ControlBackgroundComposite;
import org.jvnet.substance.painter.SubstanceGradientPainter;
import org.jvnet.substance.scroll.ScrollThumbGripPainter;
import org.jvnet.substance.scroll.SubstanceScrollButton;
import org.jvnet.substance.tabbed.TabCloseCallback;
import org.jvnet.substance.theme.*;
import org.jvnet.substance.theme.SubstanceTheme.ThemeKind;
import org.jvnet.substance.title.SubstanceTitlePainter;
import org.jvnet.substance.utils.ComponentState.ColorSchemeKind;
import org.jvnet.substance.utils.SubstanceConstants.*;

/**
 * Various utility functions. This class is <b>for internal use only</b>.
 * 
 * @author Kirill Grouchnikov
 * @author Romain Guy
 */
public class SubstanceCoreUtilities {
	/**
	 * Private constructor. Is here to enforce using static methods only.
	 */
	private SubstanceCoreUtilities() {
	}

	/**
	 * Clips string based on specified font metrics and available width (in
	 * pixels). Returns the clipped string, which contains the beginning and the
	 * end of the input string separated by ellipses (...) in case the string is
	 * too long to fit into the specified width, and the origianl string
	 * otherwise.
	 * 
	 * @param metrics
	 *            Font metrics.
	 * @param availableWidth
	 *            Available width in pixels.
	 * @param fullText
	 *            String to clip.
	 * @return The clipped string, which contains the beginning and the end of
	 *         the input string separated by ellipses (...) in case the string
	 *         is too long to fit into the specified width, and the origianl
	 *         string otherwise.
	 */
	public static String clipString(FontMetrics metrics, int availableWidth,
			String fullText) {

		if (metrics.stringWidth(fullText) <= availableWidth)
			return fullText;

		String ellipses = "...";
		int ellipsesWidth = metrics.stringWidth(ellipses);
		if (ellipsesWidth > availableWidth)
			return "";

		String starter = "";
		String ender = "";

		int w = fullText.length();
		int w2 = (w / 2) + (w % 2);
		String prevTitle = "";
		for (int i = 0; i < w2; i++) {
			String newStarter = starter + fullText.charAt(i);
			String newEnder = ender;
			if ((w - i) > w2)
				newEnder = fullText.charAt(w - i - 1) + newEnder;
			String newTitle = newStarter + ellipses + newEnder;
			if (metrics.stringWidth(newTitle) <= availableWidth) {
				starter = newStarter;
				ender = newEnder;
				prevTitle = newTitle;
				continue;
			}
			return prevTitle;
		}
		return fullText;
	}

	/**
	 * Checks whether the specified button has associated icon.
	 * 
	 * @param button
	 *            Button.
	 * @return If the button has associated icon, <code>true</code> is
	 *         returned, otherwise <code>false</code>.
	 */
	public static boolean hasIcon(AbstractButton button) {
		return (button.getIcon() != null);
	}

	/**
	 * Checks whether the specified button has associated text.
	 * 
	 * @param button
	 *            Button.
	 * @return If the button has associated text, <code>true</code> is
	 *         returned, otherwise <code>false</code>.
	 */
	public static boolean hasText(AbstractButton button) {
		String text = button.getText();
		if ((text != null) && (text.length() > 0)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks and answers if the specified button is in a combo box.
	 * 
	 * @param button
	 *            the button to check
	 * @return <code>true</code> if in tool bar, <code>false</code>
	 *         otherwise
	 */
	public static boolean isComboBoxButton(AbstractButton button) {
		Container parent = button.getParent();
		return (parent != null)
				&& ((parent instanceof JComboBox) || (parent.getParent() instanceof JComboBox));
	}

	/**
	 * Checks and answers if the specified button is in a combo box.
	 * 
	 * @param button
	 *            the button to check
	 * @return <code>true</code> if in tool bar, <code>false</code>
	 *         otherwise
	 */
	public static boolean isScrollBarButton(AbstractButton button) {
		Container parent = button.getParent();
		return (parent != null)
				&& ((parent instanceof JScrollBar) || (parent.getParent() instanceof JScrollBar));
	}

	/**
	 * Checks and answers if the specified button is in a spinner.
	 * 
	 * @param button
	 *            the button to check
	 * @return <code>true</code> if in spinner, <code>false</code> otherwise
	 */
	public static boolean isSpinnerButton(AbstractButton button) {
		Container parent = button.getParent();
		if (!(button instanceof SubstanceSpinnerButton))
			return false;
		return (parent != null)
				&& ((parent instanceof JSpinner) || (parent.getParent() instanceof JSpinner));
	}

	/**
	 * Checks and answers if the specified button is in a toolbar.
	 * 
	 * @param button
	 *            the button to check
	 * @return <code>true</code> if in toolbar, <code>false</code> otherwise
	 */
	public static boolean isToolBarButton(AbstractButton button) {
		if (button instanceof SubstanceComboBoxButton)
			return false;
		if (button instanceof SubstanceSpinnerButton)
			return false;
		Container parent = button.getParent();
		return (parent != null)
				&& ((parent instanceof JToolBar) || (parent.getParent() instanceof JToolBar));
	}

	/**
	 * Checks answers if the specified button is in scroll control, such as
	 * scroll bar or tabbed pane (as tab scroller).
	 * 
	 * @param button
	 *            the button to check
	 * @return <code>true</code> if in scroll control, <code>false</code>
	 *         otherwise
	 */
	public static boolean isScrollButton(AbstractButton button) {
		return (button instanceof SubstanceScrollButton);
	}

	/**
	 * Returns the theme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The theme of the specified component.
	 */
	public static SubstanceTheme getTheme(Component component,
			boolean toReturnCurrent) {
		if (component != null) {
			Component comp = component;
			// while (comp != null) {
			if (comp instanceof JComponent) {
				JComponent jcomp = (JComponent) comp;
				Object controlThemeObj = jcomp
						.getClientProperty(SubstanceLookAndFeel.THEME_PROPERTY);
				if (controlThemeObj != null) {
					if (controlThemeObj instanceof String)
						return SubstanceTheme
								.getTheme((String) controlThemeObj);
					if (controlThemeObj instanceof ThemeInfo)
						return SubstanceTheme
								.createInstance((ThemeInfo) controlThemeObj);
					if (controlThemeObj instanceof SubstanceTheme)
						return ((SubstanceTheme) controlThemeObj);
				}
			}
			// comp = comp.getParent();
			// }
		}
		if (toReturnCurrent)
			return SubstanceLookAndFeel.getTheme();
		return null;
	}

	/**
	 * Returns the theme of the specified component in the specified parent.
	 * 
	 * @param component
	 *            The component.
	 * @param parent
	 *            The component parent of the component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The theme of the specified component.
	 */
	public static SubstanceTheme getTheme(Component component,
			Component parent, boolean toReturnCurrent) {
		SubstanceTheme compTheme = getTheme(component, toReturnCurrent);
		if (compTheme != null)
			return compTheme;

		return getTheme(parent, toReturnCurrent);
	}

	/**
	 * Returns the active theme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The active theme of the specified component.
	 */
	public static SubstanceTheme getActiveTheme(Component component,
			boolean toReturnCurrent) {
		SubstanceTheme componentTheme = getTheme(component, toReturnCurrent);
		if (componentTheme == null)
			return null;
		return componentTheme.getActiveTheme();
	}

	/**
	 * Returns the highlight background theme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The highlight background theme of the specified component.
	 */
	public static SubstanceTheme getHighlightBackgroundTheme(
			Component component, boolean toReturnCurrent) {
		SubstanceTheme componentTheme = getTheme(component, toReturnCurrent);
		if (componentTheme == null)
			return null;
		return componentTheme.getHighlightBackgroundTheme();
	}

	/**
	 * Returns the default theme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The default theme of the specified component.
	 */
	public static SubstanceTheme getDefaultTheme(Component component,
			boolean toReturnCurrent) {
		return getDefaultTheme(component, toReturnCurrent, false);
	}

	/**
	 * Returns the default theme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @param checkHierarchy
	 *            If <code>true</code>, the entire component hierarchy will
	 *            be scanned for the
	 *            {@link SubstanceLookAndFeel#PAINT_ACTIVE_PROPERTY}.
	 * @return The default theme of the specified component.
	 */
	public static SubstanceTheme getDefaultTheme(Component component,
			boolean toReturnCurrent, boolean checkHierarchy) {
		if ((component != null)
				&& SubstanceCoreUtilities.isControlAlwaysPaintedActive(
						component, checkHierarchy)) {
			return getActiveTheme(component, toReturnCurrent);
		} else {
			SubstanceTheme theme = getTheme(component, toReturnCurrent);
			if (theme != null)
				return theme.getDefaultTheme();
			return null;
		}
	}

	/**
	 * Returns the disabled theme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The disabled theme of the specified component.
	 */
	public static SubstanceTheme getDisabledTheme(Component component,
			boolean toReturnCurrent) {
		SubstanceTheme theme = getTheme(component, toReturnCurrent);
		if (theme != null)
			return theme.getDisabledTheme();
		return null;
	}

	/**
	 * Returns the active scheme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @return The active scheme of the specified component.
	 */
	public static ColorScheme getActiveScheme(Component component) {
		SubstanceTheme theme = getActiveTheme(component, true);
		if (theme != null)
			return theme.getColorScheme();
		return null;
	}

	/**
	 * Returns the default scheme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The default scheme of the specified component.
	 */
	public static ColorScheme getDefaultScheme(Component component,
			boolean toReturnCurrent) {
		SubstanceTheme theme = getDefaultTheme(component, toReturnCurrent);
		if (theme != null)
			return theme.getColorScheme();
		return null;
	}

	/**
	 * Returns the default scheme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @return The default scheme of the specified component.
	 */
	public static ColorScheme getDefaultScheme(Component component) {
		return getDefaultScheme(component, true);
	}

	/**
	 * Returns the disabled scheme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @param toReturnCurrent
	 *            if <code>true</code>, the currently set <b>Substance</b>
	 *            theme will be returned if the
	 *            {@link SubstanceLookAndFeel#THEME_PROPERTY} is not set on the
	 *            component and any of its ancestors.
	 * @return The disabled scheme of the specified component.
	 */
	public static ColorScheme getDisabledScheme(Component component,
			boolean toReturnCurrent) {
		SubstanceTheme theme = getDisabledTheme(component, toReturnCurrent);
		if (theme != null)
			return theme.getColorScheme();
		return null;
	}

	/**
	 * Returns the disabled scheme of the specified component.
	 * 
	 * @param component
	 *            The component.
	 * @return The disabled scheme of the specified component.
	 */
	public static ColorScheme getDisabledScheme(Component component) {
		return getDisabledScheme(component, true);
	}

	/**
	 * Returns the active scheme of the specified component in the specified
	 * parent.
	 * 
	 * @param component
	 *            The component.
	 * @param parent
	 *            The component parent of the component.
	 * @return The active scheme of the specified component.
	 */
	public static ColorScheme getActiveScheme(Component component,
			Component parent) {
		SubstanceTheme theme = getTheme(component, parent, false);
		if (theme != null)
			return theme.getActiveTheme().getColorScheme();
		return SubstanceLookAndFeel.getActiveColorScheme();
	}

	/**
	 * Returns the default scheme of the specified component in the specified
	 * parent.
	 * 
	 * @param component
	 *            The component.
	 * @param parent
	 *            The component parent of the component.
	 * @return The default scheme of the specified component.
	 */
	public static ColorScheme getDefaultScheme(Component component,
			Component parent) {

		boolean isComponentAlwaysActive = isControlAlwaysPaintedActive(component);
		boolean isParentAlwaysActive = isControlAlwaysPaintedActive(parent);

		if (isComponentAlwaysActive || isParentAlwaysActive) {
			return getActiveScheme(component, parent);
		}

		SubstanceTheme theme = getTheme(component, parent, false);
		if (theme != null)
			return theme.getDefaultTheme().getColorScheme();
		return SubstanceLookAndFeel.getDefaultColorScheme();
	}

	/**
	 * Returns the disabled scheme of the specified component in the specified
	 * parent.
	 * 
	 * @param component
	 *            The component.
	 * @param parent
	 *            The component parent of the component.
	 * @return The disabled scheme of the specified component.
	 */
	public static ColorScheme getDisabledScheme(Component component,
			Component parent) {
		SubstanceTheme theme = getTheme(component, parent, false);
		if (theme != null)
			return theme.getDisabledTheme().getColorScheme();
		return SubstanceLookAndFeel.getDisabledColorScheme();
	}

	/**
	 * Checks whether the specified control is always painted in currently
	 * active color (ignoring the transition states that normally result in
	 * default appearance).
	 * 
	 * @param comp
	 *            Button.
	 * @return <code>true</code> if the specified button is always painted in
	 *         currently active color (ignoring the transition states that
	 *         normally result in default appearance), <code>false</code>
	 *         otherwise.
	 */
	public static boolean isControlAlwaysPaintedActive(Component comp) {
		return isControlAlwaysPaintedActive(comp, false);
	}

	/**
	 * Checks whether the specified control is always painted in currently
	 * active color (ignoring the transition states that normally result in
	 * default appearance).
	 * 
	 * @param comp
	 *            Button.
	 * @param checkHierarchy
	 *            If <code>true</code>, the entire component hierarchy will
	 *            be scanned for the
	 *            {@link SubstanceLookAndFeel#PAINT_ACTIVE_PROPERTY}.
	 * @return <code>true</code> if the specified button is always painted in
	 *         currently active color (ignoring the transition states that
	 *         normally result in default appearance), <code>false</code>
	 *         otherwise.
	 */
	public static boolean isControlAlwaysPaintedActive(Component comp,
			boolean checkHierarchy) {
		if (!checkHierarchy) {
			if (comp instanceof JComponent) {
				JComponent jcomp = (JComponent) comp;
				Object componentProp = jcomp
						.getClientProperty(SubstanceLookAndFeel.PAINT_ACTIVE_PROPERTY);
				if (componentProp != null) {
					if (Boolean.TRUE.equals(componentProp))
						return true;
					if (Boolean.FALSE.equals(componentProp))
						return false;
				}
			}
		} else {
			Component c = comp;
			while (c != null) {
				if (c instanceof JComponent) {
					JComponent jcomp = (JComponent) c;
					Object componentProp = jcomp
							.getClientProperty(SubstanceLookAndFeel.PAINT_ACTIVE_PROPERTY);
					if (componentProp != null) {
						if (Boolean.TRUE.equals(componentProp))
							return true;
						if (Boolean.FALSE.equals(componentProp))
							return false;
					}
				}
				c = c.getParent();
			}
		}
		return Boolean.TRUE.equals(UIManager
				.get(SubstanceLookAndFeel.PAINT_ACTIVE_PROPERTY));
	}

	/**
	 * Checks whether the specified button never paints its background.
	 * 
	 * @param button
	 *            Button.
	 * @return <code>true</code> if the specified button never paints its
	 *         background, <code>false</code> otherwise.
	 */
	public static boolean isButtonNeverPainted(AbstractButton button) {
		Component c = button;
		while (c != null) {
			if (c instanceof JComponent) {
				JComponent jc = (JComponent) c;
				Object prop = jc
						.getClientProperty(SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY);
				if (prop != null) {
					if (Boolean.TRUE.equals(prop))
						return true;
					if (Boolean.FALSE.equals(prop))
						return false;
				}
			}
			c = c.getParent();
		}

		return Boolean.TRUE.equals(UIManager
				.get(SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY));
	}

	/**
	 * Returns the focus ring kind of the specified component.
	 * 
	 * @param component
	 *            Component.
	 * @return The focus ring kind of the specified component.
	 */
	public static FocusKind getFocusKind(Component component) {
		while (component != null) {
			if (component instanceof JComponent) {
				JComponent jcomp = (JComponent) component;
				Object jcompFocusKind = jcomp
						.getClientProperty(SubstanceLookAndFeel.FOCUS_KIND);
				if (jcompFocusKind instanceof FocusKind)
					return (FocusKind) jcompFocusKind;
			}
			component = component.getParent();
		}
		Object globalFocusKind = UIManager.get(SubstanceLookAndFeel.FOCUS_KIND);
		if (globalFocusKind instanceof FocusKind)
			return (FocusKind) globalFocusKind;
		return FocusKind.ALL_INNER;
	}

	/**
	 * Returns the text alignment kind of the specified tabbed pane.
	 * 
	 * @param tabPane
	 *            Tabbed pane.
	 * @return The text alignment kind of the specified tabbed pane.
	 */
	public static TabTextAlignmentKind getTabTextAlignmentKind(
			JTabbedPane tabPane) {
		Object jcompAlignmentKind = tabPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_TEXT_ALIGNMENT_KIND);
		if (jcompAlignmentKind instanceof TabTextAlignmentKind)
			return (TabTextAlignmentKind) jcompAlignmentKind;

		Object globalAlignmentKind = UIManager
				.get(SubstanceLookAndFeel.TABBED_PANE_TEXT_ALIGNMENT_KIND);
		if (globalAlignmentKind instanceof TabTextAlignmentKind)
			return (TabTextAlignmentKind) globalAlignmentKind;
		return TabTextAlignmentKind.DEFAULT;
	}

	/**
	 * Returns indication whether the watermark should be drawn on the specified
	 * component.
	 * 
	 * @param component
	 *            Component.
	 * @return <code>true</code> if the watermark should be drawn on the
	 *         specified component, <code>false</code> otherwise.
	 */
	public static boolean toDrawWatermark(Component component) {
		while (component != null) {
			if (component instanceof JComponent) {
				JComponent jcomp = (JComponent) component;
				Object obj = jcomp
						.getClientProperty(SubstanceLookAndFeel.WATERMARK_IGNORE);
				if (Boolean.TRUE.equals(obj))
					return false;
				if (Boolean.FALSE.equals(obj))
					return true;
			}
			component = component.getParent();
		}
		Object obj = UIManager.get(SubstanceLookAndFeel.WATERMARK_IGNORE);
		if (Boolean.TRUE.equals(obj))
			return false;
		return true;
	}

	/**
	 * Returns indication whether the watermark should "bleed" through the
	 * specified component.
	 * 
	 * @param component
	 *            Component.
	 * @return <code>true</code> if the watermark should "bleed" through the
	 *         specified component, <code>false</code> otherwise.
	 */
	public static boolean toBleedWatermark(Component component) {
		if (component instanceof JComponent) {
			JComponent jcomp = (JComponent) component;
			Object obj = jcomp
					.getClientProperty(SubstanceLookAndFeel.WATERMARK_TO_BLEED);
			if (Boolean.TRUE.equals(obj))
				return true;
			if (Boolean.FALSE.equals(obj))
				return false;
		}
		return SubstanceLookAndFeel.toBleedWatermark();
	}

	/**
	 * Returns the button shaper of the specified button.
	 * 
	 * @param button
	 *            The button.
	 * @return The button shaper of the specified button.
	 */
	public static SubstanceButtonShaper getButtonShaper(AbstractButton button) {
		SubstanceButtonShaper shaper = null;
		Component c = button;
		while (c != null) {
			if (c instanceof JComponent) {
				JComponent jcomp = (JComponent) c;
				Object customShaper = jcomp
						.getClientProperty(SubstanceLookAndFeel.BUTTON_SHAPER_PROPERTY);
				if (customShaper != null) {
					if (customShaper instanceof SubstanceButtonShaper)
						return (SubstanceButtonShaper) customShaper;
					if (customShaper instanceof String) {
						try {
							shaper = (SubstanceButtonShaper) Class.forName(
									(String) customShaper).newInstance();
						} catch (Exception exc) {
							shaper = null;
						}

						if (shaper != null)
							return shaper;
					}
				}
			}
			c = c.getParent();
		}
		if (shaper == null) {
			shaper = SubstanceLookAndFeel.getCurrentButtonShaper();
		}
		return shaper;
	}

	/**
	 * Returns the gradient painter of the specified component.
	 * 
	 * @param comp
	 *            Component.
	 * @return The gradient painter of the specified component.
	 */
	public static SubstanceGradientPainter getGradientPainter(JComponent comp) {
		SubstanceGradientPainter painter = SubstanceLookAndFeel
				.getCurrentGradientPainter();
		Object customPainter = comp
				.getClientProperty(SubstanceLookAndFeel.GRADIENT_PAINTER_PROPERTY);
		if (customPainter != null) {
			if (customPainter instanceof SubstanceGradientPainter)
				return (SubstanceGradientPainter) customPainter;
			try {
				painter = (SubstanceGradientPainter) Class.forName(
						(String) customPainter).newInstance();
			} catch (Exception exc) {
				painter = SubstanceLookAndFeel.getCurrentGradientPainter();
			}
		}
		return painter;
	}

	/**
	 * Retrieves the <code>modified</code> state for the specified component
	 * in a tabbed pane.
	 * 
	 * @param tabComponent
	 *            The associated tab component.
	 * @return <code>true</code> if the specified component in a tabbed pane
	 *         is marked as modified, <code>false</code> otherwise.
	 * @see SubstanceLookAndFeel#WINDOW_MODIFIED
	 */
	public static boolean isTabModified(Component tabComponent) {
		boolean isWindowModified = false;
		// boolean toEnd = (tabComponent == null);
		Component comp = tabComponent;
		// while (!toEnd) {
		if (comp instanceof JComponent) {
			JComponent jc = (JComponent) comp;

			isWindowModified = Boolean.TRUE.equals(jc
					.getClientProperty(SubstanceLookAndFeel.WINDOW_MODIFIED));
			// if (isWindowModified)
			// break;
		}
		// if (comp instanceof JTabbedPane)
		// toEnd = true;
		// comp = comp.getParent();
		// if (comp == null)
		// toEnd = true;
		// }
		return isWindowModified;
	}

	/**
	 * Retrieves the <code>modified</code> state for the specified root pane.
	 * 
	 * @param rootPane
	 *            The root pane.
	 * @return <code>true</code> if the specified root pane is marked as
	 *         modified, <code>false</code> otherwise.
	 * @see SubstanceLookAndFeel#WINDOW_MODIFIED
	 */
	public static boolean isRootPaneModified(JRootPane rootPane) {
		return Boolean.TRUE.equals(rootPane
				.getClientProperty(SubstanceLookAndFeel.WINDOW_MODIFIED));
	}

	/**
	 * Retrieves the <code>modified</code> state for the specified internal
	 * frame.
	 * 
	 * @param internalFrame
	 *            The internal frame.
	 * @return <code>true</code> if the specified internal frame is marked as
	 *         modified, <code>false</code> otherwise.
	 * @see SubstanceLookAndFeel#WINDOW_MODIFIED
	 */
	public static boolean isInternalFrameModified(JInternalFrame internalFrame) {
		Object frameProp = internalFrame
				.getClientProperty(SubstanceLookAndFeel.WINDOW_MODIFIED);
		if (Boolean.TRUE.equals(frameProp))
			return true;
		if (Boolean.FALSE.equals(frameProp))
			return false;
		return Boolean.TRUE.equals(internalFrame.getRootPane()
				.getClientProperty(SubstanceLookAndFeel.WINDOW_MODIFIED));
	}

	/**
	 * Returns the tab animation kind of the specified tab component.
	 * 
	 * @param tabComponent
	 *            Tab component.
	 * @return Tab animation kind of the specified tab component.
	 */
	public static TabAnimationKind getTabAnimationKind(Component tabComponent) {
		Component comp = tabComponent;
		// while (!toEnd) {
		if (comp instanceof JComponent) {
			JComponent jc = (JComponent) comp;

			Object animObj = jc
					.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_TAB_ANIMATION_KIND);
			if (animObj instanceof TabAnimationKind)
				return (TabAnimationKind) animObj;
		}
		return null;
	}

	/**
	 * Returns the tab background composite of the specified tabbed pane.
	 * 
	 * @param component
	 *            Tabbed pane.
	 * @return Tab background composite of the specified tabbed pane.
	 */
	public static ControlBackgroundComposite getControlBackgroundComposite(
			Component component) {
		Component c = component;
		while (c != null) {
			if (c instanceof JComponent) {
				JComponent jc = (JComponent) c;
				Object objProp = jc
						.getClientProperty(SubstanceLookAndFeel.BACKGROUND_COMPOSITE);
				if (objProp instanceof ControlBackgroundComposite)
					return (ControlBackgroundComposite) objProp;
			}
			c = c.getParent();
		}
		Object globalProp = UIManager
				.get(SubstanceLookAndFeel.BACKGROUND_COMPOSITE);
		if (globalProp instanceof ControlBackgroundComposite)
			return (ControlBackgroundComposite) globalProp;

		return SubstanceLookAndFeel.getBackgroundComposite(component);
	}

	/**
	 * Checks whether the specified tab has a close button.
	 * 
	 * @param tabbedPane
	 *            Tabbed pane.
	 * @param tabIndex
	 *            Tab index.
	 * @return <code>true</code> if the specified tab has a close button,
	 *         <code>false</code> otherwise.
	 */
	public static boolean hasCloseButton(JTabbedPane tabbedPane, int tabIndex) {
		int tabCount = tabbedPane.getTabCount();
		if ((tabIndex < 0) || (tabIndex >= tabCount))
			return false;
		// check property on tab component
		Component tabComponent = tabbedPane.getComponentAt(tabIndex);
		if (tabComponent instanceof JComponent) {
			Object compProp = ((JComponent) tabComponent)
					.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_PROPERTY);
			if (Boolean.TRUE.equals(compProp))
				return true;
			if (Boolean.FALSE.equals(compProp))
				return false;
		}
		// check property on tabbed pane
		Object tabProp = tabbedPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_PROPERTY);
		if (Boolean.TRUE.equals(tabProp))
			return true;
		if (Boolean.FALSE.equals(tabProp))
			return false;
		// check property in UIManager
		return UIManager
				.getBoolean(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_PROPERTY);
	}

	/**
	 * Returns the size of the close button for a tab in the specified tabbed
	 * pane.
	 * 
	 * @param tabbedPane
	 *            Tabbed pane.
	 * @param tabIndex
	 *            Tab index.
	 * @return The size of the close button for a tab in the specified tabbed
	 *         pane.
	 */
	public static int getCloseButtonSize(JTabbedPane tabbedPane, int tabIndex) {
		if (!SubstanceCoreUtilities.hasCloseButton(tabbedPane, tabIndex))
			return 0;

		int tabCount = tabbedPane.getTabCount();
		if ((tabIndex < 0) || (tabIndex >= tabCount))
			return SubstanceTabbedPaneUI.TAB_DEFAULT_BUTTON_DIMENSION;
		// check property on tab component
		Component tabComponent = tabbedPane.getComponentAt(tabIndex);
		if (tabComponent instanceof JComponent) {
			Object compProp = ((JComponent) tabComponent)
					.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_SIZE);
			if (compProp instanceof Integer)
				return (Integer) compProp;
		}
		// check property on tabbed pane
		Object tabProp = tabbedPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_SIZE);
		if (tabProp instanceof Integer)
			return (Integer) tabProp;
		// check property in UIManager
		Object globalProp = UIManager
				.get(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_SIZE);
		if (globalProp instanceof Integer)
			return (Integer) globalProp;
		return SubstanceTabbedPaneUI.TAB_DEFAULT_BUTTON_DIMENSION;
	}

	/**
	 * Checks whether the specified tab should show vertically-aligned (rotated)
	 * components.
	 * 
	 * @param tabbedPane
	 *            Tabbed pane.
	 * @return <code>true</code> if the specified tab should show
	 *         vertically-aligned (rotated) components, <code>false</code>
	 *         otherwise.
	 */
	public static boolean toLayoutVertically(JTabbedPane tabbedPane) {
		int tabPlacement = tabbedPane.getTabPlacement();
		if ((tabPlacement == SwingConstants.TOP)
				|| (tabPlacement == SwingConstants.BOTTOM))
			return false;

		// check property on tabbed pane
		Object tabProp = tabbedPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_VERTICAL_ORIENTATION);
		if (Boolean.TRUE.equals(tabProp))
			return true;
		if (Boolean.FALSE.equals(tabProp))
			return false;
		// check property in UIManager
		return UIManager
				.getBoolean(SubstanceLookAndFeel.TABBED_PANE_VERTICAL_ORIENTATION);
	}

	/**
	 * Checks whether the specified tab should show unrotated icon when the tab
	 * itself is layed-out vertically.
	 * 
	 * @param tabbedPane
	 *            Tabbed pane.
	 * @param tabIndex
	 *            Tab index.
	 * @return <code>true</code> if the specified tab should show unrotated
	 *         icon when the tab itself is layed-out vertically,
	 *         <code>false</code> otherwise.
	 */
	public static boolean toShowIconUnrotated(JTabbedPane tabbedPane,
			int tabIndex) {
		int tabCount = tabbedPane.getTabCount();
		if ((tabIndex < 0) || (tabIndex >= tabCount))
			return false;
		// check property on tab component
		Component tabComponent = tabbedPane.getComponentAt(tabIndex);
		if (tabComponent instanceof JComponent) {
			Object compProp = ((JComponent) tabComponent)
					.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_VERTICAL_ORIENTATION_ROTATE_ICONS);
			if (Boolean.TRUE.equals(compProp))
				return true;
			if (Boolean.FALSE.equals(compProp))
				return false;
		}
		// check property on tabbed pane
		Object tabProp = tabbedPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_VERTICAL_ORIENTATION_ROTATE_ICONS);
		if (Boolean.TRUE.equals(tabProp))
			return true;
		if (Boolean.FALSE.equals(tabProp))
			return false;
		// check property in UIManager
		return UIManager
				.getBoolean(SubstanceLookAndFeel.TABBED_PANE_VERTICAL_ORIENTATION_ROTATE_ICONS);
	}

	/**
	 * Checks whether the specified tab should show modified animation only on
	 * its close button.
	 * 
	 * @param tabbedPane
	 *            Tabbed pane.
	 * @param tabIndex
	 *            Tab index.
	 * @return <code>true</code> if the specified tab should show modified
	 *         animation only on its close button, <code>false</code>
	 *         otherwise.
	 */
	public static boolean toAnimateCloseIconOfModifiedTab(
			JTabbedPane tabbedPane, int tabIndex) {
		int tabCount = tabbedPane.getTabCount();
		if ((tabIndex < 0) || (tabIndex >= tabCount))
			return false;

		if (!hasCloseButton(tabbedPane, tabIndex))
			return false;

		// check property on tab component
		Component tabComponent = tabbedPane.getComponentAt(tabIndex);
		if (tabComponent instanceof JComponent) {
			Object compProp = ((JComponent) tabComponent)
					.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_MODIFIED_ANIMATION);
			if (Boolean.TRUE.equals(compProp))
				return true;
			if (Boolean.FALSE.equals(compProp))
				return false;
		}
		// check property on tabbed pane
		Object tabProp = tabbedPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_MODIFIED_ANIMATION);
		if (Boolean.TRUE.equals(tabProp))
			return true;
		if (Boolean.FALSE.equals(tabProp))
			return false;
		// check property in UIManager
		return UIManager
				.getBoolean(SubstanceLookAndFeel.TABBED_PANE_CLOSE_BUTTONS_MODIFIED_ANIMATION);
	}

	/**
	 * Retrieves transparent image of specified dimension.
	 * 
	 * @param width
	 *            Image width.
	 * @param height
	 *            Image height.
	 * @return Transparent image of specified dimension.
	 */
	public static BufferedImage getBlankImage(int width, int height) {
		if (MemoryAnalyzer.isRunning()) {
			// see if the request is unusual
			if ((width >= 100) || (height >= 100)) {
				// throw an Exception and then analyze it
				try {
					throw new Exception();
				} catch (Exception exc) {
					StringBuffer sb = new StringBuffer();
					StackTraceElement[] stack = exc.getStackTrace();
					int count = 0;
					for (StackTraceElement stackEntry : stack) {
						if (count++ > 8)
							break;
						sb.append(stackEntry.getClassName() + ".");
						sb.append(stackEntry.getMethodName() + " [");
						sb.append(stackEntry.getLineNumber() + "]");
						sb.append("\n");
					}
					MemoryAnalyzer.enqueueUsage("Blank " + width + "*" + height
							+ "\n" + sb.toString());

				}
			}
		}

		BufferedImage image = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);

		// get graphics and set hints
		Graphics2D graphics = (Graphics2D) image.getGraphics().create();
		graphics.setColor(new Color(0, 0, 0, 0));
		graphics.setComposite(AlphaComposite.Src);
		graphics.fillRect(0, 0, width, height);
		graphics.dispose();

		return image;
	}

	/**
	 * Checks whether the specified button should have minimal size.
	 * 
	 * @param button
	 *            Button.
	 * @return <code>false</code> if the specified button should have minimal
	 *         size, <code>true</code> otherwise.
	 */
	public static boolean hasNoMinSizeProperty(AbstractButton button) {
		Object noMinSizeProperty = button
				.getClientProperty(SubstanceLookAndFeel.BUTTON_NO_MIN_SIZE_PROPERTY);
		if (Boolean.TRUE.equals(noMinSizeProperty))
			return true;
		if (Boolean.FALSE.equals(noMinSizeProperty))
			return false;
		Container parent = button.getParent();
		if (parent instanceof JComponent) {
			noMinSizeProperty = ((JComponent) parent)
					.getClientProperty(SubstanceLookAndFeel.BUTTON_NO_MIN_SIZE_PROPERTY);
			if (Boolean.TRUE.equals(noMinSizeProperty))
				return true;
			if (Boolean.FALSE.equals(noMinSizeProperty))
				return false;
		}
		return (Boolean.TRUE.equals(UIManager
				.get(SubstanceLookAndFeel.BUTTON_NO_MIN_SIZE_PROPERTY)));
	}

	/**
	 * Checks whether the specified component is flat.
	 * 
	 * @param comp
	 *            Component.
	 * @return <code>false</code> if the specified button is flat,
	 *         <code>true</code> otherwise.
	 */
	public static boolean hasFlatProperty(Component comp) {
		if (comp instanceof JComponent) {
			JComponent jcomp = (JComponent) comp;
			Object flatProperty = jcomp
					.getClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY);
			if (Boolean.TRUE.equals(flatProperty))
				return true;
			if (Boolean.FALSE.equals(flatProperty))
				return false;
		}

		Container parent = comp.getParent();
		if (parent instanceof JComponent) {
			Object flatProperty = ((JComponent) parent)
					.getClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY);
			if (Boolean.TRUE.equals(flatProperty))
				return true;
			if (Boolean.FALSE.equals(flatProperty))
				return false;
		}

		return false;
	}

	/**
	 * Returns the popup flyout orientation for the specified combobox.
	 * 
	 * @param combobox
	 *            Combobox.
	 * @return The popup flyout orientation for the specified combobox.
	 */
	public static int getPopupFlyoutOrientation(JComboBox combobox) {
		Object comboProperty = combobox
				.getClientProperty(SubstanceLookAndFeel.COMBO_BOX_POPUP_FLYOUT_ORIENTATION);
		if (comboProperty instanceof Integer)
			return (Integer) comboProperty;
		Object globalProperty = UIManager
				.get(SubstanceLookAndFeel.COMBO_BOX_POPUP_FLYOUT_ORIENTATION);
		if (globalProperty instanceof Integer)
			return (Integer) globalProperty;
		return SwingConstants.SOUTH;
	}

	/**
	 * Makes the specified component and all its descendants non-opaque.
	 * 
	 * @param comp
	 *            Component.
	 * @param opaquenessSnapshot
	 *            The "snapshot" map that will contain the original opacity
	 *            status of the specified component and all its descendants.
	 */
	public static void makeNonOpaque(Component comp,
			Map<Component, Boolean> opaquenessSnapshot) {
		if (comp instanceof JComponent) {
			JComponent jcomp = (JComponent) comp;
			opaquenessSnapshot.put(comp, jcomp.isOpaque());
			jcomp.setOpaque(false);
		}
		if (comp instanceof Container) {
			Container cont = (Container) comp;
			for (int i = 0; i < cont.getComponentCount(); i++)
				makeNonOpaque(cont.getComponent(i), opaquenessSnapshot);
		}
	}

	/**
	 * Restores the opacity of the specified component and all its descendants.
	 * 
	 * @param comp
	 *            Component.
	 * @param opaquenessSnapshot
	 *            The "snapshot" map that contains the original opacity status
	 *            of the specified component and all its descendants.
	 */
	public static void restoreOpaque(Component comp,
			Map<Component, Boolean> opaquenessSnapshot) {
		if (comp instanceof JComponent) {
			JComponent jcomp = (JComponent) comp;
			// fix for defect 159 - snapshot may not contain
			// opacity for table header of a table when it's used
			// inside tree cell renderer (wrapper in a scroll pane).
			if (opaquenessSnapshot.containsKey(comp))
				jcomp.setOpaque(opaquenessSnapshot.get(comp));
			else
				jcomp.setOpaque(true);
		}
		if (comp instanceof Container) {
			Container cont = (Container) comp;
			for (int i = 0; i < cont.getComponentCount(); i++)
				restoreOpaque(cont.getComponent(i), opaquenessSnapshot);
		}
	}

	/**
	 * Creates a compatible image (for efficient processing and drawing).
	 * 
	 * @param image
	 *            The original image.
	 * @return Compatible version of the original image.
	 * @author Romain Guy
	 */
	public static BufferedImage createCompatibleImage(BufferedImage image) {
		GraphicsEnvironment e = GraphicsEnvironment
				.getLocalGraphicsEnvironment();
		GraphicsDevice d = e.getDefaultScreenDevice();
		GraphicsConfiguration c = d.getDefaultConfiguration();
		BufferedImage compatibleImage = c.createCompatibleImage(image
				.getWidth(), image.getHeight());
		Graphics g = compatibleImage.getGraphics();
		g.drawImage(image, 0, 0, null);
		g.dispose();
		return compatibleImage;
	}

	/**
	 * Checks whether the specified button in a toolbar is flat.
	 * 
	 * @param button
	 *            Button.
	 * @return <code>true</code> if the specified button is flat in a toolbar,
	 *         <code>false</code> otherwise.
	 */
	public static boolean isToolbarButtonFlat(AbstractButton button) {
		Component comp = button;
		JToolBar toolbar = null;
		while (comp != null) {
			if (comp instanceof JToolBar) {
				toolbar = (JToolBar) comp;
				break;
			}
			comp = comp.getParent();
		}
		if (toolbar == null)
			return false;

		return isToolbarButtonFlat(button, toolbar);
	}

	/**
	 * Checks whether the specified button in the specified toolbar is flat.
	 * 
	 * @param button
	 *            Button.
	 * @param toolbar
	 *            Toolbar that contains the specified button.
	 * @return <code>true</code> if the specified button is flat in the
	 *         specified toolbar, <code>false</code> otherwise.
	 */
	public static boolean isToolbarButtonFlat(AbstractButton button,
			JToolBar toolbar) {
		Object isFlatProperty = button
				.getClientProperty(SubstanceLookAndFeel.TOOLBAR_BUTTON_FLAT);
		if (Boolean.TRUE.equals(isFlatProperty))
			return true;
		if (Boolean.FALSE.equals(isFlatProperty))
			return false;
		isFlatProperty = toolbar
				.getClientProperty(SubstanceLookAndFeel.TOOLBAR_BUTTON_FLAT);
		if (Boolean.TRUE.equals(isFlatProperty))
			return true;
		if (Boolean.FALSE.equals(isFlatProperty))
			return false;
		if (Boolean.FALSE.equals(UIManager
				.get(SubstanceLookAndFeel.TOOLBAR_BUTTON_FLAT)))
			return false;
		return true;
	}

	/**
	 * Returns the callback to be called upon tab closing (using the tab close
	 * button).
	 * 
	 * @param me
	 *            Mouse event.
	 * @param tabbedPane
	 *            Tabbed pane.
	 * @param tabIndex
	 *            Tab index.
	 * @return Callback to be called upon tab closing (using the tab close
	 *         button).
	 */
	public static TabCloseCallback getTabCloseCallback(MouseEvent me,
			JTabbedPane tabbedPane, int tabIndex) {
		int tabCount = tabbedPane.getTabCount();
		if ((tabIndex < 0) || (tabIndex >= tabCount))
			return null;

		// check property on tab component
		Component tabComponent = tabbedPane.getComponentAt(tabIndex);
		if (tabComponent instanceof JComponent) {
			Object compProp = ((JComponent) tabComponent)
					.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_CALLBACK);
			if (compProp instanceof TabCloseCallback)
				return (TabCloseCallback) compProp;
		}

		// check property on tabbed pane
		Object tabProp = tabbedPane
				.getClientProperty(SubstanceLookAndFeel.TABBED_PANE_CLOSE_CALLBACK);
		if (tabProp instanceof TabCloseCallback)
			return (TabCloseCallback) tabProp;

		Object globProp = UIManager
				.get(SubstanceLookAndFeel.TABBED_PANE_CLOSE_CALLBACK);
		if (globProp instanceof TabCloseCallback)
			return (TabCloseCallback) globProp;

		return null;
	}

	/**
	 * Blends two images along X-axis.
	 * 
	 * @param imageLeft
	 *            The left image.
	 * @param imageRight
	 *            The right image.
	 * @param start
	 *            Relative start of the blend area (in 0.0-1.0 range).
	 * @param end
	 *            Relative end of the blend area (in 0.0-1.0 range).
	 * @return Blended image.
	 */
	public static BufferedImage blendImagesHorizontal(BufferedImage imageLeft,
			BufferedImage imageRight, double start, double end) {
		int width = imageLeft.getWidth();
		if (width != imageRight.getWidth())
			throw new IllegalArgumentException("Widths are not the same: "
					+ imageLeft.getWidth() + " and " + imageRight.getWidth());
		int height = imageLeft.getHeight();
		if (height != imageRight.getHeight())
			throw new IllegalArgumentException("Heights are not the same: "
					+ imageLeft.getHeight() + " and " + imageRight.getHeight());

		BufferedImage result = getBlankImage(width, height);
		Graphics2D graphics = (Graphics2D) result.getGraphics().create();

		int startX = (int) (start * width);
		int endX = (int) (end * width);
		int rampWidth = endX - startX;

		if (rampWidth == 0) {
			graphics.drawImage(imageLeft, 0, 0, startX, height, 0, 0, startX,
					height, null);
			graphics.drawImage(imageRight, startX, 0, width, height, startX, 0,
					width, height, null);
		} else {
			BufferedImage rampRight = getBlankImage(rampWidth, height);
			Graphics2D rampRightG = (Graphics2D) rampRight.getGraphics();
			rampRightG
					.setPaint(new GradientPaint(new Point(0, 0), new Color(0,
							0, 0, 255), new Point(rampWidth, 0), new Color(0,
							0, 0, 0)));
			rampRightG.fillRect(0, 0, rampWidth, height);

			BufferedImage tempRight = getBlankImage(width - startX, height);
			Graphics2D tempRightG = (Graphics2D) tempRight.getGraphics();
			tempRightG.drawImage(imageRight, 0, 0, width - startX, height,
					startX, 0, width, height, null);
			tempRightG.setComposite(AlphaComposite.DstOut);
			tempRightG.drawImage(rampRight, 0, 0, null);

			tempRightG.setComposite(AlphaComposite.SrcOver);
			graphics.drawImage(imageLeft, 0, 0, null);
			graphics.drawImage(tempRight, startX, 0, null);
		}
		graphics.dispose();
		return result;
	}

	/**
	 * Blends two images along Y-axis.
	 * 
	 * @param imageTop
	 *            The left image.
	 * @param imageBottom
	 *            The right image.
	 * @param start
	 *            Relative start of the blend area (in 0.0-1.0 range).
	 * @param end
	 *            Relative end of the blend area (in 0.0-1.0 range).
	 * @return Blended image.
	 */
	public static BufferedImage blendImagesVertical(BufferedImage imageTop,
			BufferedImage imageBottom, double start, double end) {
		int width = imageTop.getWidth();
		if (width != imageBottom.getWidth())
			throw new IllegalArgumentException("Widths are not the same: "
					+ imageTop.getWidth() + " and " + imageBottom.getWidth());
		int height = imageTop.getHeight();
		if (height != imageBottom.getHeight())
			throw new IllegalArgumentException("Heights are not the same: "
					+ imageTop.getHeight() + " and " + imageBottom.getHeight());

		BufferedImage result = getBlankImage(width, height);
		Graphics2D graphics = (Graphics2D) result.getGraphics().create();

		int startY = (int) (start * height);
		int endY = (int) (end * height);
		int rampHeight = endY - startY;

		if (rampHeight == 0) {
			graphics.drawImage(imageTop, 0, 0, width, startY, 0, 0, width,
					startY, null);
			graphics.drawImage(imageBottom, 0, startY, width, height, 0,
					startY, width, height, null);
		} else {
			BufferedImage rampBottom = getBlankImage(width, rampHeight);
			Graphics2D rampBottomG = (Graphics2D) rampBottom.getGraphics();
			rampBottomG.setPaint(new GradientPaint(new Point(0, 0), new Color(
					0, 0, 0, 255), new Point(0, rampHeight), new Color(0, 0, 0,
					0)));
			rampBottomG.fillRect(0, 0, width, rampHeight);

			BufferedImage tempBottom = getBlankImage(width, height - startY);
			Graphics2D tempBottomG = (Graphics2D) tempBottom.getGraphics();
			tempBottomG.drawImage(imageBottom, 0, 0, width, height - startY, 0,
					startY, width, height, null);
			tempBottomG.setComposite(AlphaComposite.DstOut);
			tempBottomG.drawImage(rampBottom, 0, 0, null);

			tempBottomG.setComposite(AlphaComposite.SrcOver);
			graphics.drawImage(imageTop, 0, 0, null);
			graphics.drawImage(tempBottom, 0, startY, null);
		}
		graphics.dispose();
		return result;
	}

	/**
	 * Retruns the unique ID for the specified color scheme.
	 * 
	 * @param colorScheme
	 *            Color scheme.
	 * @return Unique ID for the specified color scheme.
	 */
	public static String getSchemeId(ColorScheme colorScheme) {
		if (colorScheme instanceof BaseColorScheme) {
			BaseColorScheme base = (BaseColorScheme) colorScheme;
			return base.getId();
		}

		return colorScheme.getClass().getName();
	}

	/**
	 * Returns the color scheme for the icon of option panes with the specified
	 * message type.
	 * 
	 * @param messageType
	 *            Option pane message type.
	 * @param mainScheme
	 *            Main color scheme.
	 * @return Color scheme for the icon of option panes with the specified
	 *         message type.
	 */
	public static ColorScheme getOptionPaneColorScheme(int messageType,
			ColorScheme mainScheme) {
		if (!SubstanceLookAndFeel.isToUseConstantThemesOnDialogs())
			return mainScheme;

		switch (messageType) {
		case JOptionPane.INFORMATION_MESSAGE:
			return new BottleGreenColorScheme();
		case JOptionPane.QUESTION_MESSAGE:
			return new LightAquaColorScheme();
		case JOptionPane.WARNING_MESSAGE:
			return new SunsetColorScheme();
		case JOptionPane.ERROR_MESSAGE:
			return new SunfireRedColorScheme();
		}
		return null;
	}

	/**
	 * Checks whether the specified theme is dark.
	 * 
	 * @param theme
	 *            Theme.
	 * @return <code>true</code> if the specified theme is dark,
	 *         <code>false</code> otherwise.
	 */
	public static boolean isThemeDark(SubstanceTheme theme) {
		if (theme instanceof SubstanceInvertedTheme) {
			return !isThemeDark(((SubstanceInvertedTheme) theme)
					.getOriginalTheme());
		}
		if (theme instanceof SubstanceNegatedTheme) {
			return isThemeDark(((SubstanceNegatedTheme) theme)
					.getOriginalTheme());
		}
		if (theme instanceof SubstanceMixTheme) {
			SubstanceMixTheme mix = (SubstanceMixTheme) theme;
			for (SubstanceTheme mixCompTheme : mix.getOriginalThemes())
				if (isThemeDark(mixCompTheme))
					return true;
			return false;
		}
		if (theme instanceof SubstanceBlendBiTheme) {
			SubstanceBlendBiTheme blend = (SubstanceBlendBiTheme) theme;
			return isThemeDark(blend.getOriginalFirstTheme())
					|| isThemeDark(blend.getOriginalSecondTheme());
		}
		return (theme.getKind() == ThemeKind.DARK);
	}

	/**
	 * Returns the component theme.
	 * 
	 * @param component
	 *            Component.
	 * @param colorSchemeKind
	 *            Color scheme kind.
	 * @return Component theme.
	 */
	public static SubstanceTheme getComponentTheme(JComponent component,
			ComponentState.ColorSchemeKind colorSchemeKind) {
		return getComponentTheme(component, colorSchemeKind, false);

	}

	/**
	 * Returns the component theme.
	 * 
	 * @param component
	 *            Component.
	 * @param colorSchemeKind
	 *            Color scheme kind.
	 * @param checkHierarchy
	 *            If <code>true</code>, the entire component hierarchy will
	 *            be scanned for the
	 *            {@link SubstanceLookAndFeel#PAINT_ACTIVE_PROPERTY}.
	 * @return Component theme.
	 */
	public static SubstanceTheme getComponentTheme(JComponent component,
			ComponentState.ColorSchemeKind colorSchemeKind,
			boolean checkHierarchy) {
		if (colorSchemeKind == ColorSchemeKind.DISABLED) {
			return SubstanceCoreUtilities.getDisabledTheme(component, true);
		} else {
			if (colorSchemeKind == ColorSchemeKind.CURRENT) {
				return SubstanceCoreUtilities.getActiveTheme(component, true);
			} else {
				return SubstanceCoreUtilities.getDefaultTheme(component, true,
						checkHierarchy);
			}
		}
	}

	/**
	 * Returns the popup prototype display value for the specified combo box.
	 * This value is used to compute the width of the combo popup.
	 * 
	 * @param combo
	 *            Combo box.
	 * @return The popup prototype display value for the specified combo box.
	 */
	public static Object getComboPopupPrototypeDisplayValue(JComboBox combo) {
		Object objProp = combo
				.getClientProperty(SubstanceLookAndFeel.COMBO_POPUP_PROTOTYPE);
		if (objProp == null)
			objProp = UIManager.get(SubstanceLookAndFeel.COMBO_POPUP_PROTOTYPE);
		if (objProp == null)
			return null;

		if (objProp instanceof ComboPopupPrototypeCallback) {
			ComboPopupPrototypeCallback callback = (ComboPopupPrototypeCallback) objProp;
			return callback.getPopupPrototypeDisplayValue(combo);
		}

		// check if this object is in the model ???
		return objProp;
	}

	/**
	 * Returns the title painter of the specified root pane.
	 * 
	 * @param rp
	 *            Root pane.
	 * @return The title painter of the specified root pane.
	 */
	public static SubstanceTitlePainter getTitlePainter(JRootPane rp) {
		if (rp != null) {
			Object custObj = rp
					.getClientProperty(SubstanceLookAndFeel.TITLE_PAINTER_PROPERTY);
			if (custObj instanceof String) {
				String custStr = (String) custObj;
				try {
					Class<?> cl = Class.forName(custStr);
					Object custInst = cl.newInstance();
					if (custInst instanceof SubstanceTitlePainter)
						return (SubstanceTitlePainter) custInst;
				} catch (Exception exc) {
				}
			}
			if (custObj instanceof SubstanceTitlePainter) {
				return (SubstanceTitlePainter) custObj;
			}
		}
		return SubstanceLookAndFeel.getCurrentTitlePainter();
	}

	/**
	 * Returns the title painter of the specified internal frame.
	 * 
	 * @param jif
	 *            Internal frame.
	 * @return The title painter of the specified internal frame.
	 */
	public static SubstanceTitlePainter getTitlePainter(JInternalFrame jif) {
		Object custObj = jif
				.getClientProperty(SubstanceLookAndFeel.TITLE_PAINTER_PROPERTY);
		if (custObj instanceof String) {
			String custStr = (String) custObj;
			try {
				Class<?> cl = Class.forName(custStr);
				Object custInst = cl.newInstance();
				if (custInst instanceof SubstanceTitlePainter)
					return (SubstanceTitlePainter) custInst;
			} catch (Exception exc) {
			}
		}
		if (custObj instanceof SubstanceTitlePainter) {
			return (SubstanceTitlePainter) custObj;
		}
		return SubstanceLookAndFeel.getCurrentTitlePainter();
	}

	/**
	 * Returns the scroll bar buttons kind of the specified scroll bar.
	 * 
	 * @param scrollBar
	 *            Scroll bar.
	 * @return The scroll bar buttons kind of the specified scroll bar.
	 */
	public static ScrollPaneButtonPolicyKind getScrollPaneButtonsPolicyKind(
			JScrollBar scrollBar) {
		Component parent = scrollBar.getParent();
		if (parent instanceof JScrollPane) {
			Object jspKind = ((JScrollPane) parent)
					.getClientProperty(SubstanceLookAndFeel.SCROLL_PANE_BUTTONS_POLICY);
			if (jspKind instanceof ScrollPaneButtonPolicyKind)
				return (ScrollPaneButtonPolicyKind) jspKind;
		}
		Object globalJspKind = UIManager
				.get(SubstanceLookAndFeel.SCROLL_PANE_BUTTONS_POLICY);
		if (globalJspKind instanceof ScrollPaneButtonPolicyKind)
			return (ScrollPaneButtonPolicyKind) globalJspKind;
		return ScrollPaneButtonPolicyKind.OPPOSITE;
	}

	/**
	 * Returns the set of sides registered on the specified button.
	 * 
	 * @param button
	 *            Button.
	 * @param propertyName
	 *            Client property name for retrieving the registered sides.
	 * @return Set of sides registered on the specified button.
	 */
	@SuppressWarnings("unchecked")
	public static Set<Side> getSides(AbstractButton button, String propertyName) {
		Object prop = button.getClientProperty(propertyName);

		if (prop instanceof Set) {
			return (Set<Side>) prop;
		}

		Set<Side> result = new HashSet<Side>();
		if (prop != null) {
			if (prop instanceof String) {
				result.add(SubstanceConstants.Side.valueOf((String) prop));
			}
			if (prop instanceof String[]) {
				String[] clientSides = (String[]) prop;
				for (String side : clientSides) {
					result.add(SubstanceConstants.Side.valueOf(side));
				}
			}
			if (prop instanceof Side) {
				result.add((Side) prop);
			}
			if (prop instanceof Side[]) {
				Side[] clientSides = (Side[]) prop;
				for (Side side : clientSides) {
					result.add(side);
				}
			}
		}
		return result;
	}

	/**
	 * Returns the corner radius of the specified toolbar button.
	 * 
	 * @param button
	 *            Toolbar button.
	 * @param insets
	 *            Button insets.
	 * @return Corner radius of the specified toolbar button.
	 */
	public static float getToolbarButtonCornerRadius(AbstractButton button,
			Insets insets) {

		JToolBar toolbar = null;
		Component c = button.getParent();
		while (c != null) {
			if (c instanceof JToolBar) {
				toolbar = (JToolBar) c;
				break;
			}
			c = c.getParent();
		}
		if (toolbar == null)
			return 2.0f;

		int width = button.getWidth();
		int height = button.getHeight();

		if (insets != null) {
			width -= (insets.left + insets.right);
			height -= (insets.top + insets.bottom);
		}
		float maxRadius = (width > height) ? (height) / 2.0f : (width) / 2.0f;

		Object buttonProp = button
				.getClientProperty(SubstanceLookAndFeel.CORNER_RADIUS);
		if (buttonProp instanceof Float)
			return Math.min(maxRadius, ((Float) buttonProp).floatValue());

		Object toolbarProp = toolbar
				.getClientProperty(SubstanceLookAndFeel.CORNER_RADIUS);
		if (toolbarProp instanceof Float)
			return Math.min(maxRadius, ((Float) toolbarProp).floatValue());

		Object globalProp = UIManager.get(SubstanceLookAndFeel.CORNER_RADIUS);
		if (globalProp instanceof Float)
			return Math.min(maxRadius, ((Float) globalProp).floatValue());

		return 2.0f;
	}

	/**
	 * Returns the number of echo characters per each password chanaracter.
	 * 
	 * @param jpf
	 *            Password field.
	 * @return The number of echo characters per each password chanaracter.
	 */
	public static int getEchoPerChar(JPasswordField jpf) {
		Object obj = jpf
				.getClientProperty(SubstanceLookAndFeel.PASSWORD_ECHO_PER_CHAR);
		if ((obj != null) && (obj instanceof Integer)) {
			int result = (Integer) obj;
			if (result >= 1)
				return result;
		}

		obj = UIManager.get(SubstanceLookAndFeel.PASSWORD_ECHO_PER_CHAR);
		if ((obj != null) && (obj instanceof Integer)) {
			int result = (Integer) obj;
			if (result >= 1)
				return result;
		}
		return 1;
	}

	/**
	 * Creates a clip image for soft-clipping. Code taken from <a
	 * href="http://weblogs.java.net/blog/campbell/archive/2006/07/java_2d_tricker_2.html">here</a>.
	 * 
	 * @param s
	 *            Clip shape.
	 * @param width
	 *            Image width.
	 * @param height
	 *            Image height.
	 * @return Clip image.
	 * @author Chris Campbell.
	 */
	public static BufferedImage createClipImage(Shape s, int width, int height) {
		// Create a translucent intermediate image in which we can perform
		// the soft clipping
		GraphicsEnvironment e = GraphicsEnvironment
				.getLocalGraphicsEnvironment();
		GraphicsDevice d = e.getDefaultScreenDevice();
		GraphicsConfiguration c = d.getDefaultConfiguration();

		BufferedImage img = c.createCompatibleImage(width, height,
				Transparency.TRANSLUCENT);
		Graphics2D g2 = img.createGraphics();

		// Clear the image so all pixels have zero alpha
		g2.setComposite(AlphaComposite.Clear);
		g2.fillRect(0, 0, width, height);

		// Render our clip shape into the image. Note that we enable
		// antialiasing to achieve the soft clipping effect. Try
		// commenting out the line that enables antialiasing, and
		// you will see that you end up with the usual hard clipping.
		g2.setComposite(AlphaComposite.Src);
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setColor(Color.WHITE);
		g2.fill(s);
		g2.dispose();

		return img;
	}

	/**
	 * Checks whether the specified component can be pinned.
	 * 
	 * @param comp
	 *            Component.
	 * @return <code>true</code> if the specified component can be pinned,
	 *         <code>false</code> otherwise.
	 */
	public static boolean canBePinned(Component comp) {
		Component c = comp;
		while (c != null) {
			if (c instanceof JComponent) {
				JComponent jcomp = (JComponent) c;
				Object componentProp = jcomp
						.getClientProperty(SubstanceLookAndFeel.CAN_BE_PINNED);
				if (componentProp != null) {
					if (Boolean.TRUE.equals(componentProp))
						return true;
					if (Boolean.FALSE.equals(componentProp))
						return false;
				}
			}
			c = c.getParent();
		}
		if (Boolean.FALSE.equals(UIManager
				.get(SubstanceLookAndFeel.CAN_BE_PINNED)))
			return false;
		return true;
	}

	/**
	 * Checks whether the specified component is permanently pinned.
	 * 
	 * @param comp
	 *            Component.
	 * @return <code>true</code> if the specified component is permanently
	 *         pinned, <code>false</code> otherwise.
	 */
	public static boolean isPermanentlyPinned(Component comp) {
		if (comp instanceof JComponent) {
			JComponent jcomp = (JComponent) comp;
			Object componentProp = jcomp
					.getClientProperty(SubstanceLookAndFeel.PERMANENTLY_PINNED);
			if (componentProp != null) {
				if (Boolean.TRUE.equals(componentProp))
					return true;
				if (Boolean.FALSE.equals(componentProp))
					return false;
			}
		}
		return false;
	}

	/**
	 * Returns the color of mark icons (checkbox, radio button, scrollbar
	 * arrows, combo arrows, menu arrows etc) for the specified theme.
	 * 
	 * @param theme
	 *            Theme.
	 * @return Color of mark icons.
	 */
	public static Color getMarkColor(SubstanceTheme theme) {
		ColorScheme scheme = theme.getColorScheme();
		Color markColor = SubstanceCoreUtilities.isThemeDark(theme) ? SubstanceColorUtilities
				.getInterpolatedColor(scheme.getForegroundColor(), scheme
						.getUltraLightColor(), 0.7)
				: SubstanceColorUtilities.getInterpolatedColor(scheme
						.getUltraDarkColor(), scheme.getDarkColor(), 0.9);
		return markColor;
	}

	/**
	 * Checks whether the specified component has overlay enabled.
	 * 
	 * @param component
	 *            Component.
	 * @return <code>true</code> if the specified component has overlay
	 *         enabled, <code>false</code> otherwise.
	 */
	public static boolean hasOverlayProperty(Component component) {
		if (component instanceof JComponent) {
			Object flatProperty = ((JComponent) component)
					.getClientProperty(SubstanceLookAndFeel.OVERLAY_PROPERTY);
			if (Boolean.TRUE.equals(flatProperty))
				return true;
			if (Boolean.FALSE.equals(flatProperty))
				return false;
		}

		return Boolean.TRUE.equals(UIManager
				.get(SubstanceLookAndFeel.OVERLAY_PROPERTY));
	}

	/**
	 * Checks whether the specified component has extra Substance-specific UI
	 * elements.
	 * 
	 * @param component
	 *            Component.
	 * @return <code>true</code> if the specified component has extra
	 *         Substance-specific UI elements, <code>false</code> otherwise.
	 */
	public static boolean toShowExtraElements(Component component) {
		Component c = component;
		while (c != null) {
			if (c instanceof JComponent) {
				JComponent jcomp = (JComponent) c;
				Object componentProp = jcomp
						.getClientProperty(SubstanceLookAndFeel.NO_EXTRA_ELEMENTS);
				if (componentProp != null) {
					if (Boolean.TRUE.equals(componentProp))
						return false;
					if (Boolean.FALSE.equals(componentProp))
						return true;
				}
			}
			c = c.getParent();
		}
		return SubstanceLookAndFeel.toShowExtraElements();
	}

	/**
	 * Returns the thumb grip painter for the specified scroll bar.
	 * 
	 * @param scrollBar
	 *            Scroll bar.
	 * @return The thumb grip painter for the specified scroll bar.
	 */
	public static ScrollThumbGripPainter getThumbGripPainter(
			JScrollBar scrollBar) {
		Component c = scrollBar;
		while (c != null) {
			if (c instanceof JComponent) {
				JComponent jcomp = (JComponent) c;
				Object jcompSetting = jcomp
						.getClientProperty(SubstanceLookAndFeel.SCROLLBAR_GRIP_PAINTER);
				if (jcompSetting instanceof ScrollThumbGripPainter)
					return (ScrollThumbGripPainter) jcompSetting;
			}
			c = c.getParent();
		}
		Object globalSetting = UIManager
				.get(SubstanceLookAndFeel.SCROLLBAR_GRIP_PAINTER);
		if (globalSetting instanceof ScrollThumbGripPainter)
			return (ScrollThumbGripPainter) globalSetting;
		return null;
	}

	/**
	 * Returns indication whether the specified component's border is a
	 * Substance-specific border.
	 * 
	 * @param c
	 *            Component.
	 * @return <code>true</code> if the specified component's border is a
	 *         Substance-specific border, <code>false</code> otherwise.
	 */
	public static boolean hasSubstanceBorder(JComponent c) {
		if (c == null)
			return false;

		Border border = c.getBorder();
		if (border instanceof SubstanceBorder)
			return true;

		if (border instanceof CompoundBorder) {
			CompoundBorder cb = (CompoundBorder) border;
			if (cb.getOutsideBorder() instanceof SubstanceBorder)
				return true;
		}

		return false;
	}

	/**
	 * Returns the current icon for the specified button. This method is <b>for
	 * internal use only</b>.
	 * 
	 * @param b
	 *            Button.
	 * @return Icon for the specified button.
	 */
	public static Icon getIcon(AbstractButton b) {
		Icon icon = b.getIcon();
		Icon tmpIcon = null;
		ButtonModel model = b.getModel();

		if (icon != null) {
			if (!model.isEnabled()) {
				if (model.isSelected()) {
					tmpIcon = (Icon) b.getDisabledSelectedIcon();
				} else {
					tmpIcon = (Icon) b.getDisabledIcon();
				}
			} else if (model.isPressed() && model.isArmed()) {
				tmpIcon = (Icon) b.getPressedIcon();
			} else if (b.isRolloverEnabled() && model.isRollover()) {
				if (model.isSelected()) {
					tmpIcon = (Icon) b.getRolloverSelectedIcon();
				} else {
					tmpIcon = (Icon) b.getRolloverIcon();
				}
			} else if (model.isSelected()) {
				tmpIcon = (Icon) b.getSelectedIcon();
			}

			if (tmpIcon != null) {
				icon = tmpIcon;
			}
		}
		return icon;
	}

	/**
	 * Returns the global menu gutter fill kind.
	 * 
	 * @return The global menu gutter fill kind.
	 */
	public static MenuGutterFillKind getMenuGutterFillKind() {
		Object globalSetting = UIManager
				.get(SubstanceLookAndFeel.MENU_GUTTER_FILL_KIND);
		if (globalSetting instanceof MenuGutterFillKind)
			return (MenuGutterFillKind) globalSetting;
		return MenuGutterFillKind.HARD;
	}
}
