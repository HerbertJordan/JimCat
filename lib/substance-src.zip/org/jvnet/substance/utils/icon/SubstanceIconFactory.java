/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.utils.icon;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.lang.reflect.Field;
import java.util.*;

import javax.swing.*;
import javax.swing.plaf.SliderUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicSliderUI;

import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.*;
import org.jvnet.substance.button.BaseButtonShaper;
import org.jvnet.substance.color.ColorScheme;
import org.jvnet.substance.painter.SubstanceGradientPainter;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.*;

/**
 * Icon factory for dynamically-changing icons. This class is <b>for internal
 * use only</b>.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceIconFactory {
	/**
	 * Icons for check box menu item in {@link SubstanceCheckBoxMenuItemUI}.
	 */
	private static Map<Integer, Icon> checkBoxMenuItemIcons = new HashMap<Integer, Icon>();

	/**
	 * Icons for radio button menu item in
	 * {@link SubstanceRadioButtonMenuItemUI}.
	 */
	private static Map<Integer, Icon> radioButtonMenuItemIcons = new HashMap<Integer, Icon>();

	/**
	 * Icons for horizontal slider in {@link SubstanceSliderUI}.
	 */
	private static Map<String, Icon> sliderHorizontalIcons = new HashMap<String, Icon>();

	/**
	 * Icons for vertical slider in {@link SubstanceSliderUI}.
	 */
	private static Map<String, Icon> sliderVerticalIcons = new HashMap<String, Icon>();

	/**
	 * Resets image maps (used when setting new theme).
	 * 
	 * @see SubstanceLookAndFeel#setCurrentTheme(String)
	 * @see SubstanceLookAndFeel#setCurrentTheme(SubstanceTheme)
	 */
	public static synchronized void reset() {
		SubstanceIconFactory.checkBoxMenuItemIcons.clear();
		SubstanceIconFactory.radioButtonMenuItemIcons.clear();
		SubstanceIconFactory.sliderHorizontalIcons.clear();
		SubstanceIconFactory.sliderVerticalIcons.clear();

		SubstanceIconFactory.titlePaneIcons.get(IconKind.CLOSE).clear();
		SubstanceIconFactory.titlePaneIcons.get(IconKind.MINIMIZE).clear();
		SubstanceIconFactory.titlePaneIcons.get(IconKind.MAXIMIZE).clear();
		SubstanceIconFactory.titlePaneIcons.get(IconKind.RESTORE).clear();
	}

	/**
	 * Retrieves icon for check box menu item in
	 * {@link SubstanceCheckBoxMenuItemUI}.
	 * 
	 * @param size
	 *            The size of the icon to retrieve.
	 * @return Icon for check box menu item in
	 *         {@link SubstanceCheckBoxMenuItemUI}.
	 */
	public synchronized static Icon getCheckBoxMenuItemIcon(int size) {
		if (SubstanceIconFactory.checkBoxMenuItemIcons.get(size) == null) {
			Icon icon = new CheckBoxMenuItemIcon(size);
			SubstanceIconFactory.checkBoxMenuItemIcons.put(size, icon);
		}
		return SubstanceIconFactory.checkBoxMenuItemIcons.get(size);
	}

	/**
	 * Retrieves icon for radio button menu item in
	 * {@link SubstanceRadioButtonMenuItemUI}.
	 * 
	 * @param size
	 *            The size of the icon to retrieve.
	 * @return Icon for radio button menu item in
	 *         {@link SubstanceRadioButtonMenuItemUI}.
	 */
	public static Icon getRadioButtonMenuItemIcon(int size) {
		if (SubstanceIconFactory.radioButtonMenuItemIcons.get(size) == null) {
			Icon icon = new RadioButtonMenuItemIcon(size);
			SubstanceIconFactory.radioButtonMenuItemIcons.put(size, icon);
		}
		return SubstanceIconFactory.radioButtonMenuItemIcons.get(size);
	}

	/**
	 * Retrieves icon for horizontal slider in {@link SubstanceSliderUI}.
	 * 
	 * @param size
	 *            The size of the icon to retrieve.
	 * @param isMirrorred
	 *            Indication whether the icon should be mirrored.
	 * @return Icon for horizontal slider in {@link SubstanceSliderUI}.
	 */
	public static Icon getSliderHorizontalIcon(int size, boolean isMirrorred) {
		String key = size + ":" + isMirrorred;
		if (SubstanceIconFactory.sliderHorizontalIcons.get(key) == null) {
			Icon icon = new SliderHorizontalIcon(size, isMirrorred);
			SubstanceIconFactory.sliderHorizontalIcons.put(key, icon);
		}
		return SubstanceIconFactory.sliderHorizontalIcons.get(key);
	}

	/**
	 * Retrieves icon for vertical slider in {@link SubstanceSliderUI}.
	 * 
	 * @param size
	 *            The size of the icon to retrieve.
	 * @param isMirrorred
	 *            Indication whether the icon should be mirrored.
	 * @return Icon for vertical slider in {@link SubstanceSliderUI}.
	 */
	public static Icon getSliderVerticalIcon(int size, boolean isMirrorred) {
		String key = size + ":" + isMirrorred;
		if (SubstanceIconFactory.sliderVerticalIcons.get(key) == null) {
			Icon icon = new SliderVerticalIcon(size, isMirrorred);
			SubstanceIconFactory.sliderVerticalIcons.put(key, icon);
		}
		return SubstanceIconFactory.sliderVerticalIcons.get(key);
	}

	/**
	 * Icon for check box menu item in {@link SubstanceCheckBoxMenuItemUI}.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private static class CheckBoxMenuItemIcon implements Icon, UIResource {
		/**
		 * Icon hash.
		 */
		private Map<ColorScheme, Map<ComponentState, Icon>> icons;

		/**
		 * The size of <code>this</code> icon.
		 */
		private int size;

		/**
		 * Simple constructor.
		 * 
		 * @param size
		 *            The size of <code>this</code> icon.
		 */
		public CheckBoxMenuItemIcon(int size) {
			this.icons = new HashMap<ColorScheme, Map<ComponentState, Icon>>();
			this.size = size;
		}

		/**
		 * Retrieves icon pack for the currently used theme.
		 * 
		 * @return Icons for the currently used theme.
		 */
		private synchronized Map<ComponentState, Icon> getCurrentThemeIcons() {
			ColorScheme currColorScheme = SubstanceCoreUtilities
					.getActiveScheme(null);
			Map<ComponentState, Icon> currSchemeIcons = this.icons
					.get(currColorScheme);
			if (currSchemeIcons == null) {
				currSchemeIcons = new HashMap<ComponentState, Icon>();
				for (ComponentState state : ComponentState.values()) {
					currSchemeIcons.put(state, new ImageIcon(
							SubstanceImageCreator.getCheckBox(this.size + 3,
									state)));
				}
				this.icons.put(currColorScheme, currSchemeIcons);
			}
			return currSchemeIcons;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#paintIcon(java.awt.Component,
		 *      java.awt.Graphics, int, int)
		 */
		public void paintIcon(Component c, Graphics g, int x, int y) {
			JMenuItem b = (JMenuItem) c;

			// get the icons that match the current color scheme
			Icon iconToDraw = this.getCurrentThemeIcons().get(
					ComponentState.getState(b.getModel(), b));

			g.translate(x, y);
			iconToDraw.paintIcon(c, g, 0, 0);
			g.translate(-x, -y);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconWidth()
		 */
		public int getIconWidth() {
			return this.size + 2;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconHeight()
		 */
		public int getIconHeight() {
			return this.size + 2;
		}
	}

	/**
	 * Icon for for radio button menu item in
	 * {@link SubstanceRadioButtonMenuItemUI}.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private static class RadioButtonMenuItemIcon implements Icon, UIResource {
		/**
		 * Icon hash.
		 */
		private Map<ColorScheme, Map<ComponentState, Icon>> icons;

		/**
		 * The size of <code>this</code> icon.
		 */
		private int size;

		/**
		 * Simple constructor.
		 * 
		 * @param size
		 *            The size of <code>this</code> icon.
		 */
		public RadioButtonMenuItemIcon(int size) {
			this.icons = new HashMap<ColorScheme, Map<ComponentState, Icon>>();
			this.size = size;
		}

		/**
		 * Retrieves icon pack for the currently used theme.
		 * 
		 * @return Icons for the currently used theme.
		 */
		private synchronized Map<ComponentState, Icon> getCurrentThemeIcons() {
			ColorScheme currColorScheme = SubstanceCoreUtilities
					.getActiveScheme(null);
			Map<ComponentState, Icon> currSchemeIcons = this.icons
					.get(currColorScheme);
			if (currSchemeIcons == null) {
				currSchemeIcons = new HashMap<ComponentState, Icon>();
				for (ComponentState state : ComponentState.values()) {
					currSchemeIcons.put(state, new ImageIcon(
							SubstanceImageCreator.getRadioButton(this.size,
									state, 2)));
				}
				this.icons.put(currColorScheme, currSchemeIcons);
			}
			return currSchemeIcons;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#paintIcon(java.awt.Component,
		 *      java.awt.Graphics, int, int)
		 */
		public void paintIcon(Component c, Graphics g, int x, int y) {
			JMenuItem b = (JMenuItem) c;

			Icon iconToDraw = this.getCurrentThemeIcons().get(
					ComponentState.getState(b.getModel(), b));

			g.translate(x, y);
			iconToDraw.paintIcon(c, g, 0, 0);
			g.translate(-x, -y);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconWidth()
		 */
		public int getIconWidth() {
			return this.size + 2;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconHeight()
		 */
		public int getIconHeight() {
			return this.size;
		}
	}

	/**
	 * Trackable slider (for sliders that do not use {@link SubstanceSliderUI}
	 * as their UI (such as
	 * {@link contrib.ch.randelshofer.quaqua.colorchooser.ColorSliderUI}from
	 * Quaqua). Uses reflection to implement the {@link Trackable}interface,
	 * fetching the value of {@link BasicSliderUI#thumbRect}field.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private static class TrackableSlider implements Trackable {
		/**
		 * The associated slider.
		 */
		private JSlider slider;

		/**
		 * Reflection reference to {@link BasicSliderUI#thumbRect}field. If
		 * reflection failed, or no such field (for example the custom UI
		 * implements {@link SliderUI}directly, <code>this</code> field is
		 * <code>null</code>.
		 */
		private Field thumbRectField;

		/**
		 * Simple constructor.
		 * 
		 * @param slider
		 *            The associated slider.
		 */
		public TrackableSlider(JSlider slider) {
			this.slider = slider;

			SliderUI sliderUI = slider.getUI();
			if (sliderUI instanceof BasicSliderUI) {
				try {
					this.thumbRectField = BasicSliderUI.class
							.getDeclaredField("thumbRect");
					this.thumbRectField.setAccessible(true);
				} catch (Exception exc) {
					this.thumbRectField = null;
				}
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.jvnet.substance.Trackable#isInside(java.awt.event.MouseEvent)
		 */
		public boolean isInside(MouseEvent me) {
			try {
				Rectangle thumbB = (Rectangle) this.thumbRectField
						.get(this.slider.getUI());
				if (thumbB == null)
					return false;
				return thumbB.contains(me.getX(), me.getY());
			} catch (Exception exc) {
				return false;
			}
		}
	}

	/**
	 * Icon for horizontal slider in {@link SubstanceSliderUI}.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private static class SliderHorizontalIcon implements Icon, UIResource {
		/**
		 * Icon hash.
		 */
		// private Map<ColorScheme, Map<ComponentState, Icon>> icons;
		private static Map<String, Icon> icons = new HashMap<String, Icon>();

		/**
		 * The size of <code>this</code> icon.
		 */
		private int size;

		/**
		 * Indication whether the icon is mirrorred.
		 */
		private boolean isMirrorred;

		/**
		 * Contains models for the sliders whose UI is <b>not </b>
		 * {@link SubstanceSliderUI}. A model is used for rollover effects (as
		 * in {@link SubstanceSliderUI}and {@link SubstanceScrollBarUI}). Note
		 * that this is weak map (on keys) to allow disposing of unused keys.
		 */
		private WeakHashMap<JSlider, ButtonModel> models = new WeakHashMap<JSlider, ButtonModel>();

		/**
		 * Simple constructor.
		 * 
		 * @param size
		 *            The size of <code>this</code> icon.
		 * @param isMirrorred
		 *            Indication whether the icon should be mirrored.
		 */
		public SliderHorizontalIcon(int size, boolean isMirrorred) {
			// icons = new HashMap<ColorScheme, Map<ComponentState, Icon>>();
			this.size = size;
			this.isMirrorred = isMirrorred;
		}

		/**
		 * Retrieves icon that matches the specified state of the slider thumb.
		 * 
		 * @param state
		 *            Slider state.
		 * @param slider
		 *            The slider itself.
		 * @param sliderIcon
		 *            The slider icon.
		 * @return Icon that matches the specified state of the slider thumb.
		 */
		private static synchronized Icon getIcon(ComponentState state,
				JSlider slider, SliderHorizontalIcon sliderIcon) {

			ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();
			float cyclePos = state.getCycleCount();

			ColorScheme colorScheme = SubstanceCoreUtilities.getComponentTheme(
					slider, kind).getColorScheme();
			// SubstanceCoreUtilities.getTheme(kind)
			// .getColorScheme();
			ColorScheme colorScheme2 = colorScheme;

			FadeTracker fadeTracker = FadeTracker.getInstance();
			if (fadeTracker.isTracked(slider, FadeKind.ROLLOVER)) {
				ColorScheme defaultScheme = SubstanceCoreUtilities
						.getDefaultScheme(slider);
				if (state == ComponentState.DEFAULT) {
					// Came from rollover state
					colorScheme = SubstanceCoreUtilities.getActiveScheme(null);
					colorScheme2 = defaultScheme;
					cyclePos = 10 - fadeTracker.getFade10(slider,
							FadeKind.ROLLOVER);
				}
				if (state == ComponentState.ROLLOVER_UNSELECTED) {
					// Came from default state
					colorScheme2 = colorScheme;
					colorScheme = defaultScheme;
					cyclePos = fadeTracker.getFade10(slider, FadeKind.ROLLOVER);
				}
			}

			String key = sliderIcon.size + ":"
					+ SubstanceCoreUtilities.getSchemeId(colorScheme) + ":"
					+ SubstanceCoreUtilities.getSchemeId(colorScheme2) + ":"
					+ cyclePos;

			Icon result = SliderHorizontalIcon.icons.get(key);
			if (result != null)
				return result;

			SubstanceGradientPainter painter = SubstanceLookAndFeel
					.getCurrentGradientPainter();
			BufferedImage stateImage = painter.getContourBackground(
					2 * sliderIcon.size / 3, sliderIcon.size - 1,
					BaseButtonShaper.getTriangleButtonOutline(
							2 * sliderIcon.size / 3, sliderIcon.size - 1, 2),
					false, colorScheme, colorScheme2, cyclePos, true,
					colorScheme != colorScheme2);

			if (sliderIcon.isMirrorred)
				stateImage = SubstanceImageCreator.getRotated(stateImage, 2);
			// Graphics g = stateImage.getGraphics();
			// g.setColor(Color.red);
			// g.drawRect(0, 0, stateImage.getWidth()-1,
			// stateImage.getHeight()-1);

			result = new ImageIcon(stateImage);
			SliderHorizontalIcon.icons.put(key, result);

			return result;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#paintIcon(java.awt.Component,
		 *      java.awt.Graphics, int, int)
		 */
		public void paintIcon(Component c, Graphics g, int x, int y) {
			if (!(g instanceof Graphics2D)) {
				return;
			}

			JSlider slider = (JSlider) c;
			SliderUI sliderUI = slider.getUI();
			ComponentState state = ComponentState.ACTIVE;
			if (sliderUI instanceof SubstanceSliderUI) {
				state = ComponentState.getState(((SubstanceSliderUI) sliderUI)
						.getButtonModel(), null);
			} else {
				ButtonModel buttonModel = this.models.get(slider);
				if (buttonModel == null) {
					buttonModel = new DefaultButtonModel();
					RolloverControlListener listener = new RolloverControlListener(
							new TrackableSlider(slider), buttonModel);
					slider.addMouseListener(listener);
					slider.addMouseMotionListener(listener);
					this.models.put(slider, buttonModel);
				}
				state = ComponentState.getState(buttonModel, null);
			}
			Icon iconToDraw = SliderHorizontalIcon.getIcon(state, slider, this);

			iconToDraw.paintIcon(c, g, x, y);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconWidth()
		 */
		public int getIconWidth() {
			return 2 * this.size / 3;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconHeight()
		 */
		public int getIconHeight() {
			return this.size - 1;
		}
	}

	/**
	 * Icon for vertical slider in {@link SubstanceSliderUI}.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private static class SliderVerticalIcon implements Icon, UIResource {
		/**
		 * Icon hash.
		 */
		private static Map<String, Icon> icons = new HashMap<String, Icon>();

		/**
		 * The size of <code>this</code> icon.
		 */
		private int size;

		/**
		 * Indication whether the icon is mirrorred.
		 */
		private boolean isMirrorred;

		/**
		 * Contains models for the sliders whose UI is <b>not </b>
		 * {@link SubstanceSliderUI}. A model is used for rollover effects (as
		 * in {@link SubstanceSliderUI}and {@link SubstanceScrollBarUI}). Note
		 * that this is weak map (on keys) to allow disposing of unused keys.
		 */
		private WeakHashMap<JSlider, ButtonModel> models = new WeakHashMap<JSlider, ButtonModel>();

		/**
		 * Simple constructor.
		 * 
		 * @param size
		 *            The size of <code>this</code> icon.
		 * @param isMirrorred
		 *            Indication whether the icon should be mirrored.
		 */
		public SliderVerticalIcon(int size, boolean isMirrorred) {
			this.size = size;
			this.isMirrorred = isMirrorred;
		}

		/**
		 * Retrieves icon that matches the specified state of the slider thumb.
		 * 
		 * @param state
		 *            Slider state.
		 * @param slider
		 *            The slider itself.
		 * @param sliderIcon
		 *            The slider icon.
		 * @return Icon that matches the specified state of the slider thumb.
		 */
		private static synchronized Icon getIcon(ComponentState state,
				JSlider slider, SliderVerticalIcon sliderIcon) {

			ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();
			float cyclePos = state.getCycleCount();

			ColorScheme colorScheme = SubstanceCoreUtilities.getComponentTheme(
					slider, kind).getColorScheme();
			// SubstanceCoreUtilities.getTheme(kind)
			// .getColorScheme();
			ColorScheme colorScheme2 = colorScheme;

			FadeTracker fadeTracker = FadeTracker.getInstance();
			if (fadeTracker.isTracked(slider, FadeKind.ROLLOVER)) {
				ColorScheme defaultScheme = SubstanceCoreUtilities
						.getDefaultScheme(slider);
				if (state == ComponentState.DEFAULT) {
					// Came from rollover state
					colorScheme = SubstanceCoreUtilities.getActiveScheme(null);
					colorScheme2 = defaultScheme;
					cyclePos = 10 - fadeTracker.getFade10(slider,
							FadeKind.ROLLOVER);
				}
				if (state == ComponentState.ROLLOVER_UNSELECTED) {
					// Came from default state
					colorScheme2 = colorScheme;
					colorScheme = defaultScheme;
					cyclePos = fadeTracker.getFade10(slider, FadeKind.ROLLOVER);
				}
			}

			String key = sliderIcon.size + ":"
					+ slider.getComponentOrientation() + ":"
					+ SubstanceCoreUtilities.getSchemeId(colorScheme) + ":"
					+ SubstanceCoreUtilities.getSchemeId(colorScheme2) + ":"
					+ cyclePos;

			Icon result = SliderVerticalIcon.icons.get(key);
			if (result != null)
				return result;

			SubstanceGradientPainter painter = SubstanceLookAndFeel
					.getCurrentGradientPainter();
			BufferedImage stateImage = painter.getContourBackground(
					2 * (sliderIcon.size - 1) / 3, sliderIcon.size,
					BaseButtonShaper.getTriangleButtonOutline(
							2 * (sliderIcon.size - 1) / 3, sliderIcon.size, 2),
					false, colorScheme, colorScheme2, cyclePos, true,
					colorScheme != colorScheme2);

			if (sliderIcon.isMirrorred)
				stateImage = SubstanceImageCreator.getRotated(stateImage, 1);
			else
				stateImage = SubstanceImageCreator.getRotated(stateImage, 3);
			
			if (!slider.getComponentOrientation().isLeftToRight()) {
				stateImage = SubstanceImageCreator.getRotated(stateImage, 2);
			}

			// Graphics g = stateImage.getGraphics();
			// g.setColor(Color.red);
			// g.drawRect(0, 0, stateImage.getWidth()-1,
			// stateImage.getHeight()-1);

			result = new ImageIcon(stateImage);
			SliderVerticalIcon.icons.put(key, result);

			return result;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#paintIcon(java.awt.Component,
		 *      java.awt.Graphics, int, int)
		 */
		public void paintIcon(Component c, Graphics g, int x, int y) {
			if (!(g instanceof Graphics2D)) {
				return;
			}
			JSlider slider = (JSlider) c;
			SliderUI sliderUI = slider.getUI();
			ComponentState state = ComponentState.ACTIVE;
			if (sliderUI instanceof SubstanceSliderUI) {
				state = ComponentState.getState(((SubstanceSliderUI) sliderUI)
						.getButtonModel(), null);
			} else {
				ButtonModel buttonModel = this.models.get(slider);
				if (buttonModel == null) {
					buttonModel = new DefaultButtonModel();
					RolloverControlListener listener = new RolloverControlListener(
							new TrackableSlider(slider), buttonModel);
					slider.addMouseListener(listener);
					slider.addMouseMotionListener(listener);
					this.models.put(slider, buttonModel);
				}
				state = ComponentState.getState(buttonModel, null);
			}
			Icon iconToDraw = SliderVerticalIcon.getIcon(state, slider, this);
			iconToDraw.paintIcon(c, g, x, y);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconWidth()
		 */
		public int getIconWidth() {
			return this.size - 1;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.Icon#getIconHeight()
		 */
		public int getIconHeight() {
			return 2 * this.size / 3;
		}
	}

	/**
	 * Icon kind of a title pane button.
	 * 
	 * @author Kirill Grocuhnikov.
	 */
	public enum IconKind {
		/**
		 * Icon of a close button.
		 */
		CLOSE,

		/**
		 * Icon of a minimize button.
		 */
		MINIMIZE,

		/**
		 * Icon of a maximize button.
		 */
		MAXIMIZE,

		/**
		 * Icon of a restore button.
		 */
		RESTORE;
	}

	/**
	 * Cache of title pane icons.
	 */
	private static final Map<IconKind, Map<SubstanceTheme, Icon>> titlePaneIcons = SubstanceIconFactory
			.createTitlePaneIcons();

	/**
	 * Creates an empty map of title pane icons.
	 * 
	 * @return Empty map of title pane icons.
	 */
	private static Map<IconKind, Map<SubstanceTheme, Icon>> createTitlePaneIcons() {
		Map<IconKind, Map<SubstanceTheme, Icon>> result = new HashMap<IconKind, Map<SubstanceTheme, Icon>>();

		result.put(IconKind.CLOSE, new HashMap<SubstanceTheme, Icon>());
		result.put(IconKind.MINIMIZE, new HashMap<SubstanceTheme, Icon>());
		result.put(IconKind.MAXIMIZE, new HashMap<SubstanceTheme, Icon>());
		result.put(IconKind.RESTORE, new HashMap<SubstanceTheme, Icon>());
		return result;
	}

	/**
	 * Returns title pane icon of the specified kind.
	 * 
	 * @param iconKind
	 *            Icon kind.
	 * @param theme
	 *            Substance theme.
	 * @return Title pane icon of the specified kind.
	 */
	public static synchronized Icon getTitlePaneIcon(IconKind iconKind,
			SubstanceTheme theme) {
		Map<SubstanceTheme, Icon> kindMap = SubstanceIconFactory.titlePaneIcons
				.get(iconKind);
		Icon result = kindMap.get(theme);
		if (result != null)
			return result;

		switch (iconKind) {
		case CLOSE:
			result = SubstanceImageCreator.getCloseIcon(theme);
			break;
		case MINIMIZE:
			result = SubstanceImageCreator.getMinimizeIcon(theme);
			break;
		case MAXIMIZE:
			result = SubstanceImageCreator.getMaximizeIcon(theme);
			break;
		case RESTORE:
			result = SubstanceImageCreator.getRestoreIcon(theme);
			break;
		}
		kindMap.put(theme, result);
		return result;
	}

}