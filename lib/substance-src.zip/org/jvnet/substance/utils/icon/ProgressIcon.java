/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance.utils.icon;

import java.awt.*;
import java.awt.geom.GeneralPath;

import javax.swing.Icon;

import org.jvnet.substance.utils.SubstanceColorUtilities;

/**
 * Icon with overlayed progress indication. This class is <b>for internal use
 * only</b>.
 * 
 * @author Kirill Grouchnikov
 */
public class ProgressIcon implements Icon, IconWrapper {
	/**
	 * The original icon.
	 */
	private Icon originalIcon;

	/**
	 * The current cycle position.
	 */
	private float cyclePos;

	/**
	 * Constructs new icon with overlayed progress indication.
	 * 
	 * @param originalIcon
	 */
	public ProgressIcon(Icon originalIcon) {
		this.originalIcon = originalIcon;
		this.cyclePos = 0.0f;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.utils.icon.IconWrapper#setCyclePos(double)
	 */
	public void setCyclePos(double cyclePos) {
		this.cyclePos = (float) cyclePos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#getIconHeight()
	 */
	public int getIconHeight() {
		return this.originalIcon.getIconHeight();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#getIconWidth()
	 */
	public int getIconWidth() {
		return this.originalIcon.getIconWidth();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#paintIcon(java.awt.Component, java.awt.Graphics,
	 *      int, int)
	 */
	public void paintIcon(Component c, Graphics g, int x, int y) {
		Graphics2D g2 = (Graphics2D) g.create();

		float transp = (this.cyclePos < 0.5) ? 2.0f * this.cyclePos
				: 2.f * (1 - this.cyclePos);
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
				0.5f * transp));
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		this.originalIcon.paintIcon(c, g2, x, y);

		g2.setComposite(AlphaComposite
				.getInstance(AlphaComposite.SRC_OVER, 1.f));
		double pos = (((int) (this.cyclePos * 10))) / 10.;
		double leadAngle = Math.PI / 2.0 + 2.0 * pos * Math.PI;

		for (int i = 0; i < 10; i++) {
			double trailAngle = leadAngle - Math.PI / 10.0;

			double r = this.getIconWidth() / 2.5;
			double d = this.getIconWidth() / 8.0;
			double cx = x + this.getIconWidth() / 2.0;
			double cy = y + this.getIconHeight() / 2.0;

			double lx = cx + r * Math.cos(leadAngle);
			double ly = cy + r * Math.sin(leadAngle);
			double tnx = cx + (r - d) * Math.cos(trailAngle);
			double tny = cy + (r - d) * Math.sin(trailAngle);
			double tfx = cx + (r + d) * Math.cos(trailAngle);
			double tfy = cy + (r + d) * Math.sin(trailAngle);

			GeneralPath gp = new GeneralPath();
			gp.moveTo((float) tnx, (float) tny);
			gp.lineTo((float) lx, (float) ly);
			gp.lineTo((float) tfx, (float) tfy);

			g2.setStroke(new BasicStroke(3.2f));
			g2.setColor(new Color(255, 255, 255, 96));
			g2.draw(gp);

			g2.setStroke(new BasicStroke(2.0f));
			g2.setColor(Color.black);
			g2.draw(gp);

			if (i < 5) {
				g2.setColor(SubstanceColorUtilities.getInterpolatedColor(
						Color.black, Color.white, i / 5.0));
				g2.setStroke(new BasicStroke(1.4f));
				g2.draw(gp);
			}

			leadAngle -= Math.PI / 5.0;
		}
		g2.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.substance.utils.icon.IconWrapper#getOriginalIcon()
	 */
	public Icon getOriginalIcon() {
		return this.originalIcon;
	}
}
