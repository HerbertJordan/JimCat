/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicButtonListener;

import org.jvnet.lafwidget.utils.FadeStateListener;
import org.jvnet.lafwidget.utils.FadeTracker;
import org.jvnet.lafwidget.utils.FadeTracker.FadeKind;
import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.*;

/**
 * UI for check boxes in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceCheckBoxUI extends SubstanceRadioButtonUI {
	/**
	 * Prefix for the checkbox-related properties in the {@link UIManager}.
	 */
	private final static String propertyPrefix = "CheckBox" + ".";

	/**
	 * Listener for fade animations.
	 */
	protected FadeStateListener substanceFadeStateListener;

	/**
	 * Property change listener. Listens on changes to
	 * {@link AbstractButton#MODEL_CHANGED_PROPERTY} property.
	 */
	protected PropertyChangeListener substancePropertyListener;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent b) {
		return new SubstanceCheckBoxUI((JToggleButton) b);
	}

	/**
	 * Hash map for storing icons.
	 */
	private static Map<String, Icon> icons = new HashMap<String, Icon>();

	/**
	 * Simple constructor.
	 * 
	 * @param button
	 *            The associated button.
	 */
	private SubstanceCheckBoxUI(JToggleButton button) {
		super(button);
		button.setRolloverEnabled(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicRadioButtonUI#getPropertyPrefix()
	 */
	@Override
	protected String getPropertyPrefix() {
		return propertyPrefix;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#installListeners(javax.swing.AbstractButton)
	 */
	@Override
	protected void installListeners(final AbstractButton b) {
		super.installListeners(b);
		this.substanceFadeStateListener = new FadeStateListener(b,
				b.getModel(), null);
		this.substanceFadeStateListener.registerListeners();

		this.substancePropertyListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (AbstractButton.MODEL_CHANGED_PROPERTY.equals(evt
						.getPropertyName())) {
					if (substanceFadeStateListener != null)
						substanceFadeStateListener.unregisterListeners();
					substanceFadeStateListener = new FadeStateListener(b, b
							.getModel(), null);
					substanceFadeStateListener.registerListeners();
				}
			}
		};
		b.addPropertyChangeListener(this.substancePropertyListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#uninstallListeners(javax.swing.AbstractButton)
	 */
	@Override
	protected void uninstallListeners(AbstractButton b) {
		this.substanceFadeStateListener.unregisterListeners();
		this.substanceFadeStateListener = null;

		b.removePropertyChangeListener(this.substancePropertyListener);
		this.substancePropertyListener = null;

		super.uninstallListeners(b);
	}

	/**
	 * Default checkbox dimension.
	 */
	private static final int DIMENSION = 16;

	/**
	 * Resets image maps (used when setting new theme).
	 * 
	 * @see SubstanceLookAndFeel#setCurrentTheme(String)
	 * @see SubstanceLookAndFeel#setCurrentTheme(SubstanceTheme)
	 */
	public static synchronized void reset() {
		SubstanceCheckBoxUI.icons.clear();
	}

	/**
	 * Returns the icon that matches the specified state of the specified
	 * button.
	 * 
	 * @param button
	 *            Button (should be {@link JCheckBox}).
	 * @param state
	 *            Button state.
	 * @return Matching icon.
	 */
	private static synchronized Icon getIcon(JToggleButton button,
			ComponentState state) {
		// check if fading
		FadeTracker fadeTracker = FadeTracker.getInstance();
		float visibility = state.isSelected() ? 10 : 0;
		if (fadeTracker.isTracked(button, FadeKind.SELECTION)) {
			visibility = fadeTracker.getFade10(button, FadeKind.SELECTION);
		}

		if (fadeTracker.isTracked(button, FadeKind.ROLLOVER)) {
			SubstanceTheme defaultTheme = SubstanceCoreUtilities
					.getDefaultTheme(button, true);
			SubstanceTheme theme = SubstanceCoreUtilities.getActiveTheme(
					button, true);
			SubstanceTheme theme2 = theme;
			float cyclePos = 0;
			// Control remains colored when it's selected. In addition, no
			// fading on disabled controls.
			if (!state.isSelected() && state.isEnabled()) {
				if (state == ComponentState.DEFAULT) {
					// Came from rollover state
					theme2 = defaultTheme;
					cyclePos = 10 - fadeTracker.getFade10(button,
							FadeKind.ROLLOVER);
				} else {
					// Came from default state
					theme2 = theme;
					theme = defaultTheme;
					cyclePos = fadeTracker.getFade10(button, FadeKind.ROLLOVER);
				}

				String key = state.name() + ":" + theme.getDisplayName() + ":"
						+ theme2.getDisplayName() + ":" + cyclePos + ":"
						+ visibility;
				Icon result = SubstanceCheckBoxUI.icons.get(key);
				if (result != null)
					return result;
				result = new ImageIcon(SubstanceImageCreator.getCheckBox(
						button, SubstanceCheckBoxUI.DIMENSION, state, theme,
						theme2, cyclePos, visibility / 10.f));
				SubstanceCheckBoxUI.icons.put(key, result);
				return result;
			}
		}

		ComponentState.ColorSchemeKind kind = state.getColorSchemeKind();
		SubstanceTheme theme = SubstanceCoreUtilities.getComponentTheme(button,
				kind);
		int cyclePos = state.getCycleCount();

		String key = state.name() + ":" + theme.getDisplayName() + ":"
				+ theme.getDisplayName() + ":" + cyclePos + ":" + visibility;

		Icon result = SubstanceCheckBoxUI.icons.get(key);
		if (result != null)
			return result;
		result = new ImageIcon(SubstanceImageCreator.getCheckBox(button,
				SubstanceCheckBoxUI.DIMENSION, state, theme, theme, cyclePos,
				visibility / 10.f));
		SubstanceCheckBoxUI.icons.put(key, result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#createButtonListener(javax.swing.AbstractButton)
	 */
	@Override
	protected BasicButtonListener createButtonListener(AbstractButton b) {
		return new RolloverButtonListener(b);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicRadioButtonUI#getDefaultIcon()
	 */
	@Override
	public Icon getDefaultIcon() {
		ButtonModel model = this.button.getModel();
		return SubstanceCheckBoxUI.getIcon(this.button, ComponentState
				.getState(model, this.button));
	}

	/**
	 * Returns memory usage string.
	 * 
	 * @return Memory usage string.
	 */
	public static String getMemoryUsage() {
		StringBuffer sb = new StringBuffer();
		sb.append("SubstanceCheckBox: \n");
		sb.append("\t" + SubstanceCheckBoxUI.icons.size() + " icons");
		return sb.toString();
	}
}
