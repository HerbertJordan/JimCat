/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JComponent;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTableHeaderUI;
import javax.swing.table.*;

import org.jvnet.substance.theme.SubstanceTheme;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for table headers in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceTableHeaderUI extends BasicTableHeaderUI {
	/**
	 * Delegate for painting the background.
	 */
	private static SubstanceGradientBackgroundDelegate backgroundDelegate = new SubstanceGradientBackgroundDelegate();

	/**
	 * Repaints the header on column selection.
	 */
	protected TableHeaderListener substanceHeaderListener;

	/**
	 * Listener for table header.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private static class TableHeaderListener implements ListSelectionListener {
		/**
		 * The associated table header UI.
		 */
		private SubstanceTableHeaderUI ui;

		/**
		 * Simple constructor.
		 * 
		 * @param ui
		 *            The associated table header UI
		 */
		public TableHeaderListener(SubstanceTableHeaderUI ui) {
			this.ui = ui;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
		 */
		public void valueChanged(ListSelectionEvent e) {
			if (this.ui.header == null)
				return;
			if (this.ui.header.isValid())
				this.ui.header.repaint();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent h) {
		SubstanceTableHeaderUI result = new SubstanceTableHeaderUI();
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTableHeaderUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();
		TableColumnModel columnModel = this.header.getColumnModel();
		if (columnModel != null) {
			ListSelectionModel lsm = columnModel.getSelectionModel();
			if (lsm != null) {
				// fix for defect 109 - memory leak on theme switch
				this.substanceHeaderListener = new TableHeaderListener(this);
				lsm.addListSelectionListener(this.substanceHeaderListener);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicTableHeaderUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		super.uninstallListeners();
		// fix for defect 109 - memory leak on theme switch
		TableColumnModel columnModel = this.header.getColumnModel();
		if (columnModel != null) {
			ListSelectionModel lsm = columnModel.getSelectionModel();
			if (lsm != null) {
				lsm.removeListSelectionListener(this.substanceHeaderListener);
				this.substanceHeaderListener = null;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		if (this.header.getColumnModel().getColumnCount() <= 0) {
			return;
		}
		boolean ltr = this.header.getComponentOrientation().isLeftToRight();

		Rectangle clip = g.getClipBounds();
		Point left = clip.getLocation();
		Point right = new Point(clip.x + clip.width - 1, clip.y);

		TableColumnModel cm = this.header.getColumnModel();
		int[] selectedColumns = cm.getSelectedColumns();
		Set<Integer> selected = new HashSet<Integer>();
		for (int sel : selectedColumns)
			selected.add(sel);

		int cMin = this.header.columnAtPoint(ltr ? left : right);
		int cMax = this.header.columnAtPoint(ltr ? right : left);
		// This should never happen.
		if (cMin == -1) {
			cMin = 0;
		}
		// If the table does not have enough columns to fill the view we'll get
		// -1.
		// Replace this with the index of the last column.
		if (cMax == -1) {
			cMax = cm.getColumnCount() - 1;
		}

		TableColumn draggedColumn = this.header.getDraggedColumn();
		int columnWidth;
		Rectangle cellRect = this.header.getHeaderRect(ltr ? cMin : cMax);
		TableColumn aColumn;
		if (ltr) {
			for (int column = cMin; column <= cMax; column++) {
				aColumn = cm.getColumn(column);
				columnWidth = aColumn.getWidth();
				cellRect.width = columnWidth;
				if (aColumn != draggedColumn) {
					this.paintCell(g, cellRect, column, selected
							.contains(column));
				}
				cellRect.x += columnWidth;
			}
		} else {
			for (int column = cMax; column >= cMin; column--) {
				aColumn = cm.getColumn(column);
				columnWidth = aColumn.getWidth();
				cellRect.width = columnWidth;
				if (aColumn != draggedColumn) {
					this.paintCell(g, cellRect, column, selected
							.contains(column));
				}
				cellRect.x += columnWidth;
			}
		}

		// Paint the dragged column if we are dragging.
		if (draggedColumn != null) {
			int draggedColumnIndex = this.viewIndexForColumn(draggedColumn);
			Rectangle draggedCellRect = this.header
					.getHeaderRect(draggedColumnIndex);

			// Draw a gray well in place of the moving column.
			g.setColor(this.header.getParent().getBackground());
			g.fillRect(draggedCellRect.x, draggedCellRect.y,
					draggedCellRect.width, draggedCellRect.height);

			draggedCellRect.x += this.header.getDraggedDistance();

			// Fill the background.
			g.setColor(this.header.getBackground());
			g.fillRect(draggedCellRect.x, draggedCellRect.y,
					draggedCellRect.width, draggedCellRect.height);

			this.paintCell(g, draggedCellRect, draggedColumnIndex, selected
					.contains(draggedColumnIndex));
		}

		// Remove all components in the rendererPane.
		this.rendererPane.removeAll();
	}

	/**
	 * Retrieves renderer for the specified column header.
	 * 
	 * @param columnIndex
	 *            Column index.
	 * @return Renderer for the specified column header.
	 */
	private Component getHeaderRenderer(int columnIndex) {
		TableColumn aColumn = this.header.getColumnModel().getColumn(
				columnIndex);
		TableCellRenderer renderer = aColumn.getHeaderRenderer();
		if (renderer == null) {
			renderer = this.header.getDefaultRenderer();
		}
		return renderer.getTableCellRendererComponent(this.header.getTable(),
				aColumn.getHeaderValue(), false, false, -1, columnIndex);
	}

	/**
	 * Paints cell.
	 * 
	 * @param g
	 *            Graphic context.
	 * @param cellRect
	 *            Cell rectangle.
	 * @param columnIndex
	 *            Column index.
	 * @param isSelected
	 *            Selection indication.
	 */
	private void paintCell(Graphics g, Rectangle cellRect, int columnIndex,
			boolean isSelected) {
		Component component = this.getHeaderRenderer(columnIndex);
		SubstanceTheme theme = isSelected ? SubstanceCoreUtilities
				.getActiveTheme(this.header, true) : SubstanceCoreUtilities
				.getDefaultTheme(this.header, true);
		SubstanceTableHeaderUI.backgroundDelegate.update(g, component,
				cellRect, theme.getHighlightBackgroundTheme(), true);
		this.rendererPane.paintComponent(g, component, this.header, cellRect.x,
				cellRect.y, cellRect.width, cellRect.height, true);
	}

	/**
	 * Retrieves view index for the specified column.
	 * 
	 * @param aColumn
	 *            Table column.
	 * @return View index for the specified column.
	 */
	private int viewIndexForColumn(TableColumn aColumn) {
		TableColumnModel cm = this.header.getColumnModel();
		for (int column = 0; column < cm.getColumnCount(); column++) {
			if (cm.getColumn(column) == aColumn) {
				return column;
			}
		}
		return -1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		// fix for issue 175 - table header under resize mode off
		// was painted in theme-agnostic (gray) color.
		SubstanceTheme theme = SubstanceCoreUtilities.getDefaultTheme(
				this.header, true);
		SubstanceTableHeaderUI.backgroundDelegate.update(g, c, c.getBounds(),
				theme.getHighlightBackgroundTheme(), true);
		this.paint(g, c);
	}
}
