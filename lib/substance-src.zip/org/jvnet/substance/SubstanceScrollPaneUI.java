/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Area;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashSet;
import java.util.Set;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicScrollPaneUI;

import org.jvnet.lafwidget.layout.TransitionBorder;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.substance.scroll.SubstanceScrollPaneBorder;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * UI for scroll panes in <b>Substance</b> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceScrollPaneUI extends BasicScrollPaneUI {
	/**
	 * Property change listener on
	 * {@link SubstanceLookAndFeel#SCROLL_PANE_BUTTONS_POLICY},
	 * {@link SubstanceLookAndFeel#WATERMARK_TO_BLEED} and
	 * <code>layoutManager</code> properties.
	 */
	protected PropertyChangeListener substancePropertyChangeListener;

	/**
	 * Background delegate.
	 */
	protected static SubstanceFillBackgroundDelegate bgDelegate = new SubstanceFillBackgroundDelegate();

	/**
	 * Creates new UI delegate.
	 * 
	 * @param c
	 *            Component.
	 * @return UI delegate for the component.
	 */
	public static ComponentUI createUI(JComponent c) {
		return new SubstanceScrollPaneUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicScrollPaneUI#installDefaults(javax.swing.JScrollPane)
	 */
	@Override
	protected void installDefaults(JScrollPane scrollpane) {
		super.installDefaults(scrollpane);
		if (SubstanceCoreUtilities.toBleedWatermark(this.scrollpane)) {
			this.scrollpane.setOpaque(false);
			this.scrollpane.getViewport().setOpaque(false);
		}
		// if (SubstanceCoreUtilities.toShowExtraElements(scrollpane)) {
		// ScrollPaneSelector.installScrollPaneSelector(scrollpane);
		// }
		scrollpane.setLayout(new AdjustedLayout((ScrollPaneLayout) scrollpane
				.getLayout()));
	}

	@Override
	protected void uninstallDefaults(JScrollPane c) {
		c.setLayout(((AdjustedLayout) scrollpane.getLayout()).delegate);
		super.uninstallDefaults(c);
	}

	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// javax.swing.plaf.basic.BasicScrollPaneUI#uninstallDefaults(javax.swing.JScrollPane)
	// */
	// @Override
	// protected void uninstallDefaults(JScrollPane c) {
	// super.uninstallDefaults(c);
	// ScrollPaneSelector.uninstallScrollPaneSelector(scrollpane);
	// }
	//
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicScrollPaneUI#installListeners(javax.swing.JScrollPane)
	 */
	@Override
	protected void installListeners(final JScrollPane c) {
		super.installListeners(c);
		this.substancePropertyChangeListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (SubstanceLookAndFeel.SCROLL_PANE_BUTTONS_POLICY.equals(evt
						.getPropertyName())) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							c.getHorizontalScrollBar().doLayout();
							c.getVerticalScrollBar().doLayout();
						}
					});
				}
				if (SubstanceLookAndFeel.WATERMARK_TO_BLEED.equals(evt
						.getPropertyName())) {
					boolean toBleed = SubstanceCoreUtilities
							.toBleedWatermark(c);
					c.setOpaque(!toBleed);
					c.getViewport().setOpaque(!toBleed);
					Component view = c.getViewport().getView();
					if (view instanceof JComponent)
						((JComponent) view).setOpaque(!toBleed);
				}
				if ("layoutManager".equals(evt.getPropertyName())) {
					if (((Boolean) evt.getNewValue()).booleanValue()) {
						ScrollPaneLayout currLayout = (ScrollPaneLayout) c
								.getLayout();
						if (!(currLayout instanceof AdjustedLayout)) {
							c.setLayout(new AdjustedLayout((ScrollPaneLayout) c
									.getLayout()));
						}
					}
					// else {
					// ScrollPaneLayout currLayout = (ScrollPaneLayout) c
					// .getLayout();
					// if (currLayout instanceof AdjustedLayout) {
					// c.setLayout(((AdjustedLayout) currLayout).delegate);
					// }
					// }
				}
			}
		};
		c.addPropertyChangeListener(this.substancePropertyChangeListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicScrollPaneUI#uninstallListeners(javax.swing.JComponent)
	 */
	@Override
	protected void uninstallListeners(JComponent c) {
		c.removePropertyChangeListener(this.substancePropertyChangeListener);
		this.substancePropertyChangeListener = null;
		super.uninstallListeners(c);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicScrollPaneUI#createMouseWheelListener()
	 */
	@Override
	protected MouseWheelListener createMouseWheelListener() {
		return new MouseWheelHandler();
	}

	/**
	 * Custom mouse wheel handler. Provides faster scrolling - issue 87.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class MouseWheelHandler implements MouseWheelListener {
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.MouseWheelListener#mouseWheelMoved(java.awt.event.MouseWheelEvent)
		 */
		public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
			if (SubstanceScrollPaneUI.this.scrollpane.isWheelScrollingEnabled()
					&& (e.getScrollAmount() != 0)) {
				JScrollBar toScroll = SubstanceScrollPaneUI.this.scrollpane
						.getVerticalScrollBar();
				int direction = 0;

				// find which scrollbar to scroll, or return if none
				if ((toScroll == null) || !toScroll.isVisible()
						|| (e.getModifiers() == InputEvent.ALT_MASK)) {
					toScroll = SubstanceScrollPaneUI.this.scrollpane
							.getHorizontalScrollBar();

					if ((toScroll == null) || !toScroll.isVisible()) {
						return;
					}
				}

				direction = (e.getWheelRotation() < 0) ? (-1) : 1;

				SubstanceScrollBarUI ui = (SubstanceScrollBarUI) toScroll
						.getUI();
				if (e.getScrollType() == MouseWheelEvent.WHEEL_UNIT_SCROLL) {
					ui.scrollByUnits(direction, 2 * e.getScrollAmount());
				} else if (e.getScrollType() == MouseWheelEvent.WHEEL_BLOCK_SCROLL) {
					ui.scrollByBlock(direction);
				}
			}
		}
	}

	/**
	 * Layout manager to adjust the bounds of scrollbars and the viewport when
	 * the default ({@link SubstanceScrollPaneBorder}) border is set on the
	 * relevant {@link JScrollPane}.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class AdjustedLayout extends ScrollPaneLayout implements
			UIResource {
		/**
		 * The delegate layout.
		 */
		protected ScrollPaneLayout delegate;

		/**
		 * Creates a new layout for adjusting the bounds of scrollbars and the
		 * viewport.
		 * 
		 * @param delegate
		 *            The original (delegate) layout.
		 */
		public AdjustedLayout(ScrollPaneLayout delegate) {
			this.delegate = delegate;
		}

		public void addLayoutComponent(String s, Component c) {
			delegate.addLayoutComponent(s, c);
		}

		public boolean equals(Object obj) {
			return delegate.equals(obj);
		}

		public JViewport getColumnHeader() {
			return delegate.getColumnHeader();
		}

		public Component getCorner(String key) {
			return delegate.getCorner(key);
		}

		public JScrollBar getHorizontalScrollBar() {
			return delegate.getHorizontalScrollBar();
		}

		public int getHorizontalScrollBarPolicy() {
			return delegate.getHorizontalScrollBarPolicy();
		}

		public JViewport getRowHeader() {
			return delegate.getRowHeader();
		}

		public JScrollBar getVerticalScrollBar() {
			return delegate.getVerticalScrollBar();
		}

		public int getVerticalScrollBarPolicy() {
			return delegate.getVerticalScrollBarPolicy();
		}

		public JViewport getViewport() {
			return delegate.getViewport();
		}

		@SuppressWarnings("deprecation")
		public Rectangle getViewportBorderBounds(JScrollPane scrollpane) {
			return delegate.getViewportBorderBounds(scrollpane);
		}

		public int hashCode() {
			return delegate.hashCode();
		}

		public Dimension minimumLayoutSize(Container parent) {
			return delegate.minimumLayoutSize(parent);
		}

		public Dimension preferredLayoutSize(Container parent) {
			return delegate.preferredLayoutSize(parent);
		}

		public void removeLayoutComponent(Component c) {
			delegate.removeLayoutComponent(c);
		}

		public void setHorizontalScrollBarPolicy(int x) {
			delegate.setHorizontalScrollBarPolicy(x);
		}

		public void setVerticalScrollBarPolicy(int x) {
			delegate.setVerticalScrollBarPolicy(x);
		}

		public void syncWithScrollPane(JScrollPane sp) {
			delegate.syncWithScrollPane(sp);
		}

		public String toString() {
			return delegate.toString();
		}

		// ScrollPaneLayout.UIResource {
		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.swing.ScrollPaneLayout#layoutContainer(java.awt.Container)
		 */
		@Override
		public void layoutContainer(Container parent) {
			delegate.layoutContainer(parent);

			JScrollPane scrollPane = (JScrollPane) parent;
			Border border = scrollPane.getBorder();
			boolean toAdjust = (border instanceof SubstanceScrollPaneBorder);
			if (border instanceof TransitionBorder) {
				toAdjust = (((TransitionBorder) border).getDelegate() instanceof SubstanceScrollPaneBorder);
			}
			if (toAdjust) {
				JScrollBar vertical = scrollPane.getVerticalScrollBar();
				JScrollBar horizontal = scrollPane.getHorizontalScrollBar();

				int dx = 0, dy = 0, dw = 0, dh = 0;
				if (scrollPane.getComponentOrientation().isLeftToRight()) {
					if (vertical.isVisible()) {
						Rectangle vBounds = vertical.getBounds();
						dw++;
						vertical.setBounds(vBounds.x + 1, vBounds.y - 1,
								vBounds.width, vBounds.height + 2);
					}
					if (horizontal.isVisible()) {
						dh++;
						Rectangle hBounds = horizontal.getBounds();
						horizontal.setBounds(hBounds.x - 1, hBounds.y + 1,
								hBounds.width + 2, hBounds.height);
					}
					if (delegate.getCorner(ScrollPaneLayout.LOWER_RIGHT_CORNER) != null) {
						Rectangle lrBounds = delegate.getCorner(
								ScrollPaneLayout.LOWER_RIGHT_CORNER)
								.getBounds();
						delegate.getCorner(ScrollPaneLayout.LOWER_RIGHT_CORNER)
								.setBounds(lrBounds.x + 1, lrBounds.y + 1,
										lrBounds.width, lrBounds.height);
					}
				} else {
					if (vertical.isVisible()) {
						dx--;
						dw++;
						Rectangle vBounds = vertical.getBounds();
						vertical.setBounds(vBounds.x - 1, vBounds.y - 1,
								vBounds.width, vBounds.height + 2);
					}
					if (horizontal.isVisible()) {
						dh++;
						Rectangle hBounds = horizontal.getBounds();
						horizontal.setBounds(hBounds.x - 1, hBounds.y + 1,
								hBounds.width + 2, hBounds.height);
					}
					if (delegate.getCorner(ScrollPaneLayout.LOWER_LEFT_CORNER) != null) {
						Rectangle llBounds = delegate.getCorner(
								ScrollPaneLayout.LOWER_LEFT_CORNER).getBounds();
						delegate.getCorner(ScrollPaneLayout.LOWER_LEFT_CORNER)
								.setBounds(llBounds.x - 1, llBounds.y - 1,
										llBounds.width, llBounds.height);
					}
				}

				if (delegate.getViewport() != null) {
					Rectangle vpBounds = delegate.getViewport().getBounds();
					delegate.getViewport().setBounds(
							new Rectangle(vpBounds.x + dx, vpBounds.y + dy,
									vpBounds.width + dw, vpBounds.height + dh));
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	public void update(Graphics g, JComponent c) {
		if (TransitionLayout.isOpaque(c)) {
			bgDelegate.update(g, c);
		}
		JScrollPane jsp = (JScrollPane) c;
		if (SubstanceCoreUtilities.hasOverlayProperty(jsp)) {
			JViewport viewport = jsp.getViewport();
			int dx = -viewport.getX() + viewport.getViewRect().x;
			int dy = viewport.getY() - viewport.getViewRect().y;
			Graphics2D graphics = (Graphics2D) g.create();

			Area clip = new Area();
			if ((jsp.getVerticalScrollBar() != null)
					&& jsp.getVerticalScrollBar().isVisible())
				clip.add(new Area(jsp.getVerticalScrollBar().getBounds()));
			if ((jsp.getHorizontalScrollBar() != null)
					&& jsp.getHorizontalScrollBar().isVisible())
				clip.add(new Area(jsp.getHorizontalScrollBar().getBounds()));
			graphics.setClip(clip);

			graphics.translate(-dx, dy);
			JComponent view = (JComponent) viewport.getView();
			boolean wasDb = view.isDoubleBuffered();
			view.setDoubleBuffered(false);
			view.paint(graphics);
			view.setDoubleBuffered(wasDb);
			graphics.translate(dx, -dy);
			graphics.dispose();
		}

		LayoutManager lm = jsp.getLayout();
		ScrollPaneLayout scrollLm = null;
		if (lm instanceof ScrollPaneLayout) {
			scrollLm = (ScrollPaneLayout) lm;
		} else {
			if (lm instanceof TransitionLayout) {
				LayoutManager origLm = ((TransitionLayout) lm).getDelegate();
				if (origLm instanceof ScrollPaneLayout) {
					scrollLm = (ScrollPaneLayout) origLm;
				}
			}
		}

		if (scrollLm != null) {
			Set<Component> corners = new HashSet<Component>();
			if (scrollLm.getCorner(ScrollPaneLayout.LOWER_LEFT_CORNER) != null) {
				corners.add(scrollLm
						.getCorner(ScrollPaneLayout.LOWER_LEFT_CORNER));
			}
			if (scrollLm.getCorner(ScrollPaneLayout.LOWER_RIGHT_CORNER) != null) {
				corners.add(scrollLm
						.getCorner(ScrollPaneLayout.LOWER_RIGHT_CORNER));
			}
			if (scrollLm.getCorner(ScrollPaneLayout.UPPER_LEFT_CORNER) != null) {
				corners.add(scrollLm
						.getCorner(ScrollPaneLayout.UPPER_LEFT_CORNER));
			}
			if (scrollLm.getCorner(ScrollPaneLayout.UPPER_RIGHT_CORNER) != null) {
				corners.add(scrollLm
						.getCorner(ScrollPaneLayout.UPPER_RIGHT_CORNER));
			}

			if (TransitionLayout.isOpaque(c)) {
				for (Component corner : corners) {
					bgDelegate.update(g, c, corner.getBounds());
				}
			}
		}

		super.paint(g, c);
	}
}
