/*
 * Copyright (c) 2005-2007 Substance Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Substance Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.substance;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.plaf.basic.BasicSplitPaneDivider;

import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Split pane divider in <code>Substance</code> look and feel.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceSplitPaneDivider extends BasicSplitPaneDivider {
	/**
	 * Background delegate.
	 */
	private SubstanceFillBackgroundDelegate bgDelegate;

	/**
	 * Simple constructor.
	 * 
	 * @param ui
	 *            Associated UI.
	 */
	public SubstanceSplitPaneDivider(SubstanceSplitPaneUI ui) {
		super(ui);
		this.bgDelegate = new SubstanceFillBackgroundDelegate();
		this.splitPane.setBackground(UIManager
				.getColor("SplitPane.dividerFocusColor"));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	@Override
	public void paint(Graphics g) {
		if (SubstanceCoreUtilities.hasFlatProperty(this.splitPane)) {
			this.bgDelegate.update(g, this.splitPane);
		}

		if (this.splitPane.getOrientation() == JSplitPane.VERTICAL_SPLIT) {
			int bumpWidth = Math.max(20, this.getWidth() / 10);
			BufferedImage bumps = SubstanceImageCreator
					.getDragImage(SubstanceLookAndFeel.getTheme(), false,
							bumpWidth, 6, false);
			g.drawImage(bumps, (this.getWidth() - bumps.getWidth()) / 2, (this
					.getHeight() - bumps.getHeight()) / 2, null);
		} else {
			int bumpHeight = Math.max(20, this.getHeight() / 10);
			BufferedImage bumps = SubstanceImageCreator.getDragImage(
					SubstanceLookAndFeel.getTheme(), false, 6, bumpHeight,
					false);
			g.drawImage(bumps, (this.getWidth() - bumps.getWidth()) / 2, (this
					.getHeight() - bumps.getHeight()) / 2, null);
		}

		super.paint(g);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSplitPaneDivider#createLeftOneTouchButton()
	 */
	@Override
	protected JButton createLeftOneTouchButton() {
		Icon verticalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
				SwingConstants.NORTH, SubstanceCoreUtilities.getActiveTheme(
						this.splitPane, true));

		Icon horizontalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
				SwingConstants.WEST, SubstanceCoreUtilities.getActiveTheme(
						this.splitPane, true));

		JButton b = new JButton(
				this.splitPane.getOrientation() == JSplitPane.VERTICAL_SPLIT ? verticalSplit
						: horizontalSplit) {
			// Don't want the button to participate in focus traversable.
			@Override
			public boolean isFocusable() {
				return false;
			}
		};

		b.putClientProperty(SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY,
				Boolean.TRUE);
		// JButton b = new JButton() {
		// Icon verticalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
		// NORTH, SubstanceLookAndFeel.getColorScheme());
		//
		// Icon horizontalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
		// WEST, SubstanceLookAndFeel.getColorScheme());
		//
		// @Override
		// public void setBorder(Border b) {
		// }
		//
		// @Override
		// public void paint(Graphics g) {
		// JSplitPane splitPane = getSplitPaneFromSuper();
		// if (splitPane != null) {
		// int orientation = getOrientationFromSuper();
		//
		// if (orientation == JSplitPane.VERTICAL_SPLIT) {
		// verticalSplit.paintIcon(splitPane, g, 1, 1);
		// } else {
		// horizontalSplit.paintIcon(splitPane, g, 1, 1);
		// }
		// }
		// }
		//
		// // Don't want the button to participate in focus traversable.
		// @Override
		// public boolean isFocusTraversable() {
		// return false;
		// }
		// };
		b.setRequestFocusEnabled(false);
		b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		b.setFocusPainted(false);
		b.setBorderPainted(false);
		// b.setOpaque(false);
		return b;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicSplitPaneDivider#createRightOneTouchButton()
	 */
	@Override
	protected JButton createRightOneTouchButton() {
		Icon verticalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
				SwingConstants.SOUTH, SubstanceCoreUtilities.getActiveTheme(
						this.splitPane, true));

		Icon horizontalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
				SwingConstants.EAST, SubstanceCoreUtilities.getActiveTheme(
						this.splitPane, true));

		JButton b = new JButton(
				this.splitPane.getOrientation() == JSplitPane.VERTICAL_SPLIT ? verticalSplit
						: horizontalSplit) {
			// Don't want the button to participate in focus traversable.
			@Override
			public boolean isFocusable() {
				return false;
			}
		};

		b.putClientProperty(SubstanceLookAndFeel.BUTTON_PAINT_NEVER_PROPERTY,
				Boolean.TRUE);
		// {
		// Icon verticalSplit = SubstanceImageCreator
		// .getArrowIcon(7, 5, SOUTH, SubstanceLookAndFeel.getColorScheme());
		//
		// Icon horizontalSplit = SubstanceImageCreator.getArrowIcon(7, 5,
		// EAST, SubstanceLookAndFeel.getColorScheme());
		//
		// @Override
		// public void setBorder(Border border) {
		// }
		//
		// @Override
		// public void paint(Graphics g) {
		// JSplitPane splitPane = getSplitPaneFromSuper();
		// if (splitPane != null) {
		// int orientation = getOrientationFromSuper();
		// if (orientation == JSplitPane.VERTICAL_SPLIT) {
		// verticalSplit.paintIcon(splitPane, g, 1, 1);
		// } else {
		// horizontalSplit.paintIcon(splitPane, g, 1, 1);
		// }
		// }
		// }
		//
		// // Don't want the button to participate in focus traversable.
		// @Override
		// public boolean isFocusTraversable() {
		// return false;
		// }
		// };
		b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		b.setFocusPainted(false);
		b.setBorderPainted(false);
		b.setRequestFocusEnabled(false);
		// b.setOpaque(false);
		return b;
	}

	/**
	 * Updates the one-touch buttons.
	 * 
	 * @param orientation
	 *            Split pane orientation.
	 */
	public void updateOneTouchButtons(int orientation) {
		if (orientation == JSplitPane.VERTICAL_SPLIT) {
			if (this.leftButton != null) {
				this.leftButton.setIcon(SubstanceImageCreator.getArrowIcon(7,
						5, SwingConstants.NORTH, SubstanceCoreUtilities
								.getActiveTheme(this.splitPane, true)));
			}
			if (this.rightButton != null) {
				this.rightButton.setIcon(SubstanceImageCreator.getArrowIcon(7,
						5, SwingConstants.SOUTH, SubstanceCoreUtilities
								.getActiveTheme(this.splitPane, true)));
			}
		} else {
			if (this.leftButton != null) {
				this.leftButton.setIcon(SubstanceImageCreator.getArrowIcon(7,
						5, SwingConstants.WEST, SubstanceCoreUtilities
								.getActiveTheme(this.splitPane, true)));
			}
			if (this.rightButton != null) {
				this.rightButton.setIcon(SubstanceImageCreator.getArrowIcon(7,
						5, SwingConstants.EAST, SubstanceCoreUtilities
								.getActiveTheme(this.splitPane, true)));
			}
		}
	}
}
